# Upgrade VMWare Tools
Ansible playbook to Upgrade VMWare tools to match with ESXi host the VM deployed.

## Steps on Upgrade VMWare Tools using vSphere API
1. Ensuring the VM located in the vCenter and Datacenter provided.
2. Checking the availablity of the latest tools version on the ESXi Host.
3. Upgrading the VM Tools using api module on vSphere.
4. Esuring the upgradation is completed successfully.
5. Gathering the facts including the VMTools Version.
6. Adding to the artifact to add to the comments on SNow. (guest_tools_version and guest_tools_status)

## Expected Behaviours
**During vm tools upgrade following behaviours expected**
1. VM may not be respond or get disconnect from network.
2. VM display may flicker sometimes.

## Required variables to run the playbook
* vCenter_FQDN - vCenter FQDN / IP Address where the VM Located.
* vsphere_user - Service Account to connect vSphere and to perform the intended tasks
* vsphere_password - Service Account Password
* hostname - VM Name (to be upgraded)
* deployed_Datacenter - DataCenter the VM deployed.
