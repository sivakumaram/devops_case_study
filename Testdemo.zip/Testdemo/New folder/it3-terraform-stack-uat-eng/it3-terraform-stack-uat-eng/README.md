# it3-terraform-stack
## 1. About
<details><summary><b>Click to expand</b></summary>
This repository defines an IT3 project as well as provides the Ansible configuration to deploy a 3-tier application stack, import a legacy virtual machine to be managed by Terraform Enterprise, and modify an existing machine that is managed by Terraform Enterprise.

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 2. File Structure
<details><summary><b>Click to expand</b></summary>
  
``` it3-terraform-stack/
├── roles/
|   ├── create_bitbucket_repo/                <-- Create the the Bitbucket repo if it doesn't already exist
<!-- |   ├── create_github_repo/                <-- Create the the GitHub repo if it doesn't already exist XXX-->
|   ├── deploy-vm/                         <-- Deploy and modify VMs' in a 3-tier applicatoin stack
|   ├── iac-tfe-role/                      <-- Create and manage terraform workspaces/teams/users
|   ├── import-vm/                         <-- Import legacy virtual machines to be managed by tfe
|   ├── statefile-query/                   <-- Extract information from a statefile
|   ├── terraform-commands/                <-- Terraform Init, Plan, and check states for importing
|   ├── vm-query/                          <-- Test cases for resource workflow template
|   └── requirements.yml                   <-- Additional role requirements from other repositories
├── vars/
|   ├── basic-workspace.yml                <-- Variables for 3-tier application deployment
|   ├── basic-workspace-import.yml         <-- Variables for legacy virtual machine import
|   ├── credentials.yml                    <-- Credential variables to be replaced with CyberArk
|   └── bitbucket.yml                         <-- Bitbucket configuration variables
<!-- |   └── github.yml                         <-- Github configuration variables XXX-->
├── app_deployment.yml                     <-- Playbook to deploy 3-tier application stack
├── configuration.yml                      <-- Configuration of SNow forms
├── initial_board.yml                      <-- 
├── instance_import.yml                    <-- Playbook to import legacy machine(s)
├── instance_import_loop.yml               <-- Task list to loop through importing multiple legacy VMs'
├── instance_modify.yml                    <-- Playbook to modify an existing VM already managed by TFE
├── wrapper.yml                            <-- 
└── README.md                              <-- You are here
```

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 3. Functionality
<details><summary><b>3.1. Deploy 3-Tier Application Stack</b></summary>

#### 3.1.1. About:
Deploy a 3-tier application stack with fully provisioned virtual network. Tiers are: web, app, and data. Can be created with multiple VMs' per tier.

#### 3.1.2. How-To Request:
From the Cloud Services portal:

1. Click "Request Something" shopping cart
2. Expand "Cloud Services" from the left side menu
3. Select "Application Stack"
4. Click "Deploy an Application Stack"
5. Fill in the support group under "Select a support group." (ex. WP Hosting Automation)
6. Fill in cloud account under "Select a cloud_account."
7. Fill in the region under "which region do you want to deploy this application to?"
8. Give the application stack a name under "What do you want to name this application stack?"
9. Select "3-Tier LAMP Stack" from the "Select an application template" dropdown
00. Click "Order Now" button

#### 3.1.3. Playbook Run from IT3:
app_deployment.yml

</details>

<details><summary><b>3.2. Import a Legacy Virtual Machine</b></summary>

#### 3.2.1. About:
Import a legacy virtual machine to be managed by Terraform Enterprise.

#### 3.2.2. How-To Request:
From the Cloud Services portal:

1. Click "Request Something" shopping cart
2. Expand "Cloud Services" from the left side menu
3. Select "Servers"
4. Click "Import a Legacy Virtual Machine"
5. Fill in the support group under "Select a support group." (ex. WP Hosting Automation)
6. Fill in cloud account under "Select a cloud_account."
7. Select the CMDB record for the machine to import with the dropdown, or
8. Enter the name of the VM to import (Development, will be removed in a future version)
9.  Click "Order Now" button

#### 3.2.3. Playbook Run from IT3:
instance_import.yml

</details>

<details><summary><b>3.3. Modify a Virtual Machine</b></summary>

#### 3.3.1. About:
Modify a virtual machine that is already managed by Terraform Enterprise. The machine must have either been deployed as a 3-tier application stack or have been imported.

#### 3.3.2. How-To Request:
From the Cloud Services portal:

1. Click "Request Something" shopping cart
2. Expand "Cloud Services" from the left side menu
3. Select "Servers"
4. Click "Modify an Existing Virtual Machine"
5. Fill in the support group under "Select a support group." (ex. WP Hosting Automation)
6. Fill in cloud account under "Select a cloud_account."
7. Select the CMDB record for the machine to import with the dropdown
8. Enter the repository name and file name where the machine is configured. (ex. PCB00000001/RITM000001.tf) (*no longer required*)
9. If changing the number of CPUs the machine has, specify the total number the machine should have. Otherwise, leave blank
00. If changing the amount of memory the machine has, specify the total amount the machine should have. Otherwise, leave blank
11. If adding an additional disk to the machine, specify the size of the disk in GigaBytes
12. If extending a disk size, specify the disk's unit number and size seperated by a colon. (ex. to modify disk with unit number 1 to 60GB put: 1:60)
13. Click "Order Now" button

#### 3.3.3. Playbook Run from IT3:
instance_modify.yml

</details>

--------------------------------------------------------------------------------------------------------------------------------------