# deploy-vm
## 1. About
<details><summary><b>Click to expand</b></summary>
Ansible role to deploy a 3-tier application stack and modify existing virtual machines.

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 2. File Structure
<details><summary><b>Click to expand</b></summary>
  
``` deploy-vm/
├── defaults/
|   └── main.yml               <-- Default variable values for the role if not provided elsewhere
├── tasks/
|   ├── create.yml             <-- Create 3-tier application action
|   ├── main.yml               <-- Clone repo, perform action, commit and push changes
|   └── modify.yml             <-- Modify existing virtual machine action
├── templates/
|   ├── _outputs.tf.j2         <-- Output variables on terraform apply
|   ├── _providers.tf.j2       <-- All providers needed for the module
|   ├── _variables.tf.j2       <-- Variables to be defined in the TFE workspace
|   ├── aci.tf.j2              <-- Manage Ansible Tower resources to create virtual network for application
|   ├── app.tf.j2              <-- Configuration for the app tier virtual machine(s)
|   ├── data.tf.j2             <-- Configuration for the data tier virtual machine(s)
|   ├── vm.tf.j2               <-- Configuration for modifying 3-tier application virtual machines
|   ├── vmi.tf.j2              <-- Configuration for modifying imported legacy virtual machines
|   └── web.tf.j2              <-- Configuration for the web tier virtual machine(s)
└── README.md                  <-- You are here
```

</details>

--------------------------------------------------------------------------------------------------------------------------------------