test-splunk-ansible-role
=========

The Splunk universal forwarder is a free, dedicated version of Splunk Enterprise that contains only the essential components needed to forward data. TechSelect uses the universal forwarder to gather data from a variety of inputs and forward your machine data to Splunk indexers. The data is then available for searching.

Requirements:
------------
Splunk supports using Splunk Enterprise on several computing environments. 

Role Variables
--------------

test_splunk_toolname - Name of the tool( default Splunk).
test_splunk_state - The desired state ( default Present).
test_run_orc - Flag to check ORC verification ( Default False).
test_splunk_communication_status - Flag to check console communication or not (Default False).
fix_splunk_service_name - Splunk agent process name ( default rsyslog and wincollect)
test_splunk_config_path - Configuration directory path (default /etc/rsyslog.conf)
test_splunk_service_path - Service path (default /etc/init.d/rsyslog )
test_splunk_agnet_msi - Wincollect.msi file name.
test_splunk_win_pkg_url - HTTP URL for package download.
test_splunk_temp_path - temp path to extract zip file ( default C:\\Splunk )

Example Playbook
----------------
Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: all
      roles:
         - { role: test-splunk-ansible-role, ignore_errors: True }

License
-------

MIT, test

Author Information
------------------
Windows:
The Role is written by shambhavi : shambhavi@company.com

Rhel:
The Role is written by Prabhuraj Murugesan: Prabhuraj.Murugesan@company.com 

