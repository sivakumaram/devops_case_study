#!/usr/bin/python

import requests
import argparse
import xml.etree.ElementTree as ET


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--hostname', required=True, action='store', help="hostname to search")
    parser.add_argument('-c', '--console_hostname', required=True, action='store', help="Remote host to connect to")
    parser.add_argument('-p', '--port', required=False, action='store', help="port to use, default 8089", default=8089)
    parser.add_argument('-a', '--auth', required=True, action='store', help="Authorization code to connect the console")
    parser.add_argument('-q', '--Query', required=False, action='store', help="searchQuery to generate jobid for hostname")

    args = parser.parse_args()

    return args

args = get_args()


searchQuery = 'search index="*" host='+args.hostname+' earliest=-3h latest=+1d| stats count by host'
data = {'search': searchQuery}
custom_header = 'Splunk %s' % args.auth
port = str(args.port)
baseurl = 'https://'+args.console_hostname+':'+port+'/services/search/jobs/'
response = requests.post(baseurl,data=data ,headers={'Authorization': custom_header}, verify=False)

root = ET.fromstring(response.text)
for i in root:
   jobid = i.text

#!/usr/bin/python
#print(jobid)
import time
time.sleep(20)

data = {'output_mode':'json'}
hostname = requests.get(baseurl+ jobid +"/results/", headers={'Authorization': custom_header},verify=False ,data = data)
Uhost = args.hostname.lower()


try:
   host_len = len(args.hostname)
   Index_value = hostname.text.lower().find(Uhost)
   sum = host_len + Index_value
   splunk_host = hostname.text[Index_value:sum]
except:
   splunk_text = hostname.text
   splunk_host = splunk_text["results"][0]['host']

if splunk_host.lower() == Uhost:
   print(splunk_host)
else:
   print("Host not Found")
