# iac-tfe-role

##Install

    ansible-galaxy install git+https://github.devops.test.local/robops/iac-tfe-role.git -f

How to use this role

    ansible-playbook -i '127.0.0.1,' -c local main.yml -e @vars.yml

Main.yml

    ---
    - name: Create Workspaces
      hosts: all
      roles:
      - {role: iac-tfe-role, tfe_object: workspaces, action: create, org_name: robops, workspace_name: workspace_xx_dev, oauth_name: Github.test-lab, repo_name: Hello-World, repo_org: robops}
    
    - name: Create workspace-variable
      hosts: all
      roles:
      - {role: iac-tfe-role, tfe_object: workspace-variables, action: create, org_name: robops, workspace_name: workspace_xx_dev, key: test, value: X}


vars.yml

    ---
    token: "[Terraform API Token]"
    tfe_host: [Terraform Enterprise URL]
    ui_url_protocol: [https or http]
    email: [email address]

## To test 

install role
clone repo
cd [repo path]/tests

### Org
#### Create
ansible-playbook -i '127.0.0.1,' -c local main.yml -e @vars.yml -e @./org/create.yml
#### Delete
ansible-playbook -i '127.0.0.1,' -c local main.yml -e @vars.yml -e @./org/delete.yml
#### Get
ansible-playbook -i '127.0.0.1,' -c local main.yml -e @vars.yml -e @./org/get.yml -vv

### Team
#### Create
ansible-playbook -i '127.0.0.1,' -c local main.yml -e @vars.yml -e @./teams/create.yml
#### Get
ansible-playbook -i '127.0.0.1,' -c local main.yml -e @vars.yml -e @./teams/get.yml -vv
