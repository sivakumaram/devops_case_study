# it3-terraform-deployment
## 1. About
<details><summary><b>Click to expand</b></summary>
This repository defines an IT3 project as well as provides the Ansible configuration to deploy a Red Hat Enterprise Linux (RHEL) server managed by Terraform Enterprise.

- Now makes use of Bitbucket as opposed to Github for creation of the repository. 

- Instances of the servers also follow a standard naming convention based on specified parameters in SNow form.

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 2. File Structure
<details><summary><b>Click to expand</b></summary>
  
``` 
it3-terraform-deployment/
├── roles/
|   └── create_bitbucket_repo/          <-- Create the the Bitbucket repo if it doesn't already exist
|   |   └── defaults/
|   |   |   └── main.yml                        <-- Default variable values for creating the bitbucket repo
|   |   └── tasks/
|   |   |   └── main.yml                        <-- Task for creating the bitbucket repo
|   └── create_github_repo/            <-- Create the the Github repo if it doesn't already exist
|   |   └── defaults/
|   |   |   └── main.yml                        <-- Default variable values for creating the github repo
|   |   └── tasks/
|   |   |   └── main.yml                        <-- Task for creating the github repo
|   └── deploy-vm/                     <-- Deploy and modify VMs' for RHEL and Windows Servers
|   |   └── defaults/
|   |   |   └── main.yml                        <-- Default variable values needed for deploying a vm
|   |   └── tasks/
|   |   |   ├── main.yml                        <-- Task for cloning and creating tf files in the repo
|   |   |   ├── middleware_converter.yml        <-- Task for getting middleware information
|   |   |   └── sys_id_converter.yml            <-- Task for converting the sys_id, needed for name generator 
|   |   └── templates/
|   |   |   ├── providers-vsphere-alias.tf.j2   <-- Jinja file for specific vsphere datacenters
|   |   |   ├── providers.tf.j2                 <-- Jinja file for providers, vault and ansible tower
|   |   |   ├── variables.tf.j2                 <-- Jinja file for all the variables specific to a RITM number
|   |   |   ├── vars.tf.j2                      <-- Jinja file for all the variables needed for vm.tf.j2
|   |   |   └── vm.tf.j2                        <-- Jinja file for creating the vm module 
|   └── iac-tfe-role/                  <-- Create and manage terraform workspaces/teams/users
|   └── snow_info_converter/         
|   |   └── tasks/            
|   |   |   ├── main.yml                        <-- Task for gathering snow information from the snow request
|   |   |   └── playbook_template_names.yml     <-- Templating the names for playbooks
|   └── vault/                         <-- Making API calls to vault to create and revoke vault tokens 
|   └── requirements/                  <-- Additional role requirements from other repositories
├── configuration.yml/             <-- Configuration of the SNow forms
├── current_run_wrapper.yml/       <-- Wrapper file to encapsulate functionality for TFE's current run
├── initial_board.yml/             <-- Defines tasks for an initial enviornment
├── rhel_server.yml/               <-- Playbook to create and deploy RHEL server
├── wrapper.yml/                   <-- Wrapper file to encapsulate functionality for TFE
└── README.md                      <-- You are here
```

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 3. Functionality
<details><summary><b>3.1. Create and Deploy a RHEL server virtual machine</b></summary>

#### 3.1.1. About:
Deploy a fully specified RHEL server virtual machine. Requires usage of SNow to define all parameters needed for the machine.

#### 3.1.2. How-To Request:
From the Cloud Services portal:

1. Click "Request Something" shopping cart
2. Expand "Cloud Services" from the left side menu
3. Select "Compute"
4. Click "Deploy an RedHat Enterprise Linux Server"
5. Fill in the support group under "Select a support group." (ex. WP Hosting Automation)
6. Fill in cloud account under "Select a cloud_account."
7. Fill in the size under "Size"
8. Fill in the region under "Select a Location."
9. Fill in the operating platform under "Select a Operating Platform" (RedHat Enterprise Linux, though also works with Windows)
00. Fill in the line of business under "Which of line of business will this server belong?"
11. Fill in the function of the server under "What function will this Server perform?" (ex. Terraform Enterprise)
12. Fill in the business application instance under "What business application instance will this server belong to?" (ex. WHOST Automation Services)
13. Give the RHEL server a name under "What do you want to name this application?"
14. Click "Order Now" button

#### 3.1.3. Playbook Run from IT3:
rhel_server.yml

</details>

--------------------------------------------------------------------------------------------------------------------------------------
