# terraform-provider-tcbtower
## Table of Contents
* [1. About](./README.md#1-about)
* [2. Usage](./README.md#2-usage)
* [3. Sources](./README.md#3-sources)
* [4. Roadmap](./README.md#4-roadmap)
  - [Upcoming Work](./README.md#upcoming-work)
  - [Completed Work](./README.md#completed-work)
## 1. About
TCBTower provider is a plugin for Terraform and Terraform Enterprise written in Go (golang) to manage resources on Ansible tower. It is designed with running jobs and workflow jobs in mind with the assumption of infrastructure needing to be both safely created and destroyed. Complete workflows are supported; for example: the provider could trigger a job/workflow run using a job template(s), project(s), inventory(ies), credential(s), host(s), and host group(s) all created with the provider.


## 2. Usage

### Provider Initialization
TCB 'tower' has the following inputs for initialization:

  - **tower_host** *(string)*: url to Tower's API. (ex. _https://tower_url/api/v2/_)
  - **tower_user** *(string)*: username to log into Tower.
  - **tower_password** *(string)*: password to log into Tower.
  - **tower_token** *(string)*: application token from Tower.
  - **allow_unverified_ssl** *(bool, optional)*: whether or not to allow unverified certificates in response from Tower. 


The following must be placed in a `*.tf` file:
  
```nginx
provider "tower" {
                      # REQUIRED #
  tower_host     = "<tower-url>"   

  ################# Basic Auth ####################
  tower_user     = "<tower-username>"
  tower_password = "<password-for-username>"
  #################################################

                      # OR #

  #################### Token ######################
  tower_token    = "<tower application token>"
  #################################################
  
                      # OPTIONAL #
  allow_unverified_ssl = <bool>     # Default is false if omitted
}

```



## 3. Sources
- [Credential Type](./docs/CREDENTIAL_TYPE.md)
- [Credential](./docs/CREDENTIAL.md)
- [Group](./docs/GROUP.md)
- [Host Group](./docs/HOST_GROUP.md)
- [Host](./docs/HOST.md)
- [Instance Group](./docs/INSTANCE_GROUP.md)
- [Inventory](./docs/INVENTORY.md)
- [Job Run](./docs/JOB_RUN.md)
- [Job Template](./docs/JOB_TEMPLATE.md)
- [Organization](./docs/ORGANIZATION.md)
- [Project](./docs/PROJECT.md)
- [Schedule](./docs/SCHEDULE.md)
- [Workflow Run](./docs/WORKFLOW_RUN.md)
- [Workflow Template](./docs/WORKFLOW_TEMPLATE.md)

## 4. Roadmap
 
### Upcoming Work


- [ ] Add a valid read function resource_workflow_run:resourceWorkflowRunRead. Low Priority.
- [ ] Rewrite the Job Template Function to be less entangled. Low Priority.

 
### Completed Work
- [X] Generalize http return body error checking
- [X] Rewrite the Workflow Template to not have Implement Destroy.
- [X] Re-refactor the documentation
- [X] Split out helpers into more appropriately named filenames
- [X] Verify all data and resources are in README and are up to date.
- [X] Add retries to job run, default to 0
- [X] Standardize pluralization of resources and datas
- [X] Start and Finish times added to Job Template state files
- [X] Verify and Fix the numbering in README.
- [X] Refactor Documentation.
- [X] Add instance groups to organization resource
- [X] Investigate edge cases for the final return value of resource_inventory:getAllIGs - TK
- [X] Add instance group resource
- [X] Implement unboxing error checking in each data: refer to `data_resource_group.go`
- [X] Move all TODO's to this list
- [X] Option for concurrent job runs in job templates - GA
- [X] Add functionality to dettach credential from project resource - GA
- [X] Add artifact pass back to Job Run deletes - TK
- [X] Resource organization (CRUD organizations) - TK
- [X] Data organization - GA
- [X] Deprecate `implement_destroy` flag
- [X] Investigate the possibility of valid 400s returned in resource_inventory:removeIGfromInventory - TK
- [X] Cleanly handle the 400 case so it is informative in the error. 400 returns when adding multiple of the same kind. In resource_job_template:setCredentialList - TK
- [X] Implement import for resource_group
- [X] Implement import for resource_instance_groups
- [x] Implement import for resource_workflow_template
- [x] Implement import for resource_inventory
- [X] Implement import for resource_credential_type
- [X] Implement import for resource_host
- [X] Implement import for resource_organization
- [X] Implement import for resource_job_template
- [X] Give all resources with organization option to provide ID as well as name (DON'T BREAK ANYTHING)
- [X] Add inventory parameter to resource_job_template
- [X] If `no_delete==true` in job run, look up job run directly without _create post-pends
- [X] Implement import for resource_project
- [X] Generalize all tests to use tower data instead of hard coded values. Low Priority.
- [X] Fix testAccCheckItemExists in resource_credential_type_test - TK
- [x] Compare all of our stuff to [Best Practices](https://www.terraform.io/docs/extend/best-practices/detecting-drift.html) to find any risky things
- [X] Add schedules to Job Templates
- [X] Remove over-the-table organization ID resolution
- [X] Add sensitive inputs parameter to Credentials resource


To contribute to this project please refer to the [contribution](./docs/CONTRIBUTING.md) guide.

To read about the testing efforts for this project please refer to the [testing](./docs/TESTING.md) summary document.
