package tcbtower

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

// getEntry queries the api either using the id or the name
func getEntry(meta interface{}, endpoint string, query interface{}) (map[string]interface{}, error) {
	switch q := query.(type) {
	case int:
		return getEntryByID(meta, endpoint, q)
	case string:
		return getEntryByName(meta, endpoint, q)
	default:
		return nil, fmt.Errorf("unknown type for query parameter: %v", query)
	}
}

// getEntryByID queries the api at the id specific endpoint for th.e query id resource
func getEntryByID(meta interface{}, endpoint string, id int) (map[string]interface{}, error) {
	queryEndpoint := endpoint + fmt.Sprint(id) + "/"
	config := meta.(*Config)

	client := config.Client(queryEndpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return nil, fmt.Errorf("error creating new request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return nil, fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return nil, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse body with error %s", err)
	}

	return body, nil
}

// getEntryByName queries the api at the endpoint for a list of resources and then returns the one specified by "name"
func getEntryByName(meta interface{}, endpoint, name string) (map[string]interface{}, error) {
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)

	if err != nil {
		return nil, fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return nil, fmt.Errorf("error setting authorization headers: %s", err)
	}

	q := req.URL.Query()
	q.Add("search", name)
	req.URL.RawQuery = q.Encode()

	res, err := client.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return nil, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse body with error %s", err)
	}

	if body["count"] == nil {
		return nil, fmt.Errorf("result does not have 'count' in body")
	}

	count, ok := body["count"].(float64)
	if !ok {
		return nil, errors.New("no count found in entry body")
	}
	if count < 1 {
		return nil, fmt.Errorf("no item of name \"%s\" found at %s", name, endpoint)
	}

	entry, err := extractSearchEntry(body, name)
	return entry, err
}

// extractSearchEntry searches through a list of resources ande returns the one with a matching name
func extractSearchEntry(b map[string]interface{}, name string) (map[string]interface{}, error) {
	arr, ok := b["results"].([]interface{})
	if !ok {
		return nil, fmt.Errorf("error unable to find \"results\" in response body")
	}

	for i := 0; i < len(arr); i++ {
		j := arr[i].(map[string]interface{})
		if j["name"] == name {
			return j, nil
		}
	}

	return nil, fmt.Errorf("did not match name to results")
}

// resolveOrganization resolves an organization name to an ID or just returns the ID if it is already set. Pass "OPTIONAL" as third argument to skip argument errors
func resolveOrganization(d *schema.ResourceData, meta interface{}, requirement string) (int, error) {

	if d.Get("organization_id").(int) != 0 {
		return d.Get("organization_id").(int), nil
	}

	if d.Get("organization").(string) != "" {
		org, err := getEntry(meta, "organizations/", d.Get("organization").(string))
		if err != nil {
			return -1, fmt.Errorf("error resolving organization id: %s", err)
		}

		return int(org["id"].(float64)), nil
	}

	if d.Get("organization").(string) == "" && d.Get("organization_id").(int) == 0 {
		if requirement != "OPTIONAL" {
			return -1, fmt.Errorf("argument error: neither organization name nor organization_id were supplied")
		}
		return -1, nil
	}

	return -1, fmt.Errorf("unexpected error while resolving organization id")
}

// setItems sets the specified list of items found in a response body map
func setItems(d *schema.ResourceData, body map[string]interface{}, items []string) error {
	set := func(d *schema.ResourceData, body map[string]interface{}, i string) error {
		if body[i] == nil {
			return nil
		}
		switch v := body[i].(type) {
		case float64:
			return d.Set(i, v)
		case int:
			return d.Set(i, v)
		case string:
			return d.Set(i, v)
		case bool:
			return d.Set(i, v)
		case []string:
			return d.Set(i, v)
		default:
			return fmt.Errorf("unknown type: body item %s", i)
		}
	}

	for _, s := range items {
		err := set(d, body, s)
		if err != nil {
			return err
		}
	}
	return nil
}

// GetAllResourceIGs gets a list of every instance group associated with this resource by ID
func GetAllResourceIGs(resourceEndpoint string, id int, meta interface{}) ([]interface{}, error) {
	endpoint := resourceEndpoint + fmt.Sprint(id) + "/instance_groups/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return nil, fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return nil, fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return nil, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse body with error %s", err)
	}
	if body["results"] != nil {
		igList, ok := body["results"].([]interface{})
		if ok {
			return igList, nil
		}
	}
	return nil, errors.New("error: No results found in response body")

}

// AddIGstoResource adds a list of instance groups to the resource via ID. Pluralized function names are ill-advised but here we are.
func AddIGstoResource(endpoint string, id int, igs interface{}, meta interface{}) error {
	if igs != nil {
		arr := igs.([]interface{})
		for i := 0; i < len(arr); i++ {
			err := AddIGtoResource(endpoint, id, meta, arr[i].(int))
			if err != nil {
				return fmt.Errorf("error adding instance group: %d to %s: %s", arr[i].(int), endpoint, err)
			}
		}
	}
	return nil
}

// AddIGtoResource adds a single instance group to the resource via id
func AddIGtoResource(resourceEndpoint string, id int, meta interface{}, ig int) error {
	// XXX: RemoveIGfromResource and AddIGtoResource can probably be joined into a single function

	endpoint := resourceEndpoint + fmt.Sprint(id) + "/instance_groups/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	reqBody, err := json.Marshal(map[string]interface{}{
		"associate": true,
		"id":        ig,
	})
	if err != nil {
		return fmt.Errorf("error marshaling JSON body: %s", err)
	}

	req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to post new host with error: %s", err)
	}

	if !(res.StatusCode == http.StatusCreated || res.StatusCode == http.StatusNoContent) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusCreated, http.StatusNoContent),
			reqBody,
			res.Body,
		)
	}

	return nil
}

// RemoveIGfromResource removes a single instance group associated with this resource by ID
func RemoveIGfromResource(resourceEndpoint string, id int, meta interface{}, ig int) error {
	// XXX: RemoveIGfromResource and AddIGtoResource can probably be joined into a single function

	endpoint := resourceEndpoint + fmt.Sprint(id) + "/instance_groups/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	reqBody, err := json.Marshal(map[string]interface{}{
		"id":           ig,
		"disassociate": true,
	})
	if err != nil {
		return fmt.Errorf("error marshalling body\n body was %v", reqBody)
	}

	req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	req.Header.Set("Content-type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusNoContent {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
			reqBody,
			res.Body,
		)
	}

	return nil
}
