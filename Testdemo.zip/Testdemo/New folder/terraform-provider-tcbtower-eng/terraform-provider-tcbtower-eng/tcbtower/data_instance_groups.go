package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataInstanceGroups() *schema.Resource {
	return &schema.Resource{
		DeprecationMessage: "tower_instance_groups is deprecated and will be removed in future releases. Please use tower_instance_group",
		Read:               dataInstanceGroupsRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"url": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"capacity": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"jobs_running": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"jobs_total": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"instances": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"controller": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"credential": {
				Type:     schema.TypeInt,
				Computed: true,
			},
		},
	}
}

func dataInstanceGroupsRead(d *schema.ResourceData, meta interface{}) error {
	endpoint := "instance_groups/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return err
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	propertyList := []string{
		"name", "url", "jobs_running", "jobs_total", "controller", "instances", "credential",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for Instance groups, %s", err)
	}

	return nil
}
