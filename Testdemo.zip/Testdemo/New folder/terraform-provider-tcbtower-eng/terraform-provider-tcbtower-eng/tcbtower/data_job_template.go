package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataJobTemplate() *schema.Resource {
	return &schema.Resource{
		Read: dataJobTemplateRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"inventory": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"credential": {
				Type:     schema.TypeInt,
				Computed: true,
			},
		},
	}
}

func dataJobTemplateRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "job_templates/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return fmt.Errorf("unable to retrieve entry with error: %s", err)
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	propertyList := []string{
		"inventory", "credential",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for Job Template, %s", err)
	}

	return nil
}
