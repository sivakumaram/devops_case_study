package tcbtower

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const instanceGroupTestEndpoint string = "instance_groups/"

func TestAccInstanceGroupResource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_instance_group" "test" {
					name = "tf-acc-test-%[1]s"
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_instance_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_instance_group.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCheckResourceExists(
					instanceGroupTestEndpoint, "tower_instance_group.test",
				),
			)
			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(instanceGroupTestEndpoint, "tower_instance_group", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_instance_group" "test" {
					name = "tf-acc-test-%[1]s"
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_instance_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_instance_group.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_instance_group" "test" {
					name = "tf-acc-test-%[1]s"
				}`, randomID)

			updateConfig := fmt.Sprintf(`
			resource "tower_organization" "dependency" {
				name = "tf-acc-test-organization-%[1]s"
			}

			resource "tower_credential_type" "dependency" {
				name = "tf-acc-test-credential-type-%[1]s"
				inputs = "{}"
				injectors = "{}"
			}
			
			resource "tower_credential" "dependency" {
				name = "tf-acc-test-%[1]s"
				type = tower_credential_type.dependency.id
				organization_id = tower_organization.dependency.id
				organization = tower_organization.dependency.name
			}

			resource "tower_instance_group" "test" {
				name = "tf-acc-test-update-%[1]s"
				credential = tower_credential.dependency.id
				policy_instance_percentage = 47
				policy_instance_minimum = 3
				pod_spec_override = "nothing"
			}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_instance_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_instance_group.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_instance_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_instance_group.test", "name", fmt.Sprintf("tf-acc-test-update-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_instance_group.test", "credential", "tower_credential.dependency", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_instance_group.test", "policy_instance_percentage", "47",
				),
				resource.TestCheckResourceAttr(
					"tower_instance_group.test", "policy_instance_minimum", "3",
				),
				resource.TestCheckResourceAttr(
					"tower_instance_group.test", "pod_spec_override", "nothing",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

}
