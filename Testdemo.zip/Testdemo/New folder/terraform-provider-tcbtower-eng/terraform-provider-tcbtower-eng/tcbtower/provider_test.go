package tcbtower

import (
	"os"
	"strconv"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/terraform"
)

var testAccProviders map[string]terraform.ResourceProvider
var testAccProviderFactories func(providers *[]*schema.Provider) map[string]terraform.ResourceProviderFactory
var testAccProvider *schema.Provider

func init() {
	testAccProvider = Provider().(*schema.Provider)
	testAccProviders = map[string]terraform.ResourceProvider{
		"tower": testAccProvider,
	}

	// The Provider attribute of resource.TestCase is deprecated so we are getting ahead of things here
	testAccProviderFactories = func(providers *[]*schema.Provider) map[string]terraform.ResourceProviderFactory {
		return map[string]terraform.ResourceProviderFactory{
			"tower": func() (terraform.ResourceProvider, error) {
				p := Provider()
				*providers = append(*providers, p.(*schema.Provider))
				return p, nil
			},
		}
	}
}

func TestAccProvider(t *testing.T) {
	if err := Provider().(*schema.Provider).InternalValidate(); err != nil {
		t.Fatalf("err: %s", err)
	}
}

func TestProvider_impl(t *testing.T) {
	var _ terraform.ResourceProvider = Provider()
}

func TestAccPreCheck(t *testing.T) {
	if v := os.Getenv("TOWER_URL"); v == "" {
		t.Fatal("TOWER_URL must be set for acceptance tests")
	}
	vu := os.Getenv("TOWER_USER")
	vp := os.Getenv("TOWER_PASSWORD")
	vt := os.Getenv("TOWER_TOKEN")
	if vp == "" && vu == "" && vt == "" {
		t.Fatal("TOWER_USER and TOWER_PASSWORD or TOWER_TOKEN must be set for acceptance tests")
	}
	if v := os.Getenv("ALLOW_UNVERIFIED_SSL"); v == "" {
		t.Fatal("TOWER_ALLOW_UNVERIFIED_SSL must be set for acceptance tests")
	}

}

func TestAccProjectPreCheck(t *testing.T) {
	TestAccPreCheck(t)

	if os.Getenv("TEST_PROJECT_SCM_URL") == "" {
		t.Fatal("TEST_PROJECT_SCM_URL must be set for project related acceptance tests and must be accessible to test network")
	}
}

// ConfigureTestProvider sets up a new provider prepared with the meta config found in environmental variables
func ConfigureTestProvider(t *testing.T) *schema.Provider {
	// Set up the tower
	TestAccPreCheck(t)
	allowUnverifiedSSL, err := strconv.ParseBool(os.Getenv("ALLOW_UNVERIFIED_SSL"))
	if err != nil {
		allowUnverifiedSSL = true
	}
	config := &Config{
		towerHost:          os.Getenv("TOWER_URL"),
		towerUser:          os.Getenv("TOWER_USER"),
		towerPassword:      os.Getenv("TOWER_PASSWORD"),
		towerToken:         os.Getenv("TOWER_TOKEN"),
		allowUnverifiedSSL: allowUnverifiedSSL,
	}

	testAccProvider.SetMeta(config)
	return testAccProvider
}
