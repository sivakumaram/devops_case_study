package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataWorkflowTemplate() *schema.Resource {
	return &schema.Resource{
		Read: dataWorkflowTemplateRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"description": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"workflow_template_id": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"type": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"status": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"scm_branch": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"limit": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"inventory": {
				Type:     schema.TypeInt,
				Computed: true,
			},
		},
	}
}

func dataWorkflowTemplateRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "workflow_job_templates/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return err
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	propertyList := []string{
		"workflow_template_id",
		"type",
		"name",
		"description",
		"status",
		"limit",
		"inventory",
		"scm_branch",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for WorkflowTemplate, %s", err)
	}

	return nil
}
