package tcbtower

import (
	"fmt"
	"os"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const JobRunTestEndpoint string = "job_templates/"

func TestAccJobRunResource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Skip("This is a knot and is semi-untestable.")
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
				}
				
				resource "tower_job_run" "test_run" {
					name = "tf-acc-test-%[1]s"
					no_delete = true
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_run.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_run.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
			)

			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(JobRunTestEndpoint, "tower_job_template", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
				}
				
				resource "tower_job_run" "test_run" {
					name = "tf-acc-test-%[1]s"
					no_delete = True
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_run.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_run.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
				}
				
				resource "tower_job_run" "test_run" {
					name = "tf-acc-test-%[1]s"
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			updateConfig := fmt.Sprintf(`
			resource "tower_organization" "dependency" {
				name = "tf-acc-test-%[1]s"
			}

			resource "tower_project" "dependency" {
				name = "tf-acc-test-%[1]s"
				organization_id = tower_organization.dependency.id
				organization = tower_organization.dependency.name

				scm_type = "git"
				scm_url = "%[2]s"
			}

			resource "tower_job_template" "test" {
				name = "tf-acc-test-%[1]s"
				project_id = tower_project.dependency.id
				organization_id = tower_organization.dependency.id
				organization = tower_organization.dependency.name
				playbook = "main"
			}
			
			resource "tower_job_run" "test_run" {
				name = "tf-acc-test-update-%[1]s"
			}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_run.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_run.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-update-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.update_dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.update_dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.update_dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

}
