package tcbtower

import (
	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/terraform"
)

// Provider TCB tower provider implementation
func Provider() terraform.ResourceProvider {
	return &schema.Provider{
		Schema: map[string]*schema.Schema{
			"tower_host": {
				Type:        schema.TypeString,
				Required:    true,
				DefaultFunc: schema.EnvDefaultFunc("TOWER_URL", nil),
				Description: "The URL for Ansible Tower",
			},
			"tower_user": {
				Type:        schema.TypeString,
				Optional:    true,
				DefaultFunc: schema.EnvDefaultFunc("TOWER_USER", ""),
				Description: "The user for Tower API operations",
			},
			"tower_password": {
				Type:        schema.TypeString,
				Optional:    true,
				Sensitive:   true,
				DefaultFunc: schema.EnvDefaultFunc("TOWER_PASSWORD", ""),
				Description: "The password for Tower API Operations",
			},
			"tower_token": {
				Type:        schema.TypeString,
				Optional:    true,
				Sensitive:   true,
				DefaultFunc: schema.EnvDefaultFunc("TOWER_TOKEN", ""),
				Description: "The token for Tower API Operations",
			},
			"connection_timeout": {
				Type:		 schema.TypeInt,
				Optional: 	 true,
				DefaultFunc: schema.EnvDefaultFunc("CONNECTION_TIMEOUT", 600),
			},
			"allow_unverified_ssl": {
				Type:        schema.TypeBool,
				Optional:    true,
				DefaultFunc: schema.EnvDefaultFunc("ALLOW_UNVERIFIED_SSL", false),
				Description: "Whether or not to allow unverified SSL certificates",
			},
		},
		ResourcesMap: map[string]*schema.Resource{
			"tower_credential":        resourceCredential(),
			"tower_credentials":       resourceCredentials(),
			"tower_credential_type":   resourceCredentialType(),
			"tower_instance_group":    resourceInstanceGroup(),
			"tower_inventory":         resourceInventory(),
			"tower_host":              resourceHost(),
			"tower_host_group":        resourceGroup(),
			"tower_job_template":      resourceJobTemplate(),
			"tower_job_run":           resourceJobRun(),
			"tower_organization":      resourceOrganization(),
			"tower_project":           resourceProject(),
			"tower_schedule":          resourceSchedule(),
			"tower_workflow_run":      resourceWorkflowRun(),
			"tower_workflow_template": resourceWorkflowTemplate(),
		},
		DataSourcesMap: map[string]*schema.Resource{
			"tower_credential":        dataCredential(),
			"tower_credentials":       dataCredentials(),
			"tower_credential_type":   dataCredentialType(),
			"tower_instance_group":    dataInstanceGroup(),
			"tower_instance_groups":   dataInstanceGroups(),
			"tower_inventory":         dataInventory(),
			"tower_job_template":      dataJobTemplate(),
			"tower_organization":      dataOrganization(),
			"tower_project":           dataProject(),
			"tower_schedule":          dataSchedule(),
			"tower_workflow_template": dataWorkflowTemplate(),
		},
		ConfigureFunc:    providerConfigure,
		MetaReset:        nil,
		TerraformVersion: "",
	}
}

func providerConfigure(d *schema.ResourceData) (interface{}, error) {
	config := &Config{
		towerHost:          d.Get("tower_host").(string),
		towerUser:          d.Get("tower_user").(string),
		towerPassword:      d.Get("tower_password").(string),
		towerToken:         d.Get("tower_token").(string),
		connectionTimeout:  d.Get("connection_timeout").(int),
		allowUnverifiedSSL: d.Get("allow_unverified_ssl").(bool),
	}
	return config, nil
}
