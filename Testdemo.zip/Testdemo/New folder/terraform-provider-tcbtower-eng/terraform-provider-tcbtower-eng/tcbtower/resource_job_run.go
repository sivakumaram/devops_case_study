package tcbtower

import (
	"fmt"
	"log"
	"strconv"
	"time"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

// Schema for the resource: tower_job_run
// Required variables:
//   - template_name: the name of the job template collection.
//   -- If the collection name is "tower" there must be job templates: "tower_create" and "tower_delete" on ansible tower
//
//   - template_inventory: the id number for the inventory to use on ansible tower
//   - template_credentials: the id number for the credentials to use on ansible tower
//
// Optional variables:
//	 - extra_vars: map of additional variables to use
func resourceJobRun() *schema.Resource {
	return &schema.Resource{
		Create: resourceJobRunCreate,
		Read:   resourceJobRunRead,
		Update: resourceJobRunUpdate,
		Delete: resourceJobRunDelete,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:        schema.TypeString,
				Required:    true,
				Description: "The name of the Job Template w/o the _create/delete",
			},
			"inventory": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  -1,
			},
			"delete_inventory": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  -1,
			},
			"credential": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  -1,
			},
			"delete_credential": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  -1,
			},
			"credentials": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default: nil,
			},
			"extra_vars": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"no_delete": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Set to true if there is no delete job template to go with the create",
			},
			"no_update": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Set to true to skip update calls",
			},
			"wait_for_job_retries": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  4000,
			},
			"status_check_retries": {
				Type:        schema.TypeInt,
				Optional:    true,
				Default:     4000,
				Description: "Number of times the status of the job will be checked before timing out and assuming failure.",
			},
			"wait_for_job_time": {
				Type:       schema.TypeString,
				Optional:   true,
				Default:    "3s",
				Deprecated: "wait_for_job_time has been deprecated. Please use the alternate, status_check_retries_delay.",
			},
			"status_check_retries_delay": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "3s",
				Description: "Time to wait between calls to the API to check for completion status",
			},
			"artifact_data_type": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "yaml",
				Description: "yaml or json encoding of nested artifact maps",
				Deprecated:  "This don't do nothin' no more.",
			},
			"success_on_job_fail": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "When true job failures will be treated as the resource being successfully created",
			},
			"retries": {
				Type:        schema.TypeInt,
				Optional:    true,
				Default:     0,
				Description: "The number of times to attempt rerunning a job",
			},
			"retries_delay": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "60s",
				Description: "Time to wait between retries",
			},
			"branch_override": {
				Type:		 schema.TypeString,
				Optional:	 true,
				Default: 	 "",
				Description: "Source branch to launch with",
			},
			"changes": {
				Type:        schema.TypeInt,
				Computed:    true,
				Description: "The number of changes re-running the job template would make",
			},
			"skips": {
				Type:        schema.TypeInt,
				Computed:    true,
				Description: "The number of tasks that would skip when re-running the job template",
			},
			"artifact_data": {
				Type:        schema.TypeMap,
				Computed:    true,
				Description: "Artifact data collected from the playbook.",
			},
			"start_time": {
				Type:        schema.TypeString,
				Computed:    true,
				Description: "System time at the initial API call to start the job",
			},
			"end_time": {
				Type:        schema.TypeString,
				Computed:    true,
				Description: "System time at the completion of the job",
			},
		},
	}
}

func resourceJobRunCreate(d *schema.ResourceData, meta interface{}) error {
	if d.Id() != "" && d.Get("no_update").(bool) {
		return nil
	}

	endpoint := "job_templates/"
	postfix := "_create"

	id, _, err := getLaunchID(d, meta, d.Get("name").(string)+postfix, endpoint)

	if err != nil && d.Get("no_delete").(bool) {
		postfix = ""
		id, _, err = getLaunchID(d, meta, d.Get("name").(string)+postfix, endpoint)
	}

	if err != nil {
		return fmt.Errorf("job did not complete with error: %s", err)
	}
	
	retries_delay := d.Get("retries_delay").(string)
	if retries_delay == "" {
		retries_delay = "60s"
	}
	
	wait, err := time.ParseDuration(retries_delay) // seconds

	if err != nil {
		return fmt.Errorf("unable to parse duration: %s : %s", d.Get("retries_delay").(string), err)
	}

	err = fmt.Errorf("")

	for retries := d.Get("retries").(int) + 1; retries > 0 && err != nil; retries-- {
		if retries != d.Get("retries").(int)+1 {
			time.Sleep(wait)
		}
		_, err = sendRunRequest("create", "job", id, retries, d, meta)
	}

	if d.Get("success_on_job_fail").(bool) {
		return nil
	}

	return err
}

func resourceJobRunRead(d *schema.ResourceData, meta interface{}) error {
	if d.Get("no_update").(bool) {
		return nil
	}

	endpoint := "job_templates/"
	postfix := "_create"

	id, _, err := getLaunchID(d, meta, d.Get("name").(string)+postfix, endpoint)

	if err != nil && d.Get("no_delete").(bool) {
		postfix = ""
		id, _, err = getLaunchID(d, meta, d.Get("name").(string)+postfix, endpoint)
	}

	if err != nil {
		return fmt.Errorf("job did not complete with error: %s", err)
	}

	// Send the run request for check
	jobid, err := sendRunRequest("check", "job", id, 0, d, meta)

	changes, skips := 0, 0

	if err != nil {
		_, _ = d.Set("changes", changes+1), d.Set("skips", skips)
		return nil
	}

	// Wait for job to finish
	res, err := waitForJobCompletion(d, meta, "job", strconv.Itoa(jobid))
	if err != nil {
		changes++ // Any error in check results in a change necessary
	}

	if res["host_status_counts"] != nil {
		hostStatusCounts := res["host_status_counts"].(map[string]interface{})

		if hostStatusCounts["changed"] != nil {
			changes += int(hostStatusCounts["changed"].(float64))
		}
		if hostStatusCounts["skipped"] != nil {
			skips = int(hostStatusCounts["skipped"].(float64))
		}
	}

	if _, _ = d.Set("changes", changes), d.Set("skips", skips); changes == 0 {
		return nil
	}

	if !d.Get("success_on_job_fail").(bool) {
		d.SetId("")
		return fmt.Errorf("error refreshing state during read: %s", err)
	}

	log.Printf("WARNING: Running %s template - changes: %d, skips: %d, clearing ID", "job", changes, skips)

	return nil
}

func resourceJobRunUpdate(d *schema.ResourceData, meta interface{}) error {
	return resourceJobRunCreate(d, meta)
}

func resourceJobRunDelete(d *schema.ResourceData, meta interface{}) error {
	// If there is no delete template, exit right away
	if d.Get("no_delete").(bool) {
		return nil
	}

	// Delete template exists so get it's ID and run it
	endpoint := "job_templates/"
	id, _, err := getLaunchID(d, meta, d.Get("name").(string)+"_delete", endpoint)

	if err != nil {
		return fmt.Errorf("job did not complete with error: %s", err)
	}

	_, err = sendRunRequest("delete", "job", id, d.Get("retries").(int), d, meta)
	return err
}
