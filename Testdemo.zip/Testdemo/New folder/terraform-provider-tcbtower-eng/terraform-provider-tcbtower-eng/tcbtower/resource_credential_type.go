package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func resourceCredentialType() *schema.Resource {
	return &schema.Resource{
		Create: resourceCredentialTypeCreate,
		Read:   resourceCredentialTypeRead,
		Update: resourceCredentialTypeUpdate,
		Delete: resourceCredentialTypeDelete,
		Importer: &schema.ResourceImporter{
			State: resourceCredentialTypeImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"description": {
				Type:     schema.TypeString,
				Default:  "...",
				Optional: true,
			},
			"kind": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "cloud",
				Description: "Options are: cloud, net",
			},
			"namespace": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"inputs": {
				Type:     schema.TypeString,
				Required: true,
			},
			"injectors": {
				Type:     schema.TypeString,
				Required: true,
			},
		},
	}
}

func resourceCredentialTypeCreate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credential_types/"
	return credentialTypeEndpoint("POST", endpoint, d, meta)
}

func resourceCredentialTypeRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "credential_types/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating new request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	if _, err = BodyToMap(res.Body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	return nil
}

func resourceCredentialTypeUpdate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credential_types/" + d.Id() + "/"

	return credentialTypeEndpoint("PUT", endpoint, d, meta)
}

func resourceCredentialTypeDelete(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credential_types/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("DELETE", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}
	if res.StatusCode != http.StatusNoContent {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
			nil,
			res.Body,
		)
	}

	d.SetId("")

	return nil
}

func credentialTypeEndpoint(verb, endpoint string, d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	inputsMap, err := Unmarshal(d.Get("inputs").(string))
	if err != nil {
		return fmt.Errorf("argument error for inputs: %s", err)
	}
	injectorsMap, err := Unmarshal(d.Get("injectors").(string))
	if err != nil {
		return fmt.Errorf("argument error for injectors: %s", err)
	}

	reqBody, err := json.Marshal(map[string]interface{}{
		"name":        d.Get("name").(string),
		"description": d.Get("description").(string),
		"kind":        d.Get("kind").(string),
		"inputs":      inputsMap,
		"injectors":   injectorsMap,
	})

	if err != nil {
		return fmt.Errorf("error marshalling request body: %s", err)
	}

	client := config.Client(endpoint)
	req, err := http.NewRequest(verb, client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			reqBody,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	credTypeID := body["id"].(float64)
	d.SetId(strconv.Itoa(int(credTypeID)))

	return resourceCredentialTypeRead(d, meta)
}

func resourceCredentialTypeImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "credential_types/"

	name := d.Id()
	d.Set("name", name)

	credType, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching credential_type: %s", err)
	}

	d.SetId(strconv.Itoa(int(credType["id"].(float64))))

	d.Set("url", string(credType["url"].(string)))
	d.Set("credentialtype_id", int(credType["id"].(float64)))
	d.Set("created", string(credType["created"].(string)))
	d.Set("modified", string(credType["modified"].(string)))
	d.Set("kind", string(credType["kind"].(string)))
	d.Set("name", string(credType["name"].(string)))
	d.Set("description", string(credType["description"].(string)))
	d.Set("managed_by_tower", bool(credType["managed_by_tower"].(bool)))
	d.Set("namespace", string(credType["namespace"].(string)))

	return []*schema.ResourceData{d}, nil
}
