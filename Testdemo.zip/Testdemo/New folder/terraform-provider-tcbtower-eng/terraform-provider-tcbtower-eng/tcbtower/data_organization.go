package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataOrganization() *schema.Resource {
	return &schema.Resource{
		Read: dataOrganizationRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"type": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"url": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"created": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"modified": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"max_hosts": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"description": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"custom_virtualenv": {
				Type:     schema.TypeString,
				Computed: true,
			},
		},
	}
}

func dataOrganizationRead(d *schema.ResourceData, meta interface{}) error {
	endpoint := "organizations/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return fmt.Errorf("unable to retrieve organization with error: %s", err)
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	propertyList := []string{
		"type", "url", "created", "modified", "max_hosts", "description", "custom_virtualenv",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for organization, %s", err)
	}

	return nil
}
