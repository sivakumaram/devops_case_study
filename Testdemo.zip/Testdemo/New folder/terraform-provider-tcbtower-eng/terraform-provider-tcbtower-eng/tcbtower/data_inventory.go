package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataInventory() *schema.Resource {
	return &schema.Resource{
		Read: dataInventoryRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"organization_id": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"description": {
				Type:     schema.TypeString,
				Computed: true,
			},
		},
	}
}

func dataInventoryRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "inventories/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return fmt.Errorf("unable to retrieve entry with error: %s", err)
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	orgID, ok := res["organization"].(float64)
	if !ok {
		return fmt.Errorf("unable to access organization id in response body: %v", res)
	}

	if err = d.Set("organization_id", int(orgID)); err != nil {
		return fmt.Errorf("error setting the organization id for Inventory, %s", err)
	}

	propertyList := []string{
		"description",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for Inventory, %s", err)
	}

	return nil
}
