package tcbtower

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
	"gopkg.in/yaml.v3"
)

func resourceCredential() *schema.Resource {
	return &schema.Resource{
		Create: resourceCredentialCreate,
		Read:   resourceCredentialRead,
		Update: resourceCredentialUpdate,
		Delete: resourceCredentialDelete,
		Importer: &schema.ResourceImporter{
			State: resourceCredentialImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"type": {
				Type:     schema.TypeInt,
				Required: true,
			},
			"inputs": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "{}",
			},
			"sensitive_inputs": {
				Type:      schema.TypeString,
				Optional:  true,
				Sensitive: true,
				Default:   "{}",
			},
			"inputs_source": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "{}",
			},
			"description": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "...",
			},
			"organization": {
				Type:       schema.TypeString,
				Optional:   true,
				Default:    "",
				Deprecated: "This has been deprecated and will be removed in future releases. Use a data organization block to resolve name to ID.",
			},
			"organization_id": {
				Type:     schema.TypeInt,
				Optional: true,
			},
			"type_id": {
				Type:     schema.TypeInt,
				Computed: true,
			},
		},
	}
}

func resourceCredentialRead(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credentials/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	if _, err = BodyToMap(res.Body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	return nil
}

func resourceCredentialCreate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credentials/"
	return credentialEndpoint("POST", endpoint, d, meta)
}

func resourceCredentialUpdate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credentials/" + d.Id() + "/"
	return credentialEndpoint("PUT", endpoint, d, meta)
}

func resourceCredentialDelete(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credentials/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("DELETE", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}
	if res.StatusCode != http.StatusNoContent {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
			nil,
			res.Body,
		)
	}

	d.SetId("")

	return nil
}

func resourceCredentialImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "credentials/"

	name := d.Id()
	d.Set("name", name)

	cred, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching credential: %s", err)
	}

	d.SetId(strconv.Itoa(int(cred["id"].(float64))))

	d.Set("type_id", int(cred["credential_type"].(float64)))
	d.Set("credential_id", int(cred["id"].(float64)))
	d.Set("organization_id", int(cred["organization"].(float64)))

	return []*schema.ResourceData{d}, nil
}

func credentialEndpoint(verb, endpoint string, d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	if d.Get("inputs").(string) != "{}" && d.Get("sensitive_inputs").(string) != "{}" {
		return fmt.Errorf("argument error: both sensitive_inputs and inputs was supplied, can only use one")
	}

	inputs := "{}"

	if d.Get("inputs").(string) != "{}" {
		inputs = d.Get("inputs").(string)
	}

	if d.Get("sensitive_inputs").(string) != "{}" {
		inputs = d.Get("sensitive_inputs").(string)
	}

	inputsMap, err := Unmarshal(inputs)
	if err != nil {
		return fmt.Errorf("argument error for inputs: %s", err)
	}

	d.Set("type_id", d.Get("type").(int))

	orgID, err := resolveOrganization(d, meta, "OPTIONAL")
	if err != nil {
		return fmt.Errorf("failed resolving organization with error: %s", err)
	}

	rawBody := map[string]interface{}{
		"name":            d.Get("name").(string),
		"description":     d.Get("description").(string),
		"credential_type": d.Get("type_id").(int),
		"inputs":          inputsMap,
	}

	if orgID != -1 {
		rawBody["organization"] = orgID
	}

	reqBody, err := json.Marshal(rawBody)

	if err != nil {
		return fmt.Errorf("error marshaling request body: %s", err)
	}

	client := config.Client(endpoint)
	req, err := http.NewRequest(verb, client.url, bytes.NewBuffer(reqBody))

	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			reqBody,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	credID := int(body["id"].(float64))
	d.SetId(strconv.Itoa(credID))

	if err = deleteCredInputSources(credID, meta); err != nil {
		return fmt.Errorf("error removing existing input_sources during reset for %s: %s", verb, err)
	}

	// Setup secret backend
	if d.Get("inputs_source") != "{}" {
		var inputSourceMap []map[string]interface{}
		inputSource := d.Get("inputs_source").(string)
		if strings.ContainsAny(inputSource, "---") {
			err := yaml.Unmarshal([]byte(inputSource), &inputSourceMap)
			if err != nil {
				return fmt.Errorf("error parsing inputs_source argument as YAML (start YAML with '---' or JSON with 'jsonencode'): %s", err)
			}

		} else {
			err := json.Unmarshal([]byte(inputSource), &inputSourceMap)
			if err != nil {
				return fmt.Errorf("error parsing inputs_source argument as JSON (start YAML with '---' or JSON with 'jsonencode'): %s", err)
			}
		}

		err = setSourceMetadata(verb, inputSourceMap, credID, meta)
		if err != nil {
			return fmt.Errorf("error setting input source for credential: %s", err)
		}
	}

	return resourceCredentialRead(d, meta)
}

func setSourceMetadata(verb string, bodyList []map[string]interface{}, id int, meta interface{}) error {
	endpoint := "credentials/" + strconv.Itoa(id) + "/input_sources/"
	config := meta.(*Config)
	client := config.Client(endpoint)

	for i, body := range bodyList {

		reqBody, err := json.Marshal(body)

		if err != nil {
			return fmt.Errorf("error marshaling request body(%d): %s", i, err)
		}

		req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
		if err != nil {
			return fmt.Errorf("error creating request(%d): %s", i, err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return fmt.Errorf("error setting authorization headers(%d): %s", i, err)
		}

		req.Header.Set("Content-Type", "application/json")

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("http request(%d) failed with error: %s", i, err)
		}

		if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
			return ResponseError(
				fmt.Sprintf("call %d: ", i)+
					StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
				reqBody,
				res.Body,
			)
		}

		if _, err = BodyToMap(res.Body); err != nil {
			return fmt.Errorf("failed to parse response body of call %d with error %s", i, err)
		}

	}
	return nil
}

func getCredInputSources(id int, meta interface{}) ([]int, error) {
	endpoint := "credentials/" + strconv.Itoa(id) + "/input_sources/"
	config := meta.(*Config)
	client := config.Client(endpoint)

	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return nil, fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return nil, fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return nil, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse body with error %s", err)
	}

	if body["results"] != nil {
		sources, ok := body["results"].([]interface{})
		if ok {
			var sourceIDs []int
			for _, val := range sources {
				sourceIDs = append(sourceIDs, int(val.(map[string]interface{})["id"].(float64)))
			}
			return sourceIDs, nil
		}
	}
	return nil, errors.New("error: No results found in response body")

}

func deleteCredInputSources(id int, meta interface{}) error {
	deleteInputSource := func(sourceID int, meta interface{}) error {
		endpoint := "credential_input_sources/" + strconv.Itoa(sourceID) + "/"
		config := meta.(*Config)
		client := config.Client(endpoint)

		req, err := http.NewRequest("DELETE", client.url, nil)
		if err != nil {
			return fmt.Errorf("error creating request: %s", err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return fmt.Errorf("error setting authorization headers: %s", err)
		}
		req.Header.Set("Content-type", "application/json")

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("HTTP request failed with error: %s", err)
		}

		if !(res.StatusCode == http.StatusNoContent) {
			return ResponseError(
				StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
				nil,
				res.Body,
			)
		}

		return nil
	}

	sourceList, err := getCredInputSources(id, meta)

	if err != nil {
		return fmt.Errorf("error getting input_source list")
	}

	if len(sourceList) > 0 {
		for i, sourceID := range sourceList {
			err = deleteInputSource(sourceID, meta)
			if err != nil {
				return fmt.Errorf("error removing input source (ID: %d) with error: %s on loop %d", sourceID, err, i)
			}
		}
	}
	return nil
}
