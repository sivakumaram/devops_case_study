package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
	"gopkg.in/yaml.v3"
)

func resourceJobTemplate() *schema.Resource {
	return &schema.Resource{
		Create: resourceJobTemplateCreate,
		Read:   resourceJobTemplateRead,
		Update: resourceJobTemplateUpdate,
		Delete: resourceJobTemplateDelete,
		Importer: &schema.ResourceImporter{
			State: resourceJopTemplateImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:        schema.TypeString,
				Required:    true,
				Description: "The name of the Job Template you wish to create",
			},
			"project_id": {
				Type:        schema.TypeInt,
				Required:    true,
				Description: "The ID of the project linked to the template",
			},
			"playbook": {
				Type:        schema.TypeString,
				Required:    true,
				Description: "The playbook for this to run",
			},
			"implement_destroy": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Build create and destroy job templates. WARNING: setting this to false can break your infrastructure",
				Deprecated:  "This has been deprecated and will be removed in future releases. Use two resource blocks instead.",
			},
			"job_type": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "run",
				Description: "Default run behavior: run or check",
			},
			"extra_vars": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"job_tags": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"skip_tags": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"verbosity": {
				Type:        schema.TypeInt,
				Optional:    true,
				Default:     0,
				Description: "The verbosity of the job",
			},
			"become_enabled": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Whether to run the job as become",
			},
			"ask_inventory_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt inventory on launch",
			},
			"ask_credential_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt credential on launch",
			},
			"ask_variables_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt extra variables on launch",
			},
			"ask_job_type_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt job type (check, run) on launch. Refer to documentation for race condition warning.",
			},
			"ask_scm_branch_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt source branch on launch. Requires project to have branch override enabled",
			},
			"organization": {
				Type:       schema.TypeString,
				Optional:   true,
				Default:    "",
				Deprecated: "This has been deprecated and will be removed in future releases. Use a data organization block to resolve name to ID.",
			},
			"organization_id": {
				Type:     schema.TypeInt,
				Optional: true,
			},
			"template_create_id": {
				Type:        schema.TypeInt,
				Computed:    true,
				Default:     nil,
				Description: "Name of your create playbook",
				Deprecated:  "This has been deprecated and will be removed in future releases. Use two resource blocks.",
			},
			"template_delete_id": {
				Type:        schema.TypeInt,
				Computed:    true,
				Default:     nil,
				Description: "Name of your delete playbook",
				Deprecated:  "This has been deprecated and will be removed in future releases. Use two resource blocks.",
			},
			"credentials": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default:     nil,
				Description: "List of credential IDs",
			},
			"description": {
				Type:        schema.TypeString,
				Optional:    true,
				Description: "Description for the job template on Tower",
			},
			"enable_concurrent_jobs": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Allow jobs to run concurrently or not",
			},
			"inventory": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  -1,
			},
			"update_project_on_create": {
				Type:     schema.TypeBool,
				Optional: true,
				Default:  false,
			},
			"wait_for_jobless_retries": {
				Type:        schema.TypeInt,
				Optional:    true,
				Default:     60,
				Description: "Number of times to wait for a project to be jobless when doing an update for this job template.",
			},
			"wait_for_jobless_time": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "3s",
				Description: "Amount of time to wait for a project to be jobless when doing an update for this job template.",
			},
			"instance_groups": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default: nil,
			},
		},
	}
}

type sendJobTemplateData struct {
	method           string
	namePostfix      string
	urlPostfix       string
	sendBody         bool
	useURLPostfix    bool
	expectStatusCode int
	returnBody       bool
}

func resourceJobTemplateSendData(d *schema.ResourceData, meta interface{}, data sendJobTemplateData) (int, error) {
	if !data.useURLPostfix {
		data.urlPostfix = ""
	}

	endpoint := "job_templates/" + data.urlPostfix
	config := meta.(*Config)

	orgID, err := resolveOrganization(d, meta, "REQUIRED")
	if err != nil {
		return -1, fmt.Errorf("failed resolving organization with error: %s", err)
	}

	// Update project if POST and update_project_on_create
	if data.method == "POST" && d.Get("update_project_on_create").(bool) {
		if err = projectUpdateSource(meta, strconv.Itoa(d.Get("project_id").(int))); err != nil {
			return -1, fmt.Errorf("error updating project: %s", err)
		}

		if err = projectWaitForJobless(strconv.Itoa(d.Get("project_id").(int)), d, meta); err != nil {
			return -1, fmt.Errorf("error waiting for project to update: %s", err)
		}
	}

	var rawBody map[string]interface{}

	if data.sendBody { // This is always set to true
		// BEGIN All sorts of work to confirm the extra vars are valid
		_extra_vars := d.Get("extra_vars").(string)

		extra_vars := new(map[string]interface{})

		if err := yaml.Unmarshal([]byte(_extra_vars), extra_vars); err != nil {
			return -1, fmt.Errorf("argument error for extra_vars: %s", err)
		}

		extraVars, err := json.Marshal(extra_vars)

		if err != nil {
			return -1, fmt.Errorf("unable to remarshal extra_vars with error: %s", err)
		}

		rawBody = map[string]interface{}{
			"name":                     d.Get("name").(string) + data.namePostfix,
			"description":              d.Get("description").(string),
			"organization":             orgID,
			"project":                  d.Get("project_id").(int),
			"playbook":                 d.Get("playbook").(string) + data.namePostfix + ".yml",
			"job_type":                 d.Get("job_type").(string),
			"job_tags":                 d.Get("job_tags").(string),
			"skip_tags":                d.Get("skip_tags").(string),
			"verbosity":                d.Get("verbosity").(int),
			"ask_inventory_on_launch":  d.Get("ask_inventory_on_launch").(bool),
			"ask_credential_on_launch": d.Get("ask_credential_on_launch").(bool),
			"ask_variables_on_launch":  d.Get("ask_variables_on_launch").(bool),
			"ask_scm_branch_on_launch": d.Get("ask_scm_branch_on_launch").(bool),
			"become_enabled":           d.Get("become_enabled").(bool),
			"allow_simultaneous":       d.Get("enable_concurrent_jobs").(bool),
			"ask_job_type_on_launch":   d.Get("ask_job_type_on_launch").(bool),
			"inventory":                d.Get("inventory").(int),
			"extra_vars":               string(extraVars),
		}
	}

	reqBody, err := MarshalNoNil(rawBody)
	if err != nil {
		return -1, fmt.Errorf("error marshaling request body: %s", err)
	}

	client := config.Client(endpoint)
	req, err := http.NewRequest(data.method, client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return -1, fmt.Errorf("error creating new request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return -1, fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return -1, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != data.expectStatusCode {
		if res.StatusCode == http.StatusNotFound && data.method == "GET" {
			d.SetId("")
			return -1, nil
		}
		return -1, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, data.expectStatusCode),
			reqBody,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil && data.returnBody {
		return -1, fmt.Errorf("failed to parse body with error %s", err)
	}

	jobTemplateID := -1
	if body != nil {
		jobTemplateID = int(body["id"].(float64))
	}

	if d.Get("credentials") != nil {
		credList := d.Get("credentials").([]interface{})
		if len(credList) > 0 {
			if err = detachCredentialList(jobTemplateID, meta); err != nil {
				return jobTemplateID, fmt.Errorf("error when trying to dettach the \"%s\" credential list: %s", data.namePostfix, err)
			}

			if err = setCredentialList(credList, jobTemplateID, meta); err != nil {
				return jobTemplateID, fmt.Errorf("error when trying to update the \"%s\" credential list: %s", data.namePostfix, err)
			}
		}
	}

	if d.Get("instance_groups") == nil {
		return jobTemplateID, nil
	}

	igs, err := GetAllResourceIGs("job_templates/", jobTemplateID, meta)
	// Check if instance_groups exist already
	if len(igs) > 0 {
		// Remove instance groups
		if err != nil {
			return jobTemplateID, fmt.Errorf("error getting the \"%s\" instance groups: %s", data.namePostfix, err)
		}
		for i, val := range igs {
			ig := int(val.(map[string]interface{})["id"].(float64))
			if err = RemoveIGfromResource("job_templates/", jobTemplateID, meta, ig); err != nil {
				return jobTemplateID, fmt.Errorf("error removing the \"%s\" instance group %d: %s on loop %d", data.namePostfix, ig, err, i)
			}
		}
	}

	// Add all instance groups to inventory
	if err = AddIGstoResource("job_templates/", jobTemplateID, d.Get("instance_groups"), meta); err != nil {
		return jobTemplateID, fmt.Errorf("error adding the \"%s\" instance group: %s", data.namePostfix, err)
	}

	return jobTemplateID, nil
}

func asCreateDelete(d *schema.ResourceData, meta interface{}, data sendJobTemplateData) (int, int, error) {
	var returnArr []int

	if d.Get("implement_destroy").(bool) {
		postfixes := []string{"_create", "_delete"}
		for _, postfix := range postfixes {
			tempData := data
			tempData.namePostfix = postfix
			tempData.urlPostfix = strconv.Itoa(d.Get("template"+postfix+"_id").(int)) + "/"
			id, err := resourceJobTemplateSendData(d, meta, tempData)
			if err != nil {
				return -1, -1, fmt.Errorf("error at playbook%s; error is: %s", postfix, err)
			}

			returnArr = append(returnArr, id)
		}
	} else {
		data.urlPostfix = d.Id() + "/"
		id, err := resourceJobTemplateSendData(d, meta, data)
		if err != nil {
			return -1, -1, err
		}
		returnArr = append(returnArr, id, -1)
	}

	return returnArr[0], returnArr[1], nil
}

func resourceJobTemplateCreate(d *schema.ResourceData, meta interface{}) error {
	postSendData := sendJobTemplateData{
		method:           "POST",
		namePostfix:      "",
		urlPostfix:       "",
		sendBody:         true,
		useURLPostfix:    false,
		expectStatusCode: http.StatusCreated,
		returnBody:       true,
	}

	createID, deleteID, err := asCreateDelete(d, meta, postSendData)
	if err != nil {
		return fmt.Errorf("creation failed with error: %s", err)
	}

	d.Set("template_create_id", createID)
	d.Set("template_delete_id", deleteID)

	d.SetId(strconv.Itoa(createID))

	return resourceJobTemplateRead(d, meta)
}

func resourceJobTemplateUpdate(d *schema.ResourceData, meta interface{}) error {
	postSendData := sendJobTemplateData{
		method:           "PUT",
		namePostfix:      "",
		urlPostfix:       "",
		sendBody:         true,
		useURLPostfix:    true,
		expectStatusCode: http.StatusOK,
		returnBody:       true,
	}

	createID, deleteID, err := asCreateDelete(d, meta, postSendData)
	if err != nil {
		return fmt.Errorf("update failed with error: %s", err)
	}

	d.Set("template_create_id", createID)
	d.Set("template_delete_id", deleteID)

	d.SetId(strconv.Itoa(createID))

	return resourceJobTemplateRead(d, meta)
}

func resourceJobTemplateRead(d *schema.ResourceData, meta interface{}) error {
	getSendData := sendJobTemplateData{
		method:           "GET",
		namePostfix:      "",
		urlPostfix:       "",
		sendBody:         true,
		useURLPostfix:    true,
		expectStatusCode: http.StatusOK,
		returnBody:       true,
	}

	_, deleteID, err := asCreateDelete(d, meta, getSendData)
	if err != nil {
		return fmt.Errorf("read failed with error: %s", err)
	}

	if deleteID != d.Get("template_delete_id").(int) && d.Get("implement_destroy").(bool) {
		return fmt.Errorf("id mismatch for playbook_delete; expected: %d, got: %d", d.Get("template_delete_id").(int), deleteID)
	}

	return nil
}

// XXX: This function seems to be broken.
func resourceJobTemplateDelete(d *schema.ResourceData, meta interface{}) error {
	type _template struct {
		id   string
		name string
	}

	templates := []_template{
		{
			id:   d.Id(),
			name: "root",
		},
	}
	for _, name := range []string{"create", "delete"} {
		if id, ok := d.Get(fmt.Sprintf("template_%[1]s_id", name)).(int); ok {
			templates = append(templates, _template{id: fmt.Sprint(id), name: name})
		}
	}

	for _, template := range templates {

		endpoint := "job_templates/" + template.id + "/"
		config := meta.(*Config)

		client := config.Client(endpoint)
		req, err := http.NewRequest("DELETE", client.url, nil)
		if err != nil {
			return fmt.Errorf("delete failed with error creating request for %s_template: %s", template.name, err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return fmt.Errorf("delete failed with error setting authorization headers for %s_template: %s", template.name, err)
		}

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("HTTP request failed with error: %s", err)
		}

		if res.StatusCode != http.StatusNoContent { // XXX: Ignoring the response is probably sloppy but atm it is a future problem
			err = ResponseError(
				StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent)+
					fmt.Sprintf("TemplateID: %s", template.id),
				nil,
				res.Body,
			)
			log.Printf("WARNING: error ignored: %s", err)
		}

		if template.name == "root" {
			d.SetId("")
		} else {
			d.Set(fmt.Sprintf("template_%[1]s_id", template.name), "")
		}

	}

	return nil
}

func setCredentialList(credList []interface{}, ID int, meta interface{}) error {
	endpoint := "job_templates/" + strconv.Itoa(ID) + "/credentials/"
	config := meta.(*Config)
	client := config.Client(endpoint)

	for i, cred := range credList {
		IDbody := make(map[string]interface{})
		IDbody["id"] = cred.(int)

		reqBody, err := json.Marshal(IDbody)

		if err != nil {
			return fmt.Errorf("error marshaling request body(%d): %s", i, err)
		}

		req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
		if err != nil {
			return fmt.Errorf("error creating request(%d): %s", i, err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return fmt.Errorf("error setting authorization headers(%d): %s", i, err)
		}

		req.Header.Set("Content-Type", "application/json")

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("HTTP request(%d) failed with error: %s", i, err)
		}

		if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusNoContent || res.StatusCode == http.StatusBadRequest) {
			return ResponseError(
				fmt.Sprintf("call %d: ", i)+
					StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusNoContent, http.StatusBadRequest),
				reqBody,
				res.Body,
			)
		}

		if _, err = BodyToMap(res.Body); err != nil && !strings.ContainsAny(err.Error(), "EOF") {
			return fmt.Errorf("failed to parse body of call %d with error %s", i, err)
		}

	}
	return nil
}

func getCurrentCredentialList(ID int, meta interface{}) ([]interface{}, error) {
	endpoint := "job_templates/" + strconv.Itoa(ID) + "/credentials/"
	config := meta.(*Config)
	client := config.Client(endpoint)

	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return nil, fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return nil, fmt.Errorf("error setting authorization headers: %s", err)
	}

	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return nil, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			nil,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse body with error %s", err)
	}

	results := body["results"].([]interface{})
	if len(results) == 0 {
		return nil, nil //Don't need to update
	}

	var credList []interface{}
	for _, credBody := range results {

		if subBody, ok := credBody.(map[string]interface{}); credBody != nil && ok {
			credList = append(credList, subBody["id"])
		}

	}

	return credList, nil
}

func detachCredentialList(ID int, meta interface{}) error {

	endpoint := "job_templates/" + strconv.Itoa(ID) + "/credentials/"
	config := meta.(*Config)
	client := config.Client(endpoint)

	credList, err := getCurrentCredentialList(ID, meta)

	if err != nil || credList == nil {
		return err
	}

	for i, cred := range credList {
		reqBody, err := json.Marshal(map[string]interface{}{
			"id":           cred,
			"disassociate": true,
		})

		if err != nil {
			return fmt.Errorf("error marshaling request body(%d): %s", i, err)
		}

		req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
		if err != nil {
			return fmt.Errorf("error creating request(%d): %s", i, err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return fmt.Errorf("error setting authorization headers(%d): %s", i, err)
		}

		req.Header.Set("Content-Type", "application/json")

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("http request(%d) failed with error: %s", i, err)
		}

		if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusNoContent || res.StatusCode == http.StatusBadRequest) {
			return ResponseError(
				fmt.Sprintf("call %d: ", i)+
					StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusNoContent, http.StatusBadRequest),
				reqBody,
				res.Body,
			)
		}

		if _, err = BodyToMap(res.Body); err != nil && !strings.ContainsAny(err.Error(), "EOF") {
			return fmt.Errorf("failed to parse body of call %d with error %s", i, err)
		}

	}
	return nil
}

func resourceJopTemplateImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "job_templates/" + d.Id() + "/"

	name := d.Id()
	d.Set("name", name)

	jobTemplate, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching job template: %s", err)
	}

	d.SetId(strconv.Itoa(int(jobTemplate["id"].(float64))))

	d.Set("url", string(jobTemplate["url"].(string)))
	d.Set("jobTemplate_id", int(jobTemplate["id"].(float64)))
	d.Set("created", string(jobTemplate["created"].(string)))
	d.Set("modified", string(jobTemplate["modified"].(string)))
	d.Set("name", string(jobTemplate["name"].(string)))
	d.Set("description", string(jobTemplate["description"].(string)))
	d.Set("job_type", string(jobTemplate["job_type"].(string)))
	d.Set("inventory_id", int(jobTemplate["inventory"].(float64)))
	d.Set("project_id", int(jobTemplate["project"].(float64)))
	d.Set("playbook", string(jobTemplate["playbook"].(string)))
	d.Set("scm_branch", string(jobTemplate["scm_branch"].(string)))
	d.Set("organization_id", int(jobTemplate["organization"].(float64)))
	d.Set("status", string(jobTemplate["status"].(string)))
	d.Set("ask_inventory_on_launch", bool(jobTemplate["ask_inventory_on_launch"].(bool)))
	d.Set("ask_credential_on_launch", bool(jobTemplate["ask_credential_on_launch"].(bool)))
	d.Set("ask_variables_on_launch", bool(jobTemplate["ask_variables_on_launch"].(bool)))
	d.Set("become_enabled", bool(jobTemplate["become_enabled"].(bool)))

	return []*schema.ResourceData{d}, nil
}
