package tcbtower

import (
	"crypto/tls"
	"fmt"
	"net/http"
	"time"
)

// Config structure for the provider
type Config struct {
	towerHost          string
	towerUser          string
	towerPassword      string
	towerToken         string
	connectionTimeout  int
	allowUnverifiedSSL bool
}

// TowerClient is the main interface with the Tower API
type TowerClient struct {
	config *Config
	url    string
	client *http.Client
}

// Client configures and returns a fully initialized TowerClient
func (c *Config) Client(endpoint string) TowerClient {
	hclient := http.Client{
		Transport: c.setTransport(),
		Timeout:   time.Second * time.Duration(c.connectionTimeout),
	}
	client := TowerClient{
		config: c,
		url:    c.towerHost + endpoint,
		client: &hclient,
	}
	return client
} 

//Set transport against SSL check option
func (c *Config) setTransport() *http.Transport {
	transport := &http.Transport{
		Proxy:                  nil,
		DialContext:            nil,
		DialTLS:                nil,
		TLSClientConfig:        &tls.Config{InsecureSkipVerify: c.allowUnverifiedSSL},
		TLSHandshakeTimeout:    0,
		DisableKeepAlives:      false,
		DisableCompression:     false,
		MaxIdleConns:           0,
		MaxIdleConnsPerHost:    0,
		MaxConnsPerHost:        0,
		IdleConnTimeout:        0,
		ResponseHeaderTimeout:  0,
		ExpectContinueTimeout:  0,
		TLSNextProto:           nil,
		ProxyConnectHeader:     nil,
		MaxResponseHeaderBytes: 0,
		WriteBufferSize:        0,
		ReadBufferSize:         0,
		ForceAttemptHTTP2:      false,
	}
	return transport
}

func setAuthHeader(meta interface{}, req *http.Request) error {
	config := meta.(*Config)
	if len(config.towerUser) > 0 && len(config.towerPassword) > 0 {
		req.SetBasicAuth(config.towerUser, config.towerPassword)
		return nil
	} else if len(config.towerToken) > 0 {
		req.Header.Add("Authorization", "Bearer "+config.towerToken)
		return nil
	}
	return fmt.Errorf("must provide either a username and password or a token for Ansible Tower")
}
