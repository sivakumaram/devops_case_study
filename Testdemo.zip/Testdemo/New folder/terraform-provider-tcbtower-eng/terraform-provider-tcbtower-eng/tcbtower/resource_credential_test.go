package tcbtower

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const credentialTestEndpoint string = "credentials/"

func TestAccCredentialResource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_credential_type" "dependency" {
					name = "tf-acc-test-credential-type-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}
				
				resource "tower_credential" "test" {
					name = "tf-acc-test-%[1]s"
					type = tower_credential_type.dependency.id
					organization_id = tower_organization.dependency.id
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_credential.test", "type", "tower_credential_type.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_credential.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCheckResourceExists(
					credentialTestEndpoint, "tower_credential.test",
				),
			)
			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(credentialTestEndpoint, "tower_credential", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_credential_type" "dependency" {
					name = "tf-acc-test-credential-type-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}
				
				resource "tower_credential" "test" {
					name = "tf-acc-test-%[1]s"
					type = tower_credential_type.dependency.id
					organization_id = tower_organization.dependency.id
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_credential.test", "type", "tower_credential_type.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_credential.test", "organization_id", "tower_organization.dependency", "id",
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_credential_type" "dependency" {
					name = "tf-acc-test-credential-type-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}
				
				resource "tower_credential" "test" {
					name = "tf-acc-test-%[1]s"
					type = tower_credential_type.dependency.id
					organization_id = tower_organization.dependency.id

					inputs = "{}"
				}`, randomID)

			updateConfig := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_organization" "update_dependency" {
					name = "tf-acc-test-organization-update-%[1]s"
				}

				resource "tower_credential_type" "dependency" {
					name = "tf-acc-test-credential-type-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}

				resource "tower_credential_type" "update_dependency" {
					name = "tf-acc-test-credential-type-update-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}
				
				resource "tower_credential" "test" {
					name = "tf-acc-test-update-%[1]s"
					type = tower_credential_type.update_dependency.id
					organization_id = tower_organization.update_dependency.id

					sensitive_inputs = "{}"
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_credential.test", "type", "tower_credential_type.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_credential.test", "organization_id", "tower_organization.dependency", "id",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential.test", "name", fmt.Sprintf("tf-acc-test-update-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_credential.test", "type", "tower_credential_type.update_dependency", "id",
				),
				testAccCompareAttributes(
					"tower_credential.test", "organization_id", "tower_organization.update_dependency", "id",
				),
			)
			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

}
