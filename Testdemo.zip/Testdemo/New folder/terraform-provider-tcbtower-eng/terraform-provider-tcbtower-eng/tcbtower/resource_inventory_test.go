package tcbtower

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const inventoryTestEndpoint string = "inventories/"

func TestAccInventoryResource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_inventory" "test" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_inventory.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization", "tower_organization.dependency", "name",
				),
				testAccCheckResourceExists(
					inventoryTestEndpoint, "tower_inventory.test",
				),
			)
			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(inventoryTestEndpoint, "tower_inventory", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_inventory" "test" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_inventory.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization", "tower_organization.dependency", "name",
				),
				testAccCheckResourceExists(
					inventoryTestEndpoint, "tower_inventory.test",
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_inventory" "test" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}`, randomID)

			updateConfig := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_organization" "update_dependency" {
					name = "tf-acc-test-update-%[1]s"
				}

				resource "tower_inventory" "test" {
					name = "tf-acc-test-update-%[1]s"
					organization_id = tower_organization.update_dependency.id
					organization = tower_organization.update_dependency.name
					variables = jsonencode({"fields":[{"id":"token","label":"none"}]})
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_inventory.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization", "tower_organization.dependency", "name",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_inventory.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-update-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization_id", "tower_organization.update_dependency", "id",
				),
				testAccCompareAttributes(
					"tower_inventory.test", "organization", "tower_organization.update_dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_inventory.test", "variables", `{"fields":[{"id":"token","label":"none"}]}`,
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

	t.Run("instance_group", func(t *testing.T) {
		t.Run("add", func(t *testing.T) {
			t.Run("single", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
		
					resource "tower_instance_group" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						instance_groups = [tower_instance_group.dependency.id]
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "1",
					),
				)

				testCase(t, config, check)
			})

			t.Run("all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_instance_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "3",
					),
				)

				testCase(t, config, check)
			})

			t.Run("single_to_all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_instance_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
				}

				resource "tower_instance_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
				}

				resource "tower_inventory" "test" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id]
				}`, randomID)

				updateConfig := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_instance_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
				}

				resource "tower_instance_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
				}

				resource "tower_instance_group" "dependency3" {
					name = "tf-acc-test-%[1]s-3"
				}


				resource "tower_inventory" "test" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]
				}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "2",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "3",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})
		})

		t.Run("remove", func(t *testing.T) {
			t.Run("single", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
		
					resource "tower_instance_group" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						instance_groups = [tower_instance_group.dependency.id]
					}`, randomID)

				updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "1",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "0",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})

			t.Run("all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
		
					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_instance_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]
					}`, randomID)

				updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "3",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "0",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})

			t.Run("single_from_all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
		
					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_instance_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]
					}`, randomID)

				updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
		
					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_inventory" "test" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id]
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "3",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_inventory.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization_id", "tower_organization.dependency", "id",
					),
					testAccCompareAttributes(
						"tower_inventory.test", "organization", "tower_organization.dependency", "name",
					),
					resource.TestCheckResourceAttr(
						"tower_inventory.test", "instance_groups.#", "2",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})
		})
	})

}
