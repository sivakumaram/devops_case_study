package tcbtower

// XXX: I am super suspicious about this resource

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func resourceHost() *schema.Resource {
	return &schema.Resource{
		Create: resourceHostCreate,
		Read:   resourceHostRead,
		Update: resourceHostUpdate,
		Delete: resourceHostDelete,
		Importer: &schema.ResourceImporter{
			State: resourceHostImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"inventory": {
				Type:        schema.TypeInt,
				Description: "Note that this is immutable.",
				Required:    true,
			},
			"groups": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default: nil,
			},
			"description": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"variables": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"enabled": {
				Type:     schema.TypeBool,
				Optional: true,
				Default:  true,
			},
		},
	}
}

func resourceHostCreate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "inventories/" + strconv.Itoa(d.Get("inventory").(int)) + "/hosts/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	reqBody, err := json.Marshal(map[string]interface{}{
		"name":        d.Get("name").(string),
		"description": d.Get("description").(string),
		"variables":   d.Get("variables").(string),
		"enabled":     d.Get("enabled").(bool),
	})
	if err != nil {
		return fmt.Errorf("failed to marshal request body with error: %s", err)
	}

	req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to post new host with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			reqBody,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	hostID := int(body["id"].(float64))
	d.SetId(strconv.Itoa(hostID))

	if err = addHostToAllGroups(d, meta); err != nil {
		return fmt.Errorf("failed to add to all groups with error %s", err)
	}

	return resourceHostRead(d, meta)
}

func resourceHostRead(d *schema.ResourceData, meta interface{}) error {
	endpoint := "inventories/" + strconv.Itoa(d.Get("inventory").(int)) + "/hosts/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating new request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	q := req.URL.Query()
	q.Add("search", d.Get("name").(string))
	req.URL.RawQuery = q.Encode()

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	count, ok := body["count"].(float64)
	if body["count"] == nil || !ok {
		return errors.New("unrecognized query response: no count in body")
	}

	if count < 1 {
		d.SetId("")
	}

	return nil
}

func resourceHostDelete(d *schema.ResourceData, meta interface{}) error {
	endpoint := "inventories/" + strconv.Itoa(d.Get("inventory").(int)) + "/hosts/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	id, err := strconv.Atoi(d.Id())
	if err != nil {
		return fmt.Errorf("error converting id to string: %s", err)
	}
	reqBody, err := json.Marshal(map[string]interface{}{
		"id":           id,
		"disassociate": true,
	})
	if err != nil {
		return fmt.Errorf("error marshalling body")
	}
	req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusNoContent {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
			reqBody,
			res.Body,
		)
	}

	d.SetId("")

	return nil
}

func resourceHostUpdate(d *schema.ResourceData, meta interface{}) error {
	// TO-DO: support updating group id(s)
	endpoint := "hosts/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	reqBody, err := json.Marshal(map[string]interface{}{
		"name":        d.Get("name").(string),
		"description": d.Get("description").(string),
		"inventory":   strconv.Itoa(d.Get("inventory").(int)),
		"enabled":     d.Get("enabled").(bool),
		"variables":   d.Get("variables").(string),
	})
	if err != nil {
		return fmt.Errorf("failed to marshal req body with error: %s", err)
	}

	req, err := http.NewRequest("PUT", client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to update host with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			reqBody,
			res.Body,
		)
	}

	// Update groups
	groups, err := getAllGroups(d, meta)
	if err != nil {
		return fmt.Errorf("error getting groups: %s", err)
	}
	for i := 0; i < len(groups); i++ {
		group := int(groups[i].(map[string]interface{})["id"].(float64))
		err = removeHostFromGroup(d, meta, group)
		if err != nil {
			return fmt.Errorf("error removing group: %d with error: %s", group, err)
		}
	}

	if err = addHostToAllGroups(d, meta); err != nil {
		return fmt.Errorf("error adding host to group: %s", err)
	}

	return resourceHostRead(d, meta)
}

func getAllGroups(d *schema.ResourceData, meta interface{}) ([]interface{}, error) {
	endpoint := "hosts/" + d.Id() + "/all_groups/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return nil, fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return nil, fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return nil, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to parse body with error %s", err)
	}

	return body["results"].([]interface{}), nil
}

func addHostToAllGroups(d *schema.ResourceData, meta interface{}) error {
	if d.Get("groups") == nil {
		return nil
	}

	arr := d.Get("groups").([]interface{})
	for i := 0; i < len(arr); i++ {
		if err := addHostToGroup(d, meta, arr[i].(int)); err != nil {
			return fmt.Errorf("error adding host: %d to group: %s", arr[i].(int), err)
		}
	}

	return nil
}

func addHostToGroup(d *schema.ResourceData, meta interface{}, group int) error {
	// TO-DO: support list of group ids
	endpoint := "hosts/" + d.Id() + "/groups/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	reqBody, err := json.Marshal(map[string]interface{}{
		"id": group,
	})
	if err != nil {
		return fmt.Errorf("err marsheling json body: %s", err)
	}

	req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to post new host with error: %s", err)
	}

	if !(res.StatusCode == http.StatusCreated || res.StatusCode == http.StatusNoContent) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusCreated, http.StatusNoContent),
			reqBody,
			res.Body,
		)
	}

	return nil
}

func removeHostFromGroup(d *schema.ResourceData, meta interface{}, group int) error {
	config := meta.(*Config)
	client := config.Client("hosts/" + d.Id() + "/groups/")
	reqBody, err := json.Marshal(map[string]interface{}{
		"id":           group,
		"disassociate": true,
	})
	if err != nil {
		return fmt.Errorf("error marshalling body")
	}
	req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-type", "application/json")

	if _, err = client.client.Do(req); err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	return nil
}

func resourceHostImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "hosts/" + d.Id() + "/"

	name := d.Id()
	d.Set("name", name)

	host, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching host: %s", err)
	}

	d.SetId(strconv.Itoa(int(host["id"].(float64))))

	d.Set("url", string(host["url"].(string)))
	d.Set("host_id", int(host["id"].(float64)))
	d.Set("created", string(host["created"].(string)))
	d.Set("modified", string(host["modified"].(string)))
	d.Set("name", string(host["name"].(string)))
	d.Set("description", string(host["description"].(string)))
	d.Set("type", string(host["type"].(string)))
	d.Set("host_instance_id", int(host["instance_id"].(float64)))
	d.Set("enabled", bool(host["enabled"].(bool)))

	return []*schema.ResourceData{d}, nil
}
