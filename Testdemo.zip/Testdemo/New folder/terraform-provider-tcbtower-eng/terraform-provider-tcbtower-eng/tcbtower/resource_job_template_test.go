package tcbtower

import (
	"fmt"
	"os"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const JobTemplateTestEndpoint string = "job_templates/"

var extra_vars string = `---
this: is
an: extra_var

`

func TestAccJobTemplateResource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
					extra_vars = <<EOF%[3]sEOF
					job_tags = "these, are, tags"
					skip_tags = "these, are, tags"
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"), "\n"+extra_vars)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "extra_vars", extra_vars,
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "skip_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				testAccCheckResourceExists(
					JobTemplateTestEndpoint, "tower_job_template.test",
				),
			)
			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(JobTemplateTestEndpoint, "tower_job_template", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
					job_tags = "these, are, tags"
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			updateConfig := fmt.Sprintf(`
			resource "tower_organization" "update_dependency" {
				name = "tf-acc-test-update-%[1]s"
			}

			resource "tower_project" "update_dependency" {
				name = "tf-acc-test-update-%[1]s"
				organization_id = tower_organization.update_dependency.id
				organization = tower_organization.update_dependency.name

				scm_type = "git"
				scm_url = "%[2]s"
			}

			resource "tower_job_template" "test" {
				name = "tf-acc-test-update-%[1]s"
				project_id = tower_project.update_dependency.id
				organization_id = tower_organization.update_dependency.id
				organization = tower_organization.update_dependency.name
				playbook = "main"
				extra_vars = <<EOF%[3]sEOF
			}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"), "\n"+extra_vars)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-update-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "extra_vars", extra_vars,
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.update_dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.update_dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.update_dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

	t.Run("add", func(t *testing.T) {
		t.Run("single", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_instance_group" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
	
						scm_type = "git"
						scm_url = "%[2]s"
					}
	
					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
						instance_groups = [tower_instance_group.dependency.id]
					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "1",
				),
			)

			testCase(t, config, check)
		})

		t.Run("all", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
					
					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_instance_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
					}
	
					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
	
						scm_type = "git"
						scm_url = "%[2]s"
					}
	
					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]

					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "3",
				),
			)

			testCase(t, config, check)
		})

		t.Run("single_to_all", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}
				
				resource "tower_instance_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
				}

				resource "tower_instance_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
					job_tags = "these, are, tags"
					instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id]

				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			updateConfig := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}
			
				resource "tower_instance_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
				}

				resource "tower_instance_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
				}

				resource "tower_instance_group" "dependency3" {
					name = "tf-acc-test-%[1]s-3"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "test" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
					job_tags = "these, are, tags"
					instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]

				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "2",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "3",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

	t.Run("remove", func(t *testing.T) {
		t.Run("single", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
			
					resource "tower_instance_group" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
	
						scm_type = "git"
						scm_url = "%[2]s"
					}
	
					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
						instance_groups = [tower_instance_group.dependency.id]
	
					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
					
					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name

						scm_type = "git"
						scm_url = "%[2]s"
					}

					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "1",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "0",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})

		t.Run("all", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
					
					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_instance_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
					}

					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
	
						scm_type = "git"
						scm_url = "%[2]s"
					}
	
					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]
	
					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}

					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name

						scm_type = "git"
						scm_url = "%[2]s"
					}

					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "3",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "0",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})

		t.Run("single_from_all", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
			
					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_instance_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
					}

					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
	
						scm_type = "git"
						scm_url = "%[2]s"
					}
	
					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id, tower_instance_group.dependency3.id]
					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-%[1]s"
					}
			
					resource "tower_instance_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
					}

					resource "tower_instance_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
					}

					resource "tower_project" "dependency" {
						name = "tf-acc-test-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
	
						scm_type = "git"
						scm_url = "%[2]s"
					}
	
					resource "tower_job_template" "test" {
						name = "tf-acc-test-%[1]s"
						project_id = tower_project.dependency.id
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
						playbook = "main"
						job_tags = "these, are, tags"
						instance_groups = [tower_instance_group.dependency1.id, tower_instance_group.dependency2.id]
					}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "3",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_job_template.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "job_tags", "these, are, tags",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "project_id", "tower_project.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization_id", "tower_organization.dependency", "id",
				),
				testAccCompareAttributes(
					"tower_job_template.test", "organization", "tower_organization.dependency", "name",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "playbook", "main",
				),
				resource.TestCheckResourceAttr(
					"tower_job_template.test", "instance_groups.#", "2",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

}
