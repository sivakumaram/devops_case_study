package tcbtower

import (
	"fmt"
	"os"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

func TestAccScheduleDataSource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)
	t.Run("basic", func(t *testing.T) {
		config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "dependency" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					inventory = tower_inventory.dependency.id
					playbook = "main"
				}

				resource "tower_schedule" "dependency" {
					name = "tf-acc-test-%[1]s"
					rrule = "DTSTART;TZID=America/Denver:20200214T171700 RRULE:FREQ=DAILY;INTERVAL=1;COUNT=1"
					unified_job_template = tower_job_template.dependency.id
				}

				data "tower_schedule" "test" {
					name = tower_schedule.dependency.name
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

		check := resource.ComposeAggregateTestCheckFunc(
			resource.TestCheckResourceAttrSet(
				"data.tower_schedule.test", "id",
			),
			resource.TestCheckResourceAttr(
				"data.tower_schedule.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
			),
		)

		testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
			resource.Test(t, resource.TestCase{
				PreCheck:  func() { TestAccProjectPreCheck(t) },
				Providers: testAccProviders,
				Steps: []resource.TestStep{
					{
						Config: config,
						Check:  check,
					},
				},
			})
		}

		t.Run("id_from_name", func(t *testing.T) {
			testCase(t, config, check)
		})
	})

}
