package tcbtower

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"strings"

	"time"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

// getLaunchID XXX: consider rename
// desc: Get the job template id from the name given
// takes:
//   - *schema.ResourceData: the resource schema of type resource job run
//	 - interface{}: configuration of resource
//	 - string: name of the job template
// returns:
//	 - int: id of the job if no error
//	 - error: if an error occurred
func getLaunchID(d *schema.ResourceData, meta interface{}, name string, endpoint string) (int, map[string]interface{}, error) {
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)

	if err != nil {
		return -1, nil, fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return -1, nil, fmt.Errorf("error setting authorization headers: %s", err)
	}

	q := req.URL.Query()
	q.Add("name", name)
	req.URL.RawQuery = q.Encode()

	res, err := client.client.Do(req)

	if err != nil {
		return -1, nil, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return -1, nil, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK)+
				fmt.Sprintf("\n Query: %s", req.URL.RawQuery),
			nil,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return -1, nil, fmt.Errorf("failed to parse body with error %s", err)
	}

	count, ok := body["count"].(float64)
	if !ok {
		return -1, nil, errors.New("no count found in LaunchID body")
	}

	if count < 1 {
		return -1, nil, ResponseError(
			fmt.Sprintf("no job with name: %s found, endpoint: %s, query: %s", name, res.Request.Method+" "+client.url, req.URL.RawQuery),
			nil,
			res.Body,
		)
	}
	if count > 1 {
		return -1, nil, fmt.Errorf("more than one entry found")
	}

	results, ok := body["results"].([]interface{})
	if !ok {
		return -1, nil, errors.New("no results found in LaunchID body")
	}

	id, ok := results[0].(map[string]interface{})["id"].(float64)

	if !ok {
		body, _ := ioutil.ReadAll(res.Body)
		checkExistsIDSync(string(body), d)
		return -1, nil, errors.New("no ID found in LaunchID results")
	}

	if results[0] == nil {
		return -1, nil, ResponseError(
			"results error in body",
			nil,
			res.Body,
		)
	}

	job := results[0].(map[string]interface{})
	if job == nil {
		return -1, nil, ResponseError(
			"job error in body",
			nil,
			res.Body,
		)
	}

	return int(id), job, nil
}

// sendRunRequest
// desc: Trigger run of tower job template and set the id of the job returned
// takes:
//	 - int: id of the job template to run
//   - *schema.ResourceData: the resource schema of type resource job run
//	 - interface{}: configuration of resource
// returns:
//	 - error: if an error occurred
func sendRunRequest(origin, endpointType string, id, retry int, d *schema.ResourceData, meta interface{}) (int, error) {
	var err error

	config := meta.(*Config)
	client := config.Client(endpointType + "_templates/" + strconv.Itoa(id) + "/launch/")

	template, err := getEntry(meta, endpointType+"_templates/", id)
	jobType, ok := template["job_type"].(string)

	if origin == "check" || !ok || err != nil {
		log.Print("WARNING: Something went wrong while retrieving job_type, running as a check")
		origin = "check"
		jobType = "check" // Default to check run if anything happens
	}

	// Unpack the extra vars for ease of manipulation
	extraVarsMap := make(map[string]interface{})
	if d.Get("extra_vars").(string) != "" {
		extraVarsMap, err = Unmarshal(d.Get("extra_vars").(string))
		if err != nil {
			return -1, fmt.Errorf("unable to unmarshal extra_vars with error: %s", err)
		}
	}
	// Add retries to the extra_vars
	extraVarsMap["retry"] = d.Get("retries").(int) - retry

	if origin == "delete" && d.Get("artifact_data") != nil {
		extraVarsMap["create_artifacts"] = d.Get("artifact_data").(map[string]interface{})
	}

	extraVars, err := json.Marshal(extraVarsMap)
	if err != nil {
		return -1, fmt.Errorf("unable to remarshal extra_vars with error: %s", err)
	}

	rawBody := map[string]interface{}{
		"inventory":   d.Get("inventory").(int),
		"credential":  d.Get("credential").(int),
		"credentials": d.Get("credentials").([]interface{}),
		"extra_vars":  string(extraVars),
		"job_type":    jobType,
	}

	if endpointType == "job" {
		if d.Get("branch_override").(string) != "" {
			rawBody["scm_branch"] = d.Get("branch_override").(string)
		}
	}

	if origin == "delete" {
		if d.Get("delete_inventory").(int) != -1 {
			rawBody["inventory"] = d.Get("delete_inventory").(int)
		}
		if d.Get("delete_credential").(int) != -1 {
			rawBody["credential"] = d.Get("delete_credential").(int)
		}
	}

	reqBody, err := MarshalNoNil(rawBody)

	if err != nil {
		return -1, fmt.Errorf("unable to marshal request body: %s", err)
	}

	if err = d.Set("start_time", time.Now().Format("2006-01-02 15:04:05")); err != nil {
		return -1, fmt.Errorf("error setting start time: %s", err)
	}

	req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))

	if err != nil {
		return -1, fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return -1, fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return -1, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusCreated {
		return -1, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusCreated)+
				fmt.Sprintf("\n JobTemplateID: %d", id),
			reqBody,
			res.Body,
		)
	}

	// Decode the response body
	body, err := BodyToMap(res.Body)
	if err != nil {
		return -1, fmt.Errorf("failed to parse body with error %s", err)
	}

	jobID := int(body[endpointType].(float64))
	d.SetId(strconv.Itoa(jobID))

	if origin == "check" {
		return jobID, nil
	}

	_, _ = d.Set("changes", 0), d.Set("skips", 0)
	body, err = waitForJobCompletion(d, meta, endpointType, d.Id())

	if err != nil {
		if strings.Contains(err.Error(), "failed") && !d.Get("success_on_job_fail").(bool) {
			d.SetId("") // Only wipe ID if success_on_job_fail is false and job failed
		}

		return -1, fmt.Errorf("job run %s returned error: %s", strconv.Itoa(jobID), err)
	}

	if body["artifacts"] != nil {
		newMap, ok := body["artifacts"].(map[string]interface{})
		if !ok {
			return -1, fmt.Errorf("error unpacking artifact map: %s", err)
		}
		return jobID, d.Set("artifact_data", newMap)
	}

	return jobID, d.Set("artifact_data", nil)
}

// waitForJobCompletion
// desc: Periodically check if the job has completed running on
//   ansible tower then return.
// takes:
//   - *schema.ResourceData: the resource schema of type resource job run
//	 - interface{}: configuration of resource
//   - string: the endpoint type "job" or "workflow_job"
//	 - string: the id of the job or workflow job
// returns:
//	 - error: if an error occurred
func waitForJobCompletion(d *schema.ResourceData, meta interface{}, endpointType string, id string) (map[string]interface{}, error) {
	endpoint := endpointType + "s/" + id + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)

	timeout := d.Get("status_check_retries").(int)                                // 4000 * 3 = 12000 seconds or 200 minutes or 3.3 hours
	wait, err := time.ParseDuration(d.Get("status_check_retries_delay").(string)) // seconds

	if err != nil {
		return nil, fmt.Errorf("unable to parse duration: %s : %s", d.Get("status_check_retries_delay").(string), err)
	}

	for timeout > 0 {
		time.Sleep(wait)
		req, err := http.NewRequest("GET", client.url, nil)

		if err != nil {
			return nil, fmt.Errorf("error creating request: %s", err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return nil, fmt.Errorf("error setting authorization headers: %s", err)
		}

		res, err := client.client.Do(req)
		if err != nil {
			return nil, fmt.Errorf("error creating HTTP request: %s", err)
		}
		if res.StatusCode != http.StatusOK {
			return nil, ResponseError(
				StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK)+
					fmt.Sprintf("\n JobID: %s", d.Id()),
				nil,
				res.Body,
			)
		}
		body, err := BodyToMap(res.Body)
		if err != nil {
			return nil, fmt.Errorf("error parsing body with error: %s", err)
		}

		if status := body["status"].(string); status == "successful" {
			return body, d.Set("end_time", time.Now().Format("2006-01-02 15:04:05"))
		} else if status == "failed" || status == "error" || status == "canceled" {
			return nil, fmt.Errorf("job failed with status: %s", status)
		}
		timeout--
	}
	return nil, fmt.Errorf("job timed out")
}
