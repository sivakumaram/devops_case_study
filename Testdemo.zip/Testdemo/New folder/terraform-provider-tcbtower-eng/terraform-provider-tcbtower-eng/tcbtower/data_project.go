package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataProject() *schema.Resource {
	return &schema.Resource{
		Read: dataProjectRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"organization_id": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"scm_type": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"scm_url": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"scm_branch": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"scm_delete_on_update": {
				Type:     schema.TypeBool,
				Computed: true,
			},
			"description": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"scm_update_on_update": {
				Type:     schema.TypeBool,
				Computed: true,
			},
		},
	}
}

func dataProjectRead(d *schema.ResourceData, meta interface{}) error {
	endpoint := "projects/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return fmt.Errorf("unable to retrieve project with error: %s", err)
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	orgID, ok := res["organization"].(float64)
	if !ok {
		return fmt.Errorf("unable to access organizations id in response body: %v", res)
	}
	if err = d.Set("organization_id", int(orgID)); err != nil {
		return fmt.Errorf("error setting the organization id for Project, %s", err)
	}

	propertyList := []string{
		"scm_type", "scm_branch", "scm_branch", "scm_delete_on_update", "scm_update_on_update", "description",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for Project, %s", err)
	}

	return nil
}
