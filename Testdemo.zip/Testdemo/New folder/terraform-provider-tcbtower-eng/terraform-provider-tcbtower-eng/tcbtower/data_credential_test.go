package tcbtower

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

func TestAccCredentialDataSource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {

		config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_credential_type" "dependency" {
					name = "tf-acc-test-credential-type-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}
				
				resource "tower_credential" "dependency" {
					name = "tf-acc-test-%[1]s"
					type = tower_credential_type.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}
				
				data "tower_credential" "test" {
					name = tower_credential.dependency.name
				}`, randomID)

		check := resource.ComposeTestCheckFunc(
			resource.TestCheckResourceAttrSet(
				"data.tower_credential.test", "id",
			),
			resource.TestCheckResourceAttr(
				"data.tower_credential.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
			),
		)

		testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
			resource.Test(t, resource.TestCase{
				PreCheck:  func() { TestAccPreCheck(t) },
				Providers: testAccProviders,
				Steps: []resource.TestStep{
					{
						Config: config,
						Check:  check,
					},
				},
			})
		}

		t.Run("id_from_name", func(t *testing.T) {
			testCase(t, config, check)
		})
	})

}
