package tcbtower

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const credentialTypeTestEndpoint string = "credential_types/"

func TestAccCredentialTypeResource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_credential_type" "test" {
					name = "tf-acc-test-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential_type.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "inputs", "{}",
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "injectors", "{}",
				),
				testAccCheckResourceExists(
					credentialTypeTestEndpoint, "tower_credential_type.test",
				),
			)
			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(credentialTypeTestEndpoint, "tower_credential_type", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_credential_type" "test" {
					name = "tf-acc-test-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential_type.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "inputs", "{}",
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "injectors", "{}",
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_credential_type" "test" {
					name = "tf-acc-test-%[1]s"
					inputs = "{}"
					injectors = "{}"
				}`, randomID)

			updateConfig := fmt.Sprintf(`
			resource "tower_credential_type" "test" {
				name = "tf-acc-test-update-%[1]s"
				inputs = jsonencode({"fields":[{"id":"token", "label":"none"}]})
        		injectors = jsonencode({"extra_vars":{"key":"val"}})
			}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential_type.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "inputs", "{}",
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "injectors", "{}",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_credential_type.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "name", fmt.Sprintf("tf-acc-test-update-%[1]s", randomID),
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "inputs", `{"fields":[{"id":"token","label":"none"}]}`,
				),
				resource.TestCheckResourceAttr(
					"tower_credential_type.test", "injectors", `{"extra_vars":{"key":"val"}}`,
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

}
