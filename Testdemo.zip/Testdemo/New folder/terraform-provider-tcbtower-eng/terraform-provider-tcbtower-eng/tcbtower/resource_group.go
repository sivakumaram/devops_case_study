package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func resourceGroup() *schema.Resource {
	return &schema.Resource{
		Create: resourceGroupCreate,
		Read:   resourceGroupRead,
		Update: resourceGroupUpdate,
		Delete: resourceGroupDelete,
		Importer: &schema.ResourceImporter{
			State: resourceGroupImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"inventory": {
				Type:     schema.TypeInt,
				Required: true,
			},
			"variables": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
		},
	}
}

func resourceGroupCreate(d *schema.ResourceData, meta interface{}) error {
	return groupEndpoint("POST", "groups/", d, meta)
}

func resourceGroupRead(d *schema.ResourceData, meta interface{}) error {
	endpoint := "groups/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	if _, err = BodyToMap(res.Body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	return nil
}

func resourceGroupUpdate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "groups/" + d.Id() + "/"

	return groupEndpoint("PUT", endpoint, d, meta)
}

func resourceGroupDelete(d *schema.ResourceData, meta interface{}) error {
	endpoint := "groups/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("DELETE", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusNoContent {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
			nil,
			res.Body,
		)
	}

	d.SetId("")

	return nil
}

func groupEndpoint(method string, endpoint string, d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	client := config.Client(endpoint)
	reqBody, err := json.Marshal(map[string]interface{}{
		"name":      d.Get("name").(string),
		"inventory": d.Get("inventory").(int),
		"variables": d.Get("variables").(string),
	})
	if err != nil {
		return fmt.Errorf("error marshalling request body: %s", err)
	}

	req, err := http.NewRequest(method, client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			reqBody,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	groupID := int(body["id"].(float64))
	d.SetId(strconv.Itoa(groupID))

	return resourceGroupRead(d, meta)
}

func resourceGroupImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "groups/"

	name := d.Id()
	d.Set("name", name)

	group, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching group: %s", err)
	}

	d.SetId(strconv.Itoa(int(group["id"].(float64))))

	d.Set("url", string(group["url"].(string)))
	d.Set("group_id", int(group["id"].(float64)))
	d.Set("created", string(group["created"].(string)))
	d.Set("modified", string(group["modified"].(string)))
	d.Set("name", string(group["name"].(string)))
	d.Set("description", string(group["description"].(string)))
	d.Set("inventory_id", int(group["inventory"].(float64)))

	return []*schema.ResourceData{d}, nil
}
