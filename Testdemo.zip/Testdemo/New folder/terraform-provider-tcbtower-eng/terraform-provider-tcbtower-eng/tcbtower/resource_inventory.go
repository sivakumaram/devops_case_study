package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func resourceInventory() *schema.Resource {
	return &schema.Resource{
		Create: resourceInventoryCreate,
		Read:   resourceInventoryRead,
		Update: resourceInventoryUpdate,
		Delete: resourceInventoryDelete,
		Importer: &schema.ResourceImporter{
			State: resourceInventoryImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"description": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"organization": {
				Type:       schema.TypeString,
				Optional:   true,
				Default:    "",
				Deprecated: "This has been deprecated and will be removed in future releases. Use a data organization block to resolve name to ID.",
			},
			"organization_id": {
				Type:     schema.TypeInt,
				Optional: true,
			},
			"variables": {
				Type:     schema.TypeString,
				Optional: true,
			},
			"kind": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"instance_groups": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default: nil,
			},
		},
	}
}

func resourceInventoryCreate(d *schema.ResourceData, meta interface{}) error {
	return inventoryEndpoint("POST", "inventories/", d, meta)
}

func resourceInventoryRead(d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)
	client := config.Client("inventories/" + d.Id() + "/")

	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	if _, err = BodyToMap(res.Body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	return nil
}

func resourceInventoryUpdate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "inventories/" + d.Id() + "/"

	return inventoryEndpoint("PUT", endpoint, d, meta)
}

func resourceInventoryDelete(d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)
	client := config.Client("inventories/" + d.Id() + "/")

	req, err := http.NewRequest("DELETE", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	req.Header.Set("Content-type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusAccepted || res.StatusCode == http.StatusNoContent) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusAccepted, http.StatusNoContent),
			nil,
			res.Body,
		)
	}

	d.SetId("")

	return nil
}

func inventoryEndpoint(method, endpoint string, d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	orgID, err := resolveOrganization(d, meta, "REQUIRED")
	if err != nil {
		return fmt.Errorf("failed resolving organization with error: %s", err)
	}

	client := config.Client(endpoint)
	reqBody, err := json.Marshal(map[string]interface{}{
		"name":         d.Get("name").(string),
		"description":  d.Get("description").(string),
		"organization": orgID,
		"variables":    d.Get("variables").(string),
		"kind":         d.Get("kind").(string),
	})

	if err != nil {
		return fmt.Errorf("failed to marshal req body with error: %s", err)
	}

	req, err := http.NewRequest(method, client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	if err != nil {
		return fmt.Errorf("failed to create request with error: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to post new inventory with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			reqBody,
			res.Body,
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	invID := int(body["id"].(float64))
	d.SetId(strconv.Itoa(invID))

	igs, err := GetAllResourceIGs("inventories/", invID, meta)
	// Check if instance_groups exist already
	if len(igs) > 0 {
		// Remove instance groups
		if err != nil {
			return fmt.Errorf("error getting groups: %s", err)
		}
		for i, val := range igs {
			ig := int(val.(map[string]interface{})["id"].(float64))
			err = RemoveIGfromResource("inventories/", invID, meta, ig)
			if err != nil {
				return fmt.Errorf("error removing instance group: %d with error: %s on loop %d", ig, err, i)
			}
		}
	}

	// Add all instance groups to inventory
	err = AddIGstoResource("inventories/", invID, d.Get("instance_groups"), meta)
	if err != nil {
		return err
	}

	return resourceInventoryRead(d, meta)
}

func resourceInventoryImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "inventories/" + d.Id() + "/"

	name := d.Id()
	d.Set("name", name)

	inv, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching inventory: %s", err)
	}

	d.SetId(strconv.Itoa(int(inv["id"].(float64))))

	d.Set("url", string(inv["url"].(string)))
	d.Set("inventory_id", int(inv["id"].(float64)))
	d.Set("created", string(inv["created"].(string)))
	d.Set("modified", string(inv["modified"].(string)))
	d.Set("host_filter", string(inv["host_filter"].(string)))
	d.Set("kind", string(inv["kind"].(string)))
	d.Set("type", string(inv["type"].(string)))
	d.Set("name", string(inv["name"].(string)))
	d.Set("pending_deletion", bool(inv["pending_deletion"].(bool)))
	d.Set("total_inventory_sources", int(inv["total_inventory_sources"].(float64)))

	return []*schema.ResourceData{d}, nil
}
