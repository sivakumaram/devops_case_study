package tcbtower

import (
	"fmt"
	"strings"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
	"github.com/hashicorp/terraform-plugin-sdk/terraform"
	"github.com/hashicorp/terraform/helper/acctest"
	"github.com/stretchr/testify/assert"
)

func TestAccResolveOrganization(t *testing.T) {
	t.Skip("No tests written due to limitations of schema.ResourceData's set functionality.")
	// Create the organization to test against
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)
	OrgName := fmt.Sprintf("tf-acc-test-%[1]s", randomID)

	testProvider := ConfigureTestProvider(t)
	meta := testProvider.Meta()
	var d schema.ResourceData

	d.SetId("-1")
	_ = d.Set("name", OrgName)
	_ = d.Set("max_hosts", 0)
	_ = d.Set("description", "...")
	_ = d.Set("custom_virtualenv", "")

	t.Logf("%v", d.State())

	err := organizationEndpoint("POST", "organizations/", &d, meta)

	if err != nil {
		t.Errorf("error while trying to create a test organization called %s: %s", OrgName, err)
	}

	OrgID := d.Id()

	// Cleanup the organization that was created
	d.SetId(OrgID)
	_ = resourceOrganizationDelete(&d, meta)
	if err != nil {
		t.Errorf("error while deleting test organization: %s", err)
	}
}

func TestAccsetItems(t *testing.T) {
	t.Skip("No tests written due to limitations of schema.ResourceData's set functionality.")
	var d schema.ResourceData
	tests := map[string]struct {
		bodyMap map[string]interface{}
		keys    []string
		want    error
	}{
		"setFloat": {
			bodyMap: map[string]interface{}{
				"aFloat": 20.8,
			},
			keys: []string{"aFloat"},
			want: nil,
		},
		"setBool": {
			bodyMap: map[string]interface{}{
				"aBool": true,
			},
			keys: []string{"aBool"},
			want: nil,
		},
		"setString": {
			bodyMap: map[string]interface{}{
				"aString": "hello there",
			},
			keys: []string{"aString"},
			want: nil,
		},
		"setList": {
			bodyMap: map[string]interface{}{
				"aList": []string{
					"hello",
					"there",
				},
			},
			keys: []string{"aList"},
			want: nil,
		},
	}

	for testName, testCase := range tests {
		t.Logf("Running %s test case", testName)

		err := setItems(&d, testCase.bodyMap, testCase.keys)

		for _, key := range testCase.keys {
			if val, ok := d.GetOk(key); !ok {
				t.Errorf("Expected %s to be set in dictionary \nwas %v", key, val)
			}
		}

		assert.Equal(t, testCase.want, err, "Expected errors to match")

	}

}

func testAccCompareAttributes(dataSourceName, dataSourceAttribute, resourceName, resourceAttribute string) resource.TestCheckFunc {
	return func(s *terraform.State) error {
		ds, ok := s.RootModule().Resources[dataSourceName]
		if !ok {
			return fmt.Errorf("root module has no resource called %s", dataSourceName)
		}

		rs, ok := s.RootModule().Resources[resourceName]
		if !ok {
			return fmt.Errorf("can't find %s in state", resourceName)
		}

		dsAttributes := ds.Primary.Attributes
		rsAttributes := rs.Primary.Attributes

		if dsAttributes[dataSourceAttribute] != rsAttributes[resourceAttribute] {
			return fmt.Errorf(
				"%s is %s; want %s",
				dataSourceAttribute,
				dsAttributes[dataSourceAttribute],
				rsAttributes[resourceAttribute],
			)
		}

		return nil
	}
}

func testAccCheckResourceExists(endpoint, name string) resource.TestCheckFunc {
	return func(state *terraform.State) error {
		rs, ok := state.RootModule().Resources[name]
		if !ok {
			return fmt.Errorf("root module has no resource called %s", name)
		}

		if rs.Primary.ID == "" {
			return fmt.Errorf("no record id is set for the resource called %s", name)
		}

		res, err := getEntry(testAccProvider.Meta(), endpoint, rs.Primary.Attributes["name"])

		if err != nil {
			return fmt.Errorf("error while verifying that the resource, %s, exists on tower -- it probably doesn't. \n error: %s", name, err)
		}

		if res["id"] == nil {
			return fmt.Errorf("the resource %s doesn't exist on tower", name)
		}

		return nil
	}
}

func checkResourceDelete(endpoint, resourceType, resourceName string) func(s *terraform.State) error {
	return func(s *terraform.State) error {
		for name, rs := range s.RootModule().Resources {
			if rs.Type != resourceType {
				continue
			}
			if strings.HasPrefix(name, "data.") {
				continue
			}

			_, err := getEntry(testAccProvider.Meta(), endpoint, name)

			if err == nil {
				return fmt.Errorf("error deleting the %s resource, %s. It seems to still exist on Tower", resourceType, resourceName)
			}
		}
		return nil
	}
}
