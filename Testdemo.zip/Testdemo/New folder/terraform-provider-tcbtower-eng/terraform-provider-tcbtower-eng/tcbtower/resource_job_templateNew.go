package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
	"gopkg.in/yaml.v3"
)

func resourceJobTemplateNew() *schema.Resource {
	return &schema.Resource{
		Create: resourceJobTemplateCreateNew,
		Read:   resourceJobTemplateReadNew,
		Update: resourceJobTemplateUpdateNew,
		Delete: resourceJobTemplateDeleteNew,
		Importer: &schema.ResourceImporter{
			State: resourceJopTemplateImportNew,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:        schema.TypeString,
				Required:    true,
				Description: "The name of the Job Template you wish to create",
			},
			"description": {
				Type:        schema.TypeString,
				Optional:    true,
				Description: "Description for the job template on Tower",
			},
			"inventory": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  -1,
			},
			"credentials": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default:     nil,
				Description: "List of credential IDs",
			},
			"organization_id": {
				Type:     schema.TypeInt,
				Optional: true,
			},
			"project_id": {
				Type:        schema.TypeInt,
				Required:    true,
				Description: "The ID of the project linked to the template",
			},
			"playbook": {
				Type:        schema.TypeString,
				Required:    true,
				Description: "The playbook for this to run",
			},
			"extra_vars": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"job_type": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "run",
				Description: "The name type of job that will be run",
			},
			"job_tags": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"skip_tags": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "",
			},
			"instance_groups": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default: nil,
			},
			"become_enabled": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Whether to run the job as become",
			},
			"enable_concurrent_jobs": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Allow jobs to run concurrently or not",
			},
			"ask_inventory_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt inventory on launch",
			},
			"ask_credential_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt credential on launch",
			},
			"ask_variables_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt extra variables on launch",
			},
			"ask_job_type_on_launch": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     true,
				Description: "Whether to prompt job type (check, run) on launch",
			},
			"update_project_on_create": {
				Type:     schema.TypeBool,
				Optional: true,
				Default:  false,
			},
			"wait_for_jobless_retries": {
				Type:        schema.TypeInt,
				Optional:    true,
				Default:     60,
				Description: "Number of times to wait for a project to be jobless when doing an update for this job template.",
			},
			"wait_for_jobless_time": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "3s",
				Description: "Amount of time to wait for a project to be jobless when doing an update for this job template.",
			},
			"verbosity": {
				Type:        schema.TypeInt,
				Optional:    true,
				Default:     0,
				Description: "The verbosity of the job",
			},
			"implement_destroy": {
				Type:        schema.TypeBool,
				Optional:    true,
				Default:     false,
				Description: "Build create and destroy job templates. WARNING: setting this to false can break your infrastructure",
				Deprecated:  "This has been deprecated and will be removed in future releases. Use two resource blocks instead.",
			},
			"template_create_id": {
				Type:        schema.TypeInt,
				Computed:    true,
				Default:     nil,
				Description: "Name of your create playbook",
				Deprecated:  "This has been deprecated and will be removed in future releases. Use two resource blocks.",
			},
			"template_delete_id": {
				Type:        schema.TypeInt,
				Computed:    true,
				Default:     nil,
				Description: "Name of your delete playbook",
				Deprecated:  "This has been deprecated and will be removed in future releases. Use two resource blocks.",
			},
		},
	}
}

func resourceJobTemplateReadNew(d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	if d.Get("implement_destroy").(bool) {
		postfixes := []string{"_create", "_delete"}
		for _, postfix := range postfixes {
			id := d.Get("template" + postfix + "_id")
			client := config.Client("job_templates/" + fmt.Sprint(id) + "/")

			req, err := http.NewRequest("GET", client.url, nil)
			if err != nil {
				return fmt.Errorf("%s: error creating request: %s", postfix, err)
			}

			if err = setAuthHeader(meta, req); err != nil {
				return fmt.Errorf("%s: error setting authorization headers: %s", postfix, err)
			}
			req.Header.Set("Content-type", "application/json")

			res, err := client.client.Do(req)
			if err != nil {
				return fmt.Errorf("%s: HTTP request failed with error: %s", postfix, err)
			}

			if res.StatusCode != http.StatusOK {
				return ResponseError(
					StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
					nil,
					res.Body,
					checkExistsIDSyncFunc(d),
				)
			}

			if _, err = BodyToMap(res.Body); err != nil {
				return fmt.Errorf("%s: failed to parse body with error %s", postfix, err)
			}

		}
	} else {
		id := d.Id()
		client := config.Client("job_templates/" + fmt.Sprint(id) + "/")

		req, err := http.NewRequest("GET", client.url, nil)
		if err != nil {
			return fmt.Errorf("error creating request: %s", err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return fmt.Errorf("error setting authorization headers: %s", err)
		}
		req.Header.Set("Content-type", "application/json")

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("HTTP request failed with error: %s", err)
		}

		if res.StatusCode != http.StatusOK {
			return ResponseError(
				StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
				nil,
				res.Body,
				checkExistsIDSyncFunc(d),
			)
		}

		if _, err = BodyToMap(res.Body); err != nil {
			return fmt.Errorf("failed to parse body with error %s", err)
		}
	}

	return nil
}

func resourceJobTemplateCreateNew(d *schema.ResourceData, meta interface{}) error {
	endpoint := "job_templates/"

	// Update project if POST and update_project_on_create
	if d.Get("update_project_on_create").(bool) {

		if err := projectUpdateSource(meta, strconv.Itoa(d.Get("project_id").(int))); err != nil {
			return fmt.Errorf("error updating project: %s", err)
		}

		if err := projectWaitForJobless(strconv.Itoa(d.Get("project_id").(int)), d, meta); err != nil {
			return fmt.Errorf("error waiting for project to update: %s", err)
		}
	}

	if d.Get("implement_destroy").(bool) {
		postfixes := []string{"_create", "_delete"}
		for _, postfix := range postfixes {
			id, err := jobTemplateEndpoint("POST", endpoint, postfix, d, meta)
			if err != nil {
				return fmt.Errorf("error during create for %s: %s", postfix, err)
			}

			d.Set("template"+postfix+"_id", id)
		}
	} else {

		id, err := jobTemplateEndpoint("POST", endpoint, "", d, meta)
		if err != nil {
			return fmt.Errorf("error at during create: %s", err)
		}

		d.SetId(strconv.Itoa(id))
	}

	return resourceJobTemplateReadNew(d, meta)
}

func resourceJobTemplateUpdateNew(d *schema.ResourceData, meta interface{}) error {
	endpoint := "job_templates/"

	if d.Get("implement_destroy").(bool) {
		postfixes := []string{"_create", "_delete"}
		for _, postfix := range postfixes {
			id, err := jobTemplateEndpoint("PUT", endpoint, postfix, d, meta)
			if err != nil {
				return fmt.Errorf("error during create for %s: %s", postfix, err)
			}

			d.Set("template"+postfix+"_id", id)
		}
	} else {

		id, err := jobTemplateEndpoint("PUT", endpoint, "", d, meta)
		if err != nil {
			return fmt.Errorf("error at during create: %s", err)
		}

		d.SetId(strconv.Itoa(id))
	}

	return resourceJobTemplateReadNew(d, meta)
}

// XXX: This function seems to be broken.
func resourceJobTemplateDeleteNew(d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	if d.Get("implement_destroy").(bool) {
		postfixes := []string{"_create", "_delete"}
		for _, postfix := range postfixes {
			id := d.Get("template" + postfix + "_id")
			client := config.Client("job_templates/" + fmt.Sprint(id) + "/")

			req, err := http.NewRequest("DELETE", client.url, nil)
			if err != nil {
				return fmt.Errorf("%s: error creating request: %s", postfix, err)
			}

			err = setAuthHeader(meta, req)
			if err != nil {
				return fmt.Errorf("error setting authorization headers: %s", err)
			}
			req.Header.Set("Content-type", "application/json")

			res, err := client.client.Do(req)
			if err != nil {
				return fmt.Errorf("HTTP request failed with error: %s", err)
			}

			if !(res.StatusCode == http.StatusAccepted || res.StatusCode == http.StatusNoContent) {
				return ResponseError(
					StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusAccepted, http.StatusNoContent),
					nil,
					res.Body,
				)
			}

			d.Set("template"+postfix+"_id", "")

		}
	} else {
		id := d.Id()
		client := config.Client("job_templates/" + fmt.Sprint(id) + "/")

		req, err := http.NewRequest("DELETE", client.url, nil)
		if err != nil {
			return fmt.Errorf("error creating request: %s", err)
		}

		if err = setAuthHeader(meta, req); err != nil {
			return fmt.Errorf("error setting authorization headers: %s", err)
		}
		req.Header.Set("Content-type", "application/json")

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("HTTP request failed with error: %s", err)
		}

		if !(res.StatusCode == http.StatusAccepted || res.StatusCode == http.StatusNoContent) {
			return ResponseError(
				StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusAccepted, http.StatusNoContent),
				nil,
				res.Body,
			)
		}
	}

	d.SetId("")

	return nil
}

func jobTemplateEndpoint(verb, endpoint, postfix string, d *schema.ResourceData, meta interface{}) (int, error) {
	config := meta.(*Config)
	client := config.Client(endpoint)

	var rawBody map[string]interface{}

	// BEGIN All sorts of work to confirm the extra vars are valid
	_extra_vars := d.Get("extra_vars").(string)

	extra_vars := new(map[string]interface{})

	if err := yaml.Unmarshal([]byte(_extra_vars), extra_vars); err != nil {
		return -1, fmt.Errorf("argument error for extra_vars: %s", err)
	}

	extraVars, err := json.Marshal(extra_vars)

	if err != nil {
		return -1, fmt.Errorf("unable to remarshal extra_vars with error: %s", err)
	}

	rawBody = map[string]interface{}{
		"name":                     d.Get("name").(string) + postfix,
		"description":              d.Get("description").(string),
		"organization":             d.Get("organization_id").(int),
		"project":                  d.Get("project_id").(int),
		"playbook":                 d.Get("playbook").(string) + postfix + ".yml",
		"job_type":                 d.Get("job_type").(string),
		"job_tags":                 d.Get("job_tags").(string),
		"skip_tags":                d.Get("skip_tags").(string),
		"verbosity":                d.Get("verbosity").(int),
		"ask_inventory_on_launch":  d.Get("ask_inventory_on_launch").(bool),
		"ask_credential_on_launch": d.Get("ask_credential_on_launch").(bool),
		"ask_variables_on_launch":  d.Get("ask_variables_on_launch").(bool),
		"become_enabled":           d.Get("become_enabled").(bool),
		"allow_simultaneous":       d.Get("enable_concurrent_jobs").(bool),
		"ask_job_type_on_launch":   d.Get("ask_job_type_on_launch").(bool),
		"inventory":                d.Get("inventory").(int),
		"extra_vars":               string(extraVars),
	}

	reqBody, err := MarshalNoNil(rawBody)
	if err != nil {
		return -1, fmt.Errorf("error marshaling request body: %s", err)
	}

	req, err := http.NewRequest(verb, client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return -1, fmt.Errorf("error creating new request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return -1, fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return -1, fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return -1, ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			reqBody,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return -1, fmt.Errorf("failed to parse body with error %s", err)
	}

	jobTemplateID := int(body["id"].(float64))

	if d.Get("credentials") != nil {
		credList := d.Get("credentials").([]interface{})
		if len(credList) > 0 {
			if err = detachCredentialList(jobTemplateID, meta); err != nil {
				return jobTemplateID, fmt.Errorf("error when trying to dettach the \"%s\" credential list: %s", postfix, err)
			}

			if err = setCredentialList(credList, jobTemplateID, meta); err != nil {
				return jobTemplateID, fmt.Errorf("error when trying to update the \"%s\" credential list: %s", postfix, err)
			}
		}
	}

	if d.Get("instance_groups") != nil {
		igs, err := GetAllResourceIGs("job_templates/", jobTemplateID, meta)
		// Check if instance_groups exist already
		if len(igs) > 0 {
			// Remove instance groups
			if err != nil {
				return jobTemplateID, fmt.Errorf("error getting the \"%s\" instance groups: %s", postfix, err)
			}
			for i, val := range igs {
				ig := int(val.(map[string]interface{})["id"].(float64))
				if err = RemoveIGfromResource("job_templates/", jobTemplateID, meta, ig); err != nil {
					return jobTemplateID, fmt.Errorf("error removing the \"%s\" instance group %d: %s on loop %d", postfix, ig, err, i)
				}
			}
		}

		// Add all instance groups to inventory
		if err = AddIGstoResource("job_templates/", jobTemplateID, d.Get("instance_groups"), meta); err != nil {
			return jobTemplateID, fmt.Errorf("error adding the \"%s\" instance group: %s", postfix, err)
		}
	}

	return jobTemplateID, nil
}

func resourceJopTemplateImportNew(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "job_templates/" + d.Id() + "/"

	name := d.Id()
	d.Set("name", name)

	jobTemplate, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching job template: %s", err)
	}

	d.SetId(strconv.Itoa(int(jobTemplate["id"].(float64))))

	d.Set("url", string(jobTemplate["url"].(string)))
	d.Set("jobTemplate_id", int(jobTemplate["id"].(float64)))
	d.Set("created", string(jobTemplate["created"].(string)))
	d.Set("modified", string(jobTemplate["modified"].(string)))
	d.Set("name", string(jobTemplate["name"].(string)))
	d.Set("description", string(jobTemplate["description"].(string)))
	d.Set("job_type", string(jobTemplate["job_type"].(string)))
	d.Set("inventory_id", int(jobTemplate["inventory"].(float64)))
	d.Set("project_id", int(jobTemplate["project"].(float64)))
	d.Set("playbook", string(jobTemplate["playbook"].(string)))
	d.Set("scm_branch", string(jobTemplate["scm_branch"].(string)))
	d.Set("organization_id", int(jobTemplate["organization"].(float64)))
	d.Set("status", string(jobTemplate["status"].(string)))
	d.Set("ask_inventory_on_launch", bool(jobTemplate["ask_inventory_on_launch"].(bool)))
	d.Set("ask_credential_on_launch", bool(jobTemplate["ask_credential_on_launch"].(bool)))
	d.Set("ask_variables_on_launch", bool(jobTemplate["ask_variables_on_launch"].(bool)))
	d.Set("become_enabled", bool(jobTemplate["become_enabled"].(bool)))

	return []*schema.ResourceData{d}, nil
}
