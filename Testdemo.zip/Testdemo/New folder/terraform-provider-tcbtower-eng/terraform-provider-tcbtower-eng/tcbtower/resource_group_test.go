package tcbtower

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const groupTestEndpoint string = "groups/"

func TestAccGroupResource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host_group" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host_group.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host_group.test", "inventory", "tower_inventory.dependency", "id",
				),
				testAccCheckResourceExists(
					groupTestEndpoint, "tower_host_group.test",
				),
			)

			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(groupTestEndpoint, "tower_group", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host_group" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host_group.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host_group.test", "inventory", "tower_inventory.dependency", "id",
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host_group" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
				}`, randomID)

			updateConfig := fmt.Sprintf(`
			resource "tower_organization" "dependency" {
				name = "tf-acc-test-organization-%[1]s"
			}

			resource "tower_organization" "update_dependency" {
				name = "tf-acc-test-organization-update-%[1]s"
			}

			resource "tower_inventory" "dependency" {
				name = "tf-acc-test-inventory-%[1]s"
				organization_id = tower_organization.dependency.id
				organization = tower_organization.dependency.name
			}

			resource "tower_inventory" "update_dependency" {
				name = "tf-acc-test-inventory-update-%[1]s"
				organization_id = tower_organization.update_dependency.id
				organization = tower_organization.update_dependency.name
			}

			resource "tower_host_group" "test" {
				name = "tf-acc-test-%[1]s"
				inventory = tower_inventory.update_dependency.id
				variables = jsonencode({"fields":[{"id":"token","label":"none"}]})
			}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host_group.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host_group.test", "inventory", "tower_inventory.dependency", "id",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host_group.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host_group.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host_group.test", "inventory", "tower_inventory.update_dependency", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host_group.test", "variables", `{"fields":[{"id":"token","label":"none"}]}`,
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

}
