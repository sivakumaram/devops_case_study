package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
	"gopkg.in/yaml.v3"
)

func resourceCredentials() *schema.Resource {
	return &schema.Resource{
		DeprecationMessage: "tower_credentials is deprecated and will be removed in future releases. Please use tower_credential",
		Create:             resourceCredentialsCreate,
		Read:               resourceCredentialsRead,
		Update:             resourceCredentialsUpdate,
		Delete:             resourceCredentialsDelete,
		Importer: &schema.ResourceImporter{
			State: resourceCredentialsImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"type": {
				Type:     schema.TypeInt,
				Required: true,
			},
			"inputs": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "{}",
			},
			"inputs_source": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "{}",
			},
			"description": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  "...",
			},
			"organization": {
				Type:       schema.TypeString,
				Optional:   true,
				Default:    "",
				Deprecated: "This has been deprecated and will be removed in future releases. Use a data organization block to resolve name to ID.",
			},
			"organization_id": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"type_id": {
				Type:     schema.TypeInt,
				Computed: true,
			},
		},
	}
}

func resourceCredentialsRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "credentials/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	if _, err = BodyToMap(res.Body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	return nil
}

func resourceCredentialsCreate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credentials/"
	return credentialsEndpoint("POST", endpoint, d, meta)
}

func resourceCredentialsUpdate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credentials/" + d.Id() + "/"
	return credentialsEndpoint("PUT", endpoint, d, meta)
}

func resourceCredentialsDelete(d *schema.ResourceData, meta interface{}) error {
	endpoint := "credentials/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("DELETE", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}
	if res.StatusCode != http.StatusNoContent {
		return fmt.Errorf("status code failed, expected %d got %s, url: %s", http.StatusNoContent, res.Status, client.url)
	}

	d.SetId("")

	return nil
}

func resourceCredentialsImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "credentials/"

	name := d.Id()
	d.Set("name", name)

	cred, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return nil, fmt.Errorf("error fetching credentials: %s", err)
	}

	d.SetId(strconv.Itoa(int(cred["id"].(float64))))

	d.Set("type_id", int(cred["credential_type"].(float64)))
	d.Set("credential_id", int(cred["id"].(float64)))
	d.Set("organization_id", int(cred["organization"].(float64)))

	return []*schema.ResourceData{d}, nil
}

func credentialsEndpoint(verb, endpoint string, d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	var inputsMap map[string]interface{}

	if d.Get("inputs") != "" {
		inputs := d.Get("inputs").(string)
		if strings.ContainsAny(inputs, "---") {
			if err := yaml.Unmarshal([]byte(inputs), &inputsMap); err != nil {
				return fmt.Errorf("error parsing inputs argument as YAML (start YAML with '---' or JSON with 'jsonencode'): %s", err)
			}
		} else {
			if err := json.Unmarshal([]byte(inputs), &inputsMap); err != nil {
				return fmt.Errorf("error parsing inputs argument as JSON (start YAML with '---' or JSON with 'jsonencode'): %s", err)
			}
		}
	}

	d.Set("type_id", d.Get("type").(int))

	org, err := getEntry(meta, "organizations/", d.Get("organization").(string))
	if err != nil {
		return fmt.Errorf("failed to get organization for inventory with error: %s", err)
	}
	d.Set("organization_id", int(org["id"].(float64)))

	reqBody, err := json.Marshal(map[string]interface{}{
		"name":            d.Get("name").(string),
		"description":     d.Get("description").(string),
		"credential_type": d.Get("type_id").(int),
		"organization":    d.Get("organization_id").(int),
		"inputs":          inputsMap,
	})

	if err != nil {
		return fmt.Errorf("error marshaling request body: %s", err)
	}

	client := config.Client(endpoint)
	req, err := http.NewRequest(verb, client.url, bytes.NewBuffer(reqBody))

	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	var body map[string]interface{}

	if err = json.NewDecoder(res.Body).Decode(&body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return fmt.Errorf("status code failed, expected %d got %s, url: %s, Response Body: %v", http.StatusOK, res.Status, client.url, body)
	}

	credID := int(body["id"].(float64))
	d.SetId(strconv.Itoa(credID))

	// Setup secret backend
	var inputSourceMap []map[string]interface{}
	if d.Get("inputs_source") != "{}" {
		inputSource := d.Get("inputs_source").(string)
		if strings.ContainsAny(inputSource, "---") {
			err := yaml.Unmarshal([]byte(inputSource), &inputSourceMap)
			if err != nil {
				return fmt.Errorf("error parsing inputs_source argument as YAML (start YAML with '---' or JSON with 'jsonencode'): %s", err)
			}

		} else {
			err := json.Unmarshal([]byte(inputSource), &inputSourceMap)
			if err != nil {
				return fmt.Errorf("error parsing inputs_source argument as JSON (start YAML with '---' or JSON with 'jsonencode'): %s", err)
			}
		}

		err = setSourceMetadatas(inputSourceMap, credID, meta)
		if err != nil {
			return fmt.Errorf("error setting input source for credential: %s", err)
		}
	}

	return nil
}

func setSourceMetadatas(bodyList []map[string]interface{}, credID int, meta interface{}) error {
	endpoint := "credentials/" + strconv.Itoa(credID) + "/input_sources/"
	config := meta.(*Config)
	client := config.Client(endpoint)

	for i, body := range bodyList {

		reqBody, err := json.Marshal(body)

		if err != nil {
			return fmt.Errorf("error marshaling request body(%d): %s", i, err)
		}

		req, err := http.NewRequest("POST", client.url, bytes.NewBuffer(reqBody))
		if err != nil {
			return fmt.Errorf("error creating request(%d): %s", i, err)
		}

		err = setAuthHeader(meta, req)
		if err != nil {
			return fmt.Errorf("error setting authorization headers(%d): %s", i, err)
		}

		req.Header.Set("Content-Type", "application/json")

		res, err := client.client.Do(req)
		if err != nil {
			return fmt.Errorf("http request(%d) failed with error: %s", i, err)
		}

		var body map[string]interface{}
		err = json.NewDecoder(res.Body).Decode(&body)

		if err != nil {
			return fmt.Errorf("failed to parse body of call %d with error %s", i, err)
		}

		if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
			return fmt.Errorf("status code failed on call %d, expected %d got %s, url: %s \n request: %s\nresponse: %v", i, http.StatusOK, res.Status, client.url, reqBody, body)
		}

	}
	return nil
}
