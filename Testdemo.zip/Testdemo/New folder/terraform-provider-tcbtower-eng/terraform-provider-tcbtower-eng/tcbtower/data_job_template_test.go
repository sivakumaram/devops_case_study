package tcbtower

import (
	"fmt"
	"os"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

func TestAccJobTemplateDataSource(t *testing.T) {
	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)
	t.Run("basic", func(t *testing.T) {
		config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-%[1]s"
				}

				resource "tower_project" "dependency" {
					name = "tf-acc-test-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name

					scm_type = "git"
					scm_url = "%[2]s"
				}

				resource "tower_job_template" "dependency" {
					name = "tf-acc-test-%[1]s"
					project_id = tower_project.dependency.id
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
					playbook = "main"
				}

				data "tower_job_template" "test" {
					name = tower_job_template.dependency.name
				}`, randomID, os.Getenv("TEST_PROJECT_SCM_URL"))

		check := resource.ComposeAggregateTestCheckFunc(
			resource.TestCheckResourceAttrSet(
				"data.tower_job_template.test", "id",
			),
			resource.TestCheckResourceAttr(
				"data.tower_job_template.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
			),
		)

		testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
			resource.Test(t, resource.TestCase{
				PreCheck:  func() { TestAccProjectPreCheck(t) },
				Providers: testAccProviders,
				Steps: []resource.TestStep{
					{
						Config: config,
						Check:  check,
					},
				},
			})
		}

		t.Run("id_from_name", func(t *testing.T) {
			testCase(t, config, check)
		})
	})

}
