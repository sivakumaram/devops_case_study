package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataSchedule() *schema.Resource {
	return &schema.Resource{
		Read: dataScheduleRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"description": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"rrule": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"unified_job_template": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"inventory": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"scm_branch": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"job_type": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"job_tags": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"skip_tags": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"limit": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"diff_mode": {
				Type:     schema.TypeBool,
				Computed: true,
			},
			"verbosity": {
				Type:     schema.TypeInt,
				Computed: true,
			},
			"enabled": {
				Type:     schema.TypeBool,
				Computed: true,
			},
			"dtstart": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"dtend": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"next_run": {
				Type:     schema.TypeString,
				Computed: true,
			},
		},
	}
}

func dataScheduleRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "schedules/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return err
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	propertyList := []string{
		"name",
		"description",
		"rrule",
		"unified_job_template",
		"inventory",
		"scm_branch",
		"job_type",
		"job_tags",
		"skip_tags",
		"limit",
		"diff_mode",
		"verbosity",
		"enabled",
		"dtstart",
		"dtend",
		"next_run",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for schedule, %s", err)
	}

	return nil
}
