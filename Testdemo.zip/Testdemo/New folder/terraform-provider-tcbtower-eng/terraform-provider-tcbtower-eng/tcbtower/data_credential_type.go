package tcbtower

import (
	"fmt"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func dataCredentialType() *schema.Resource {
	return &schema.Resource{
		Read: dataCredentialTypeRead,

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"description": {
				Type:     schema.TypeString,
				Computed: true,
			},
			"kind": {
				Type:     schema.TypeString,
				Computed: true,
			},
		},
	}
}

func dataCredentialTypeRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "credential_types/"

	res, err := getEntry(meta, endpoint, d.Get("name").(string))
	if err != nil {
		checkExistsIDSync(err.Error(), d)
		return err
	}

	id, ok := res["id"].(float64)
	if !ok {
		return fmt.Errorf("unable to access id in response body: %v", res)
	}
	d.SetId(strconv.Itoa(int(id)))

	propertyList := []string{
		"name", "kind",
	}

	if err = setItems(d, res, propertyList); err != nil {
		return fmt.Errorf("error setting values for Credential Type, %s", err)
	}

	return nil
}
