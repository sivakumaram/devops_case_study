package tcbtower

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
	"github.com/hashicorp/terraform/helper/acctest"
)

const hostTestEndpoint string = "hosts/"

func TestAccHostResource(t *testing.T) {
	t.Skip("The tower in the testing environment has an expired license which removes Hosts.")

	randomID := acctest.RandStringFromCharSet(5, acctest.CharSetAlphaNum)

	t.Run("basic", func(t *testing.T) {
		t.Run("create", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host.test", "inventory", "tower_inventory.dependency", "id",
				),
				testAccCheckResourceExists(
					hostTestEndpoint, "tower_host.test",
				),
			)

			testCase(t, config, check)
		})

		t.Run("delete", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, resourceName string) {
				resource.Test(t, resource.TestCase{
					PreCheck:     func() { TestAccPreCheck(t) },
					Providers:    testAccProviders,
					CheckDestroy: checkResourceDelete(hostTestEndpoint, "tower_host", resourceName),
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
				}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host.test", "inventory", "tower_inventory.dependency", "id",
				),
			)

			testCase(t, config, check, fmt.Sprintf("tf-acc-test-%[1]s", randomID))
		})

		t.Run("update", func(t *testing.T) {
			testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
				resource.Test(t, resource.TestCase{
					PreCheck:  func() { TestAccPreCheck(t) },
					Providers: testAccProviders,
					Steps: []resource.TestStep{
						{
							Config: config,
							Check:  check,
						},
						{
							Config: updateConfig,
							Check:  updateCheck,
						},
					},
				})
			}

			config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
				}`, randomID)

			updateConfig := fmt.Sprintf(`
			resource "tower_organization" "dependency" {
				name = "tf-acc-test-organization-%[1]s"
			}

			resource "tower_inventory" "dependency" {
				name = "tf-acc-test-inventory-%[1]s"
				organization_id = tower_organization.dependency.id
				organization = tower_organization.dependency.name
			}

			resource "tower_host" "test" {
				name = "tf-acc-test-update-%[1]s"
				inventory = tower_inventory.dependency.id
				description = "hello there"
				variables = jsonencode({"fields":[{"id":"token","label":"none"}]})
			}`, randomID)

			check := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host.test", "inventory", "tower_inventory.dependency", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host.test", "enabled", "true",
				),
			)

			updateCheck := resource.ComposeTestCheckFunc(
				resource.TestCheckResourceAttrSet(
					"tower_host.test", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host.test", "name", fmt.Sprintf("tf-acc-test-update-%[1]s", randomID),
				),
				testAccCompareAttributes(
					"tower_host.test", "inventory", "tower_inventory.dependency", "id",
				),
				resource.TestCheckResourceAttr(
					"tower_host.test", "variables", `{"fields":[{"id":"token","label":"none"}]}`,
				),
				resource.TestCheckResourceAttr(
					"tower_host.test", "description", "hello there",
				),
			)

			testCase(t, config, check, updateConfig, updateCheck)
		})
	})

	t.Run("groups", func(t *testing.T) {
		t.Run("add", func(t *testing.T) {
			t.Run("single", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-organization-%[1]s"
					}
	
					resource "tower_inventory" "dependency" {
						name = "tf-acc-test-inventory-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}

					resource "tower_host_group" "dependency" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
					}
	
					resource "tower_host" "test" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
						groups = [tower_host_group.dependency.id]
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "1",
					),
				)

				testCase(t, config, check)
			})

			t.Run("all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-organization-%[1]s"
					}
	
					resource "tower_inventory" "dependency" {
						name = "tf-acc-test-inventory-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}

					resource "tower_host_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
						inventory = tower_inventory.dependency.id
					}

					resource "tower_host_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
						inventory = tower_inventory.dependency.id
					}

					resource "tower_host_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
						inventory = tower_inventory.dependency.id
					}
	
	
					resource "tower_host" "test" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
						groups = [tower_host_group.dependency1.id, tower_host_group.dependency2.id, tower_host_group.dependency3.id]
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "3",
					),
				)

				testCase(t, config, check)
			})

			t.Run("single_to_all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
					groups = [tower_host_group.dependency1.id, tower_host_group.dependency2.id]
				}`, randomID)

				updateConfig := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host_group" "dependency3" {
					name = "tf-acc-test-%[1]s-3"
					inventory = tower_inventory.dependency.id
				}


				resource "tower_host" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
					groups = [tower_host_group.dependency1.id, tower_host_group.dependency2.id, tower_host_group.dependency3.id]
				}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "2",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "3",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})
		})

		t.Run("remove", func(t *testing.T) {
			t.Run("single", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-organization-%[1]s"
					}
	
					resource "tower_inventory" "dependency" {
						name = "tf-acc-test-inventory-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}

					resource "tower_host_group" "dependency" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
					}
	
					resource "tower_host" "test" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
						groups = [tower_host_group.dependency.id]
					}`, randomID)

				updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-organization-%[1]s"
					}
	
					resource "tower_inventory" "dependency" {
						name = "tf-acc-test-inventory-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}

					resource "tower_host_group" "dependency" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
					}
	
					resource "tower_host" "test" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "1",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "0",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})

			t.Run("all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-organization-%[1]s"
					}
	
					resource "tower_inventory" "dependency" {
						name = "tf-acc-test-inventory-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}

					resource "tower_host_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
						inventory = tower_inventory.dependency.id
					}

					resource "tower_host_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
						inventory = tower_inventory.dependency.id
					}

					resource "tower_host_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
						inventory = tower_inventory.dependency.id
					}
	
	
					resource "tower_host" "test" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
						groups = [tower_host_group.dependency1.id, tower_host_group.dependency2.id, tower_host_group.dependency3.id]
					}`, randomID)

				updateConfig := fmt.Sprintf(`
					resource "tower_organization" "dependency" {
						name = "tf-acc-test-organization-%[1]s"
					}
	
					resource "tower_inventory" "dependency" {
						name = "tf-acc-test-inventory-%[1]s"
						organization_id = tower_organization.dependency.id
						organization = tower_organization.dependency.name
					}

					resource "tower_host_group" "dependency1" {
						name = "tf-acc-test-%[1]s-1"
						inventory = tower_inventory.dependency.id
					}

					resource "tower_host_group" "dependency2" {
						name = "tf-acc-test-%[1]s-2"
						inventory = tower_inventory.dependency.id
					}

					resource "tower_host_group" "dependency3" {
						name = "tf-acc-test-%[1]s-3"
						inventory = tower_inventory.dependency.id
					}
	
	
					resource "tower_host" "test" {
						name = "tf-acc-test-%[1]s"
						inventory = tower_inventory.dependency.id
					}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "3",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "0",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})

			t.Run("single_from_all", func(t *testing.T) {
				testCase := func(t *testing.T, config string, check resource.TestCheckFunc, updateConfig string, updateCheck resource.TestCheckFunc) {
					resource.Test(t, resource.TestCase{
						PreCheck:  func() { TestAccPreCheck(t) },
						Providers: testAccProviders,
						Steps: []resource.TestStep{
							{
								Config: config,
								Check:  check,
							},
							{
								Config: updateConfig,
								Check:  updateCheck,
							},
						},
					})
				}

				config := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host_group" "dependency3" {
					name = "tf-acc-test-%[1]s-3"
					inventory = tower_inventory.dependency.id
				}


				resource "tower_host" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
					groups = [tower_host_group.dependency1.id, tower_host_group.dependency2.id, tower_host_group.dependency3.id]
				}`, randomID)

				updateConfig := fmt.Sprintf(`
				resource "tower_organization" "dependency" {
					name = "tf-acc-test-organization-%[1]s"
				}

				resource "tower_inventory" "dependency" {
					name = "tf-acc-test-inventory-%[1]s"
					organization_id = tower_organization.dependency.id
					organization = tower_organization.dependency.name
				}

				resource "tower_host_group" "dependency1" {
					name = "tf-acc-test-%[1]s-1"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host_group" "dependency2" {
					name = "tf-acc-test-%[1]s-2"
					inventory = tower_inventory.dependency.id
				}

				resource "tower_host" "test" {
					name = "tf-acc-test-%[1]s"
					inventory = tower_inventory.dependency.id
					groups = [tower_host_group.dependency1.id, tower_host_group.dependency2.id]
				}`, randomID)

				check := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "3",
					),
				)

				updateCheck := resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttrSet(
						"tower_host.test", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "name", fmt.Sprintf("tf-acc-test-%[1]s", randomID),
					),
					testAccCompareAttributes(
						"tower_host.test", "inventory", "tower_inventory.dependency", "id",
					),
					resource.TestCheckResourceAttr(
						"tower_host.test", "groups.#", "2",
					),
				)

				testCase(t, config, check, updateConfig, updateCheck)
			})
		})
	})

}
