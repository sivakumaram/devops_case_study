package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func resourceOrganization() *schema.Resource {
	return &schema.Resource{
		Create: resourceOrganizationCreate,
		Read:   resourceOrganizationRead,
		Update: resourceOrganizationUpdate,
		Delete: resourceOrganizationDelete,
		Importer: &schema.ResourceImporter{
			State: resourceOrganizationImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"description": {
				Type:        schema.TypeString,
				Optional:    true,
				Default:     "",
				Description: "Optional description of this organization.",
			},
			"max_hosts": {
				Type:        schema.TypeInt,
				Optional:    true,
				Default:     0,
				Description: "Maximum number of hosts allowed to be managed by this organization.",
			},
			"custom_virtualenv": {
				Type:        schema.TypeString,
				Optional:    true,
				Description: "Local absolute file path containing a custom Python virtualenv to use",
			},
			"instance_groups": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeInt,
				},
				Default: nil,
			},
		},
	}
}

func resourceOrganizationCreate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "organizations/"
	return organizationEndpoint("POST", endpoint, d, meta)
}

func resourceOrganizationRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "organizations/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating new request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	if _, err = BodyToMap(res.Body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	return nil
}
func resourceOrganizationUpdate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "organizations/" + d.Id() + "/"

	return organizationEndpoint("PUT", endpoint, d, meta)
}

func resourceOrganizationDelete(d *schema.ResourceData, meta interface{}) error {
	endpoint := "organizations/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("DELETE", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}
	if res.StatusCode != http.StatusNoContent {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
			nil,
			res.Body,
		)
	}

	d.SetId("")

	return nil
}

func resourceOrganizationImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "organizations/" + d.Id() + "/"

	name := d.Id()
	d.Set("name", name)

	org, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fecthing organization: %s", err)
	}

	d.SetId(strconv.Itoa(int(org["id"].(float64))))

	d.Set("type", int(org["type"].(float64)))
	d.Set("url", string(org["url"].(string)))
	d.Set("created", string(org["created"].(string)))
	d.Set("modified", string(org["modified"].(string)))
	d.Set("max_hosts", int(org["max_hosts"].(float64)))
	d.Set("description", string(org["description"].(string)))
	d.Set("custom_virtualenv", string(org["custom_virtualenv"].(string)))

	return []*schema.ResourceData{d}, nil
}

func organizationEndpoint(verb, endpoint string, d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	reqBody, err := json.Marshal(map[string]interface{}{
		"name":              d.Get("name").(string),
		"description":       d.Get("description").(string),
		"max_hosts":         d.Get("max_hosts").(int),
		"custom_virtualenv": d.Get("custom_virtualenv").(string),
	})

	if err != nil {
		return fmt.Errorf("error marshalling request body: %s", err)
	}

	client := config.Client(endpoint)
	req, err := http.NewRequest(verb, client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}
	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			reqBody,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	organizationID := int(body["id"].(float64))
	d.SetId(strconv.Itoa(int(organizationID)))

	igs, err := GetAllResourceIGs("organizations/", organizationID, meta)
	// Check if instance_groups exist already
	if len(igs) > 0 {
		if err != nil {
			return fmt.Errorf("error getting groups: %s", err)
		}

		for i, val := range igs {
			ig := int(val.(map[string]interface{})["id"].(float64))
			if err = RemoveIGfromResource("organizations/", organizationID, meta, ig); err != nil {
				return fmt.Errorf("error removing instance group: %d with error: %s on loop %d", ig, err, i)
			}
		}
	}

	// Add all instance groups to inventory
	if err = AddIGstoResource("organizations/", organizationID, d.Get("instance_groups"), meta); err != nil {
		return err
	}

	return resourceOrganizationRead(d, meta)
}
