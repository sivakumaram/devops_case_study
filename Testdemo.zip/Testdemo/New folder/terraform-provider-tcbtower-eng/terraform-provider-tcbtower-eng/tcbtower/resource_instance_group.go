package tcbtower

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/hashicorp/terraform-plugin-sdk/helper/schema"
)

func resourceInstanceGroup() *schema.Resource {
	return &schema.Resource{
		Create: resourceInstanceGroupCreate,
		Read:   resourceInstanceGroupRead,
		Update: resourceInstanceGroupUpdate,
		Delete: resourceInstanceGroupDelete,
		Importer: &schema.ResourceImporter{
			State: resourceInstanceGroupImport,
		},

		Schema: map[string]*schema.Schema{
			"name": {
				Type:     schema.TypeString,
				Required: true,
			},
			"credential": {
				Type:     schema.TypeString,
				Optional: true,
				Default:  ``,
			},
			"policy_instance_percentage": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  0,
			},
			"policy_instance_minimum": {
				Type:     schema.TypeInt,
				Optional: true,
				Default:  0,
			},
			"policy_instance_list": {
				Type:     schema.TypeList,
				Optional: true,
				Elem: &schema.Schema{
					Type: schema.TypeString,
				},
				Default: nil,
			},
			"pod_spec_override": {
				Type:     schema.TypeString,
				Optional: true,
			},
		},
	}
}

func resourceInstanceGroupCreate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "instance_groups/"
	return instanceGroupEndpoint("POST", endpoint, d, meta)
}

func resourceInstanceGroupRead(d *schema.ResourceData, meta interface{}) error {

	endpoint := "instance_groups/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("GET", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating new request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if res.StatusCode != http.StatusOK {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK),
			nil,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	if _, err = BodyToMap(res.Body); err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	return nil
}
func resourceInstanceGroupUpdate(d *schema.ResourceData, meta interface{}) error {
	endpoint := "instance_groups/" + d.Id() + "/"

	return instanceGroupEndpoint("PUT", endpoint, d, meta)
}

func resourceInstanceGroupDelete(d *schema.ResourceData, meta interface{}) error {
	endpoint := "instance_groups/" + d.Id() + "/"
	config := meta.(*Config)

	client := config.Client(endpoint)
	req, err := http.NewRequest("DELETE", client.url, nil)
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}
	if res.StatusCode != http.StatusNoContent {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusNoContent),
			nil,
			res.Body,
		)
	}

	d.SetId("")

	return nil
}

func instanceGroupEndpoint(verb, endpoint string, d *schema.ResourceData, meta interface{}) error {
	config := meta.(*Config)

	reqBody, err := json.Marshal(map[string]interface{}{
		"name":                       d.Get("name").(string),
		"credential":                 d.Get("credential").(string),
		"policy_instance_percentage": d.Get("policy_instance_percentage").(int),
		"policy_instance_minimum":    d.Get("policy_instance_minimum").(int),
		"policy_instance_list":       d.Get("policy_instance_list").([]interface{}),
		"pod_spec_override":          d.Get("pod_spec_override").(string),
	})

	if err != nil {
		return fmt.Errorf("error marshalling request body: %s", err)
	}

	client := config.Client(endpoint)
	req, err := http.NewRequest(verb, client.url, bytes.NewBuffer(reqBody))
	if err != nil {
		return fmt.Errorf("error creating request: %s", err)
	}

	if err = setAuthHeader(meta, req); err != nil {
		return fmt.Errorf("error setting authorization headers: %s", err)
	}

	req.Header.Set("Content-Type", "application/json")

	res, err := client.client.Do(req)
	if err != nil {
		return fmt.Errorf("HTTP request failed with error: %s", err)
	}

	if !(res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated) {
		return ResponseError(
			StatusCodeFailed(res.Request.Method, client.url, res.StatusCode, http.StatusOK, http.StatusCreated),
			reqBody,
			res.Body,
			checkExistsIDSyncFunc(d),
		)
	}

	body, err := BodyToMap(res.Body)
	if err != nil {
		return fmt.Errorf("failed to parse body with error %s", err)
	}

	instanceGroupID := body["id"].(float64)
	d.SetId(strconv.Itoa(int(instanceGroupID)))

	return resourceInstanceGroupRead(d, meta)
}

func resourceInstanceGroupImport(d *schema.ResourceData, meta interface{}) ([]*schema.ResourceData, error) {
	endpoint := "instance_groups/"

	name := d.Id()
	d.Set("name", name)

	instanceGroup, err := getEntry(meta, endpoint, name)
	if err != nil {
		return nil, fmt.Errorf("error fetching instance groups: %s", err)
	}

	d.SetId(strconv.Itoa(int(instanceGroup["id"].(float64))))

	d.Set("url", string(instanceGroup["url"].(string)))
	d.Set("instanceGroup_id", int(instanceGroup["id"].(float64)))
	d.Set("created", string(instanceGroup["created"].(string)))
	d.Set("modified", string(instanceGroup["modified"].(string)))
	d.Set("name", string(instanceGroup["name"].(string)))
	d.Set("credential_id", int(instanceGroup["credential"].(float64)))
	d.Set("jobs_running", int(instanceGroup["jobs_running"].(float64)))
	d.Set("jobs_total", int(instanceGroup["jobs_total"].(float64)))
	d.Set("policy_instance_percentage", int(instanceGroup["policy_instance_percentage"].(float64)))
	d.Set("policy_instance_minimum", int(instanceGroup["policy_instance_minimum"].(float64)))
	d.Set("pod_spec_override", string(instanceGroup["pod_spec_override"].(string)))

	return []*schema.ResourceData{d}, nil
}
