## Contributing

### Important References:
- [Tower API Reference](https://docs.ansible.com/ansible-tower/latest/html/towerapi/api_ref.html): All of the providers work interfaces closely with the Tower API. This is where you will find all the information that you need in order to create and modify sources. While the Tower API documentation is relative reliable there are times when you may need to poke at the API with curl or Postman to find 'secret' parameters or investigate other scattered Tower documentation where they are referenced. This is however uncommon and the API Reference is generally sufficient.
- [Hashicorp Extending Terraform](https://www.terraform.io/docs/extend/index.html): This is the main documentation for the plugin framework. Everything from standards to implementation details exist in these pages. 
- [Google Provider](https://github.com/hashicorp/terraform-provider-google): It can be useful to reference existing work especially work that is official. This is the Google provider and can be useful to reference within the code.

### New Source Guidlines
This project leverages automated templates to handle initial setups for each added source. This is handled by a script called `new_source.go` in the [tools](../tools) folder. To begin creating a new source run this script with `go run new_source.go newSourceName` and then fill in any necessary changes between the `[ ]` left in the template files.
- All resources and data names should be singular ( i.e. credential over credentials).
- If a new resource/data is added a new associated markdown file must be created in [docs](./)(automated in script) and linked in the main [README](../README.md#automatable-dataresource-on-ansible-tower) (manually). 
- If a new resource/data is added the file structure on the main [README](../README.md#usage) must be updated (manually).
- All resource/data must have a complete list of inputs as well as working examples (These must be formatted using nginx syntax highlighting. Refer to existing files in [docs](./).)

### New Parameter Guidlines
- If a new parameter is added to a pre-existing resource/data, the parameter must be added in both the parameter list and the examples found in the resource/data markdown file in [docs](./).

### Conventions
- This repository prefers generalized functions over specific functions.

### Semantic Versioning

This project makes use of Semantic versioning(SemVer) to control the automatic  release cycle of versions. Thus, bump tags __must__ be included at the end of pull requests. 
If no semver tag is provided in the title, all builds of the provider will fail until a new pull request is made with the correct tag in its title. For more details about the standard please visit the [Semver](https://semver.org/) website.


| SemVer Tags | SemVer Numbering |
|-------------|------------------|
| major.minor.patch | 0.0.0 |


<details><summary>Example Titles</summary>

- CIA-0000: Made massive breaking changes `#major`
- CIA-0001: Added a new feature that lightly changes functionality `#minor`
- CIA-0002: Fixed a minor bug `#patch`

</details>



### Submitting a pull request

1. Clone the repository
1. Create a new branch: `git checkout -b my-ticket-name`
1. Make your change, add tests, and make sure the tests still pass
1. Push to your branch and submit a pull request
1. Pat your self on the back and wait for your pull request to be reviewed and merged.


### Resources

- [Using Pull Requests](https://help.github.com/articles/about-pull-requests/)
- [GitHub Help](https://help.github.com)
- [Various Linting Tools](https://github.com/golangci/awesome-go-linters)