# tower_workflow_run

- [Resource: Create and Manage](./WORKFLOW_RUN.md#resourcetower_workflow_run) 
  - [Example](./WORKFLOW_RUN.md#resource-example)

------------------------------
## resource.tower_workflow_run
```Create and Manage``` a new workflow run on Ansible Tower
  - **name** *(string)*: name of the template minus "_create"/"_delete".
  - **inventory** *(int, optional)*: ID of the inventory to use with the workflow template
  - **credential** *(int, optional)*: ID of the credential to use with the workflow template
  - **credentials** *(list[int], optional)*: ID's of the credential to use with the workflow template
  - **extra_vars** *(string, optional)*: yaml or json formatted string of variables for the workflow template to use
  - **no_delete** *(bool, optional)*: If this is set to true the workflow will not be managed with a delete and any runs will be permanent with regards to terraform state management. If this flag is true there is no _create/_delete postpended to name in search.
  - **no_update** *(bool, optional)*: Set to true to skip update calls
  - **retries** *(int, optional)*: Amount of times to rerun the job run if it returns an error
  - **retries_delay** *(string, optional)*: Time to wait between retries
  - **status_check_retries** *(int, optional)*: Number of times the status of the job will be checked before timing out and assuming failure. Default: 4000
  - **status_check_retries_delay** *(string, optional)*: Time to wait between calls to the API to check for completion status. Default: 3s
  - **artifact_data_type** *(string, optional)*: the format to save artifact_data in for nested maps. Default: yaml, options are: yaml, json
  - **success_on_job_fail** *(bool, optional)*: Whether or not to treat job failures as successful resource creation
  - **start_time** *(string, computed)*: time of API call to start the most recent workflow run (read, create, check, or delete). Formatted as yyyy-mm-dd hh:mm:ss to be compatible with sql
  - **end_time** *(string, computed)*: time at the end of most recent workflow run (read, create, check, or delete) if successfully completed. Formatted as yyyy-mm-dd hh:mm:ss to be compatible with sql. Time will have an error bounded by the chosen `status_check_retries_delay` interval
  - **retries** *(int, optional)*: Amount of times to rerun the workflow run if it returns an error

NOTE: The workflow templates should come in pairs unless `no_delete` is set to `true`, one for create (ending in "_create") and one for delete (ending in "_delete"). The beginning should be the same. If `no_delete` flag is set, a regular tower workflow run will be launched with no postpend.



##### Resource Example
```nginx
resource "tower_workflow_run" "wrname" {
  # REQUIRED
  name = "<template-name-on-tower>"    # name of the template on tower without "_create", "_delete"

  # OPTIONAL
  # For each optional variable for tower (inventory, credential, extra_vars)
  # the associated "prompt on launch" checkbox must be checked on the job template
  # within tower or they will not work!

  inventory   = tower_inventory.iname.id                      # <inventory-id>
  credential  = data.tower_credential.cname.id                # <credential-id>
  credentials = [<credential-id-1>, <credential-id-2>, ...]   # list of credential ids
  extra_vars  = file("<filename.yml or filename.json>") # extra variables to include in job run
  no_delete   = false           # set to true if there is no delete job template 
  status_check_retries = 4000                                 # number of retries when waiting for the job to finish
  status_check_retries_delay    = "3s"                                 # time to wait between retries
  artifact_data_type   = "yaml"                               # format to use for nested maps in artifact_data. Either "yaml" (default) or "json"
  success_on_job_fail = false                                 # Whether or not to treat job failure as successful resource creation
  retries            = 3    
  retries_delay        = "60s"                                  # Time to delay between retries

  # COMPUTED
  # changes     = <number-of-changes-discovered>  # Found in state file
  # skips       = <number-of-skips-discovered>    # Found in state file
  # artifact_data = <mapping-of-artifacts-set-with-set_stats> # See description in section 3.09 - tower_job_run
  # start_time = "<time-at-start>"
  # end_time   = "<time-at-end>"

  # REQUIRED IF CREATING HOSTS
  depends_on = [              # list any resource this template needs that cannot be implicitly inferred
    tower_host.hname
  ]
}

```

------------------------------
