# TESTING
The terraform tower provider leverages both testing tools provided by Terraform Enterprise's Plugin framework for acceptance tests against a live Ansible Tower API and unit tests to test utility functions for activities such as flatten API responses. Each resource, data source, and miscellaneous function will have associated tests to expedite the development process and increase confidence in our production software. Many of these data sources and resources rely on full functionality so it is expected that more than one test will fail if faults are introduced into the provider. Below is a summary of all the tests that are needed:


## Data Sources
Data Sources are used to read and reference pre-existing infrastructure within Terraform managed infrasture.


### Credential:
`TestAccCredentialDataSource/basic/id_from_name`:
This test is to verify that when the Credential Data Source is given a valid name it is capable of resolving the associated resource ID on tower. This proves that it is capable of syncing with Tower and accessing the resources attributes.

Future Efforts: In the future tests need to be added to verify each of the Credential's additional attributes also sync within the Terraform state.

    Live API: Yes
    Implemented: Yes


### Credential Type:
`TestAccCredentialTypeDataSource/basic/id_from_name`:
This test is to verify that when the Credential Type Data Source is given a valid name it is capable of resolving the associated resource ID on tower. This proves that it is capable of syncing with Tower and accessing the resources attributes.

Future Efforts: In the future tests need to be added to verify each of the Credential Type's additional attributes also sync within the Terraform state.

    Live API: Yes
    Implemented: Yes

### Instance Group:
`TestAccInstanceGroupDataSource/basic/id_from_name`:
This test is to verify that when the Instance Group Data Source is given a valid name it is capable of resolving the associated resource ID on tower. This proves that it is capable of syncing with Tower and accessing the resources attributes.

Future Efforts: In the future tests need to be added to verify each of the Instance Group's additional attributes also sync within the Terraform state.

    Live API: Yes
    Implemented: Yes

### Inventory:
`TestAccInventoryDataSource/basic/id_from_name`:
This test is to verify that when the Inventory Data Source is given a valid name it is capable of resolving the associated resource ID on tower. This proves that it is capable of syncing with Tower and accessing the resources attributes.

Future Efforts: In the future tests need to be added to verify each of the Inventory's additional attributes also sync within the Terraform state.

    Live API: Yes
    Implemented: Yes

### Job Template:
`TestAccJobTemplateDataSource/basic/id_from_name`:
This test is to verify that when the Job Template Data Source is given a valid name it is capable of resolving the associated resource ID on tower. This proves that it is capable of syncing with Tower and accessing the resources attributes.

Future Efforts: In the future tests need to be added to verify each of the Job Template's additional attributes also sync within the Terraform state.

    Live API: Yes
    Implemented: Yes


Additional Concerns: Due to the interconnected nature of _create and _delete templates this testing may need to be expanded even further.

### Organization:
`TestAccOrganizationDataSource/basic/id_from_name`:
This test is to verify that when the Organization Data Source is given a valid name it is capable of resolving the associated resource ID on tower. This proves that it is capable of syncing with Tower and accessing the resources attributes.

Future Efforts: In the future tests need to be added to verify each of the Organization's additional attributes also sync within the Terraform state.

    Live API: Yes
    Implemented: Yes


### Project:
`TestAccProjectDataSource/basic/id_from_name`:
This test is to verify that when the Project Data Source is given a valid name it is capable of resolving the associated resource ID on tower. This proves that it is capable of syncing with Tower and accessing the resources attributes.

Future Efforts: In the future tests need to be added to verify each of the Project's additional attributes also sync within the Terraform state.

    Live API: Yes
    Implemented: Yes


## Resources
Resources are used to create, read, update, and delete infrastructure through Terraform.


### Credential:
`TestAccCredentialResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes

### Credential Type:
`TestAccCredentialTypeResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes

### Group:
`TestAccGroupResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes

### Host:
`TestAccHostResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes

`TestAccHostResource/groups`:
- `/add/single`: This test is to verify that a host can be added to a single group
- `/add/all`: This test is to verify that a host can be added to a list of groups
- `/remove/single`: This test is to verify that a host can be removed to a single group
- `/remove/all`: This test is to verify that a host can be removed to a list of groups

    Live API: Yes
    Implemented: Yes


### Instance Group:
`TestAccInstanceGroupResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes

### Iventory:
`TestAccIventoryResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes

`TestAccIventoryResource/InstanceGroup`:
- `/add` This test is to verify that the provider is capable of adding Instance Groups to this Inventory.
- `/change` This test is to verify that the provider is capable of changing which Instance Groups this Inventory has.
-  `/remove` This test is to verify that if the Inventory is assigned Instance Groups they can also be removed cleanly.

    Live API: Yes
    Implemented: Yes


### Job Run:
`TestAccJobRunResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of running a create job on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of re-running the job with modifications.
-  `/delete` This test is to verify that if given a valid Terraform destroy the provider is capable of running a delete job on Tower
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.


`TestAccJobRunResource/misc`:
- `/artifact` This test is to verify that the provider is capable of gathering and storing artifact information from a job that Sets artifacts.

    Live API: Yes
    Implemented: No


`***********TEST ON HOLD***********`

### Job Template:
`TestAccJobTemplateResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes


### Organization:
`TestAccOrganizationResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.
  
    Live API: Yes
    Implemented: Yes

`TestAccOrganizationResource/InstanceGroup`:
- `/add` This test is to verify that the provider is capable of adding Instance Groups to this Organization.
- `/change` This test is to verify that the provider is capable of changing which Instance Groups this Organization has.
-  `/remove` This test is to verify that if the Organization is assigned Instance Groups they can also be removed cleanly.

    Live API: Yes
    Implemented: yes

### Project:
`TestAccProjectResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: Yes

### Workflow Run:
`TestAccWorkflowRunResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of running a workflow's create job on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of re-running the workflow with modifications.
-  `/delete` This test is to verify that if given a valid Terraform destroy the provider is capable of running a delete workflow on Tower.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.


`TestAccJobRunResource/misc`:
- `/artifact` This test is to verify that the provider is capable of gathering and storing artifact information from a workflow's job that Sets artifacts.

    Live API: Yes
    Implemented: No

`***********TEST ON HOLD***********`


### Workflow Template:
`TestAccWorkflowTemplateResource/basic`:
- `/create` This test is to verify that given a valid Terraform configuration the provider is capable of creating the correct infrastructure on Tower.
- `/update` This test is to verify that given a valid Terraform re-configuration the provider is capable of updating the infrastructure on Tower without error.
-  `/delete` This test is to verify that if infrastructure is created on Tower it is cleanly removable without errors.
- `/read` There is no test for this directly but each of the previous tests leverages this functionality repeatedly.

    Live API: Yes
    Implemented: No

`TestAccWorkflowTemplateResource/workflow_template_nodes/add`:
- `/single`: This test is to verify that a single set of workflow node configurations can be added to a the workflow template
- `/all`: This test is to verify that a list of workflow node configurations can be added to a the workflow template
- `/single_to_all`: This test is to verify that a node configuration can be appended to an existing node configuration on a workflow template

`TestAccWorkflowTemplateResource/workflow_template_nodes/remove`:
- `/single`: This test is to verify that a single set of workflow node configurations can be removed from a workflow template
- `/all`: This test is to verify that a list of workflow node configurations can be removed from a workflow template
- `/single_to_all`: This test is to verify that a single node configuration can be removed from an existing list of node configurations

### Miscellaneous
`TestAccResolveOrganization`: 
- `/id` This test is to verify that given an Organization id the provider is capable of resolving the associated name.
- `/name` This test is to verify that given an Organization name the provider is capable of resolving the associated id.
- `/requiredfail` This test is to verify that if the Organization information is required but not supplied the function fails.
- `/requiredsuccess` This test is to verify that if the Organization information is required and supplied the function succeeds.
- `/optional` This test is to verify that if the Organization information is not required it doesn't have to be supplied.

    Live API: Yes
    Implemented: No

`This test has been removed due to limitations of Hashicorp's plugin framework. This test would still be useful to have if they ever address these limitations.`

## Unit Tests

`Test_setItem`: 
- `/setFloat` This test is to verify that given a float to set the function is capable of properly setting it in the passed dictionary.
- `/setBool` This test is to verify that given a boolean to set the function is capable of properly setting it in the passed dictionary.
- `/setString` This test is to verify that given a string to set the function is capable of properly setting it in the passed dictionary.
- `/setList` This test is to verify that given a list of mixed types to set the function is capable of properly setting them in the passed dictionary.

    Live API: No
    Implemented: No

`This test has been removed due to limitations of Hashicorp's plugin framework. This test would still be useful to have if they ever address these limitations.`


`Test_Unmarshal`: 
- `/basic_JSON` This test is to verify that given a string of JSON, Unmarshal returns the correct map.
- `/basic_YAML` This test is to verify that given a string of YAML, Unmarshal returns the correct map.
- `/bad_JSON` This test is to verify that given a string of incorrect JSON, Unmarshal returns an error.
- `/bad_YAML` This test is to verify that given a string of incorrect YAML, Unmarshal returns an error.

    Live API: No
    Implemented: Yes

`Test_checkExistsIDSync`: 
- `/exists` This test is to verify that if a message does not contain the phrase "does not exist" the id held in the dictionary remains untouched.
- `/does_not_exist` This test is to verify that if a message does contain the phrase "does not exist" the id held in the dictionary is set to nothing.

    Live API: No
    Implemented: Yes