# tower_workflow_template

- [Data: Read Existing](./WORKFLOW_TEMPLATE.md#datatower_workflow_template) 
  - [Example](./WORKFLOW_TEMPLATE.md#data-example)

- [Resource: Create and Manage](./WORKFLOW_TEMPLATE.md#resourcetower_workflow_template) 
  - [Example](./WORKFLOW_TEMPLATE.md#resource-example)

------------------------------

## data.tower_workflow_template
```Read Existing``` workflow template from Ansible Tower.
  - **name** *(string)*: exact name of workflow template on Tower.

      Returns workflow_template_id, type, description, status, limit, scm_branch, inventory*

##### Data Example
```nginx
data "tower_workflow_template" "wname" {
  name = "<name-on-tower>"    # name of existing workflow template on tower.

  # Computed
  # workflow_template_id    = "<workflow_template_id>"      # id of the workflow template
  # type             		= "<type>"        				# job type of the workflow template
  # description          	= "<description>"        		# description of the workflow template
  # status          		= "<status>"        			# status of the workflow template
  # limit          			= "<limit>"        				# limit of the workflow template
  # scm_branch          	= "<scm_branch>"        		# scm branch of the workflow template

  # inventory          	= "<inventory>"        		# inventory of the workflow template
}

```
------------------------------
## resource.tower_workflow_template
```Create and Manage``` a new workflow template on Ansible Tower.
  - **name** *(string)*: name of the template(s) minus "_create"/"_delete".
  - **description** *(string, optional)*: Optional description to display in the templates on Tower.
  - **extra_vars** *(string, optional)*: yaml or json formatted string of variables for the workflow template to use.
  - **organization_id** *(int, optional)*: id of the organization to associate with this resource on Tower.
  - **nodes** *(string, optional)*: yaml formatted string of nodes to add to the workflow. See "Examples" below for format.
  - `option flags` *(bool)*: The following boolean options are available for launch:
    -  **ask_inventory_on_launch**: default: true
    -  **ask_variables_on_launch**: default: true
    -  **ask_job_type_on_launch**: Whether to prompt job type (check, run) on launch, if set to false and enable_concurrent_jobs set to true, race conditions can occur.
    -  **enable_concurrent_jobs**: whether or not concurrent jobs can run for this workflow
  - **inventory** *(int, optional)*: id of the inventory to use with the workflow template. 

NOTE: `nodes` can also be yaml files by using file("filename.yml"). The only required attributes for a node are `job_type` and `unified_job_template`.

##### Resource Example
```nginx
resource "tower_workflow_template" "wrname" {
  # REQUIRED
  name = "<template-name-on-tower>"    # name of the template on tower to append "_create" and "_delete"

  # OPTIONAL
  description   = "..."                                       # <inventory-id>
  extra_vars  = file("<filename.yml or filename.json>")       # extra variables to include in with every run
  organization_id =  <organization-id-on-tower>
  inventory       =   <inventory-id-on-tower>
  ask_inventory_on_launch = true
  ask_variables_on_launch = true

  nodes = <<EOF
---
- job_type: run              # or check
  inventory: <id>            # optional if inventory is supplied in the job template
  verbosity: 0               # optional
  credential: <id>           # optional
  unified_job_template: <id> # id of the job template to run for this node
  always_nodes:              # nodes to run if this one succeeds or fails
    - ... # same structure as above
  success_nodes:              # nodes to run if this one succeeds
    - ... # same structure as above
  failure_nodes:              # nodes to run if this one fails
    - ... # same structure as above
EOF

```

------------------------------
