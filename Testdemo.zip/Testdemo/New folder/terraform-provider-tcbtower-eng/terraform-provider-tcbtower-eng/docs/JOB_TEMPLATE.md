# tower_job_template

- [Data: Read Existing](./JOB_TEMPLATE.md#datatower_job_template) 
  - [Example](./JOB_TEMPLATE.md#data-example)

- [Resource: Create and Manage](./JOB_TEMPLATE.md#resourcetower_job_template) 
  - [Example](./JOB_TEMPLATE.md#resource-example)

------------------------------
## data.tower_job_template
```Read Existing``` job template from Ansible Tower.
  - **name** *(string)*: exact name of job template on Tower
  
      *Returns id, inventory, and credential.*

##### Data Example
```nginx
data "tower_job_template" "jtname" {
  # REQUIRED
  name              = "<job-template-name-for-tower>"
  # Computed
  # id = <job_template-id-on-tower>
  # inventory = <inventory-on-tower>
  # credential = <credential-on-tower>
}
```

------------------------------

## resource.tower_job_template
```Create and Manage``` a new job template on Ansible Tower.
  - **name** *(string)*: name of the template(s) minus "_create"/"_delete"
  - **project_id** *(int)*: name of the project linked to the template
  - **playbook** *(string)*: name of the playbook to run
  - **job_type** *(string)*: Default run behavior: run or check. Defaults to run. Set to "check" only if this job will never be launched as a "run" type job.
  - **verbosity** *(int)*: verbosity of the job
  - **job_tags** *(string, optional)*: a comma separated list of tags to associate with this job
  - **skip_tags** *(string, optional)*: a comma separated list of skip tags to associate with this job
  - **extra_vars** *(string, optional)*: YAML formatted string of variables to persistently attach to the job template. JSON is also supported though perfect results are not guaranteed.
  - **wait_for_jobless_retries** *(int)*: number of retries when waiting for project source updates
  - **wait_for_jobless_time** *(string)*: time to wait in between retries for project source updates
  - `option flags` *(bool)*: The following boolean options are available for launch:
    -  **ask_inventory_on_launch**
    -  **ask_credential_on_launch**
    -  **ask_variables_on_launch**
    -  **ask_job_type_on_launch**: Whether to prompt job type (check, run) on launch, if set to false and enable_concurrent_jobs set to true, race conditions can occur.
    -  **ask_scm_branch_on_launch**: whether or not to prompt source branch. Default(true). Requires project to allow branch override
    -  **enable_concurrent_jobs**: whether or not concurrent jobs can run for this job
    -  **become_enabled**: whether or not to run this job as `become`
    -  **update_project_on_create**: whether or not the project source should be updated before creating
  - DEPRECATED: **organization** *(string)*: name of the organization associated with this job
  - **organization_id** *(int)*: ID of the organization associated with this job
  - **inventory** *(int, optional)*: id of the inventory to use with the job template. 
  - **credentials** *(list[int])*: List of credentials to assign to the job on launch
  - **description** *(string)*: Description of the templates purpose
  - **instance_groups** *(list[int])*: a list of the ID's of instance groups to associate with this job template

##### Resource Example
```nginx
resource "tower_job_template" "jtname" {
  # REQUIRED
  name              = "<job-template-name-for-tower>"
  project_id        = tower_project.pname.id           # "<project-id-on-tower>"
  playbook          = "playbook"          # name of playbook in project to use without _create.yml, _delete.yml
  organization =  <organization-name-on-tower>

  # OPTIONAL
  implement_destroy        = false     # Deprecated: set to false if there is no destroy playbook
  job_type                 = "run"     # can be changed to "check" but then no changes will occur
  inventory                = 0         # inventory to run this  job on.
  verbosity                = 0         # verbosity level. Default 0
  become_enabled           = false     # set to true for become privileges
  credentials              = [1,4]     # list of credential ID's to attach to a job
  update_project_on_create = false     # whether or not project source should be updated on create
  organization_id          = <organization-id-on-tower>
  job_tags                 = "Tag1, Tag2, Tag3"
  skip_tags                = "Tag1, Tag2, Tag3"
  ask_inventory_on_launch  = true
  ask_variables_on_launch  = true
  ask_credential_on_launch = true
  inventory                = 0
  instance_groups          = [1, 2, 3] # The ID's of instance groups. it is recommended to use `data.tower_instance_groups.<name>.id` for each element

  # EITHER
  extra_vars               = file("<filename.yaml or filename.json>")
  # OR
  extra_vars = <<EOF
---
extra: variables
are: fun
EOF
  # END

  # DEPRECATED
  # organization =  <organization-name-on-tower>
  # template_create_id = <template-id-for-create>
  # template_delete_id = <template-id-for-delete>
}

```

------------------------------
