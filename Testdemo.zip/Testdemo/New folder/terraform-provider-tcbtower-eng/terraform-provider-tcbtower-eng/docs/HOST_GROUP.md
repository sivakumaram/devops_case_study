# tower_host_group

- [Resource: Create and Manage](./HOST_GROUP.md#resourcetower_host_group) 
  - [Example](./HOST_GROUP.md#resource-example)

------------------------------

## resource.tower_host_group
```Create and Manage``` a new host group on Ansible Tower.
  - **name** *(string)*: name of the host group to create
  - **inventory** *(int)*: id of the inventory to add the host group to
  - **variables** *(string, optional)*: yaml or json formatted string of variables for the group to use


##### Resource Example
```nginx
resource "tower_host_group" "gname" {
  # REQUIRED
  name      = "<group-name-for-tower>"
  inventory = tower_inventory.iname.id        # <inventory-id>

  # OPTIONAL
  variables = file("</path/to/filename.yml or /path/to/filename.json>")
}
```

------------------------------
