# tower_schedule

- [Data: Read Existing](./SCHEDULE.md#datatower_schedule) 
  - [Example](./SCHEDULE.md#data-example)

- [Resource: Create and Manage](./SCHEDULE.md#resourcetower_schedule) 
  - [RRULE Info](./SCHEDULE.md#rrule-info)
  - [Example](./SCHEDULE.md#resource-example)

------------------------------
## data.tower_schedule
```Read Existing``` schedule from Ansible Tower.
  - **name** *(string)*: exact name of schedule on Tower
  
      *Returns id, description, rrule, unified_job_template_id, inventory, scm_branch, job_type, job_tags, skip_tags, limit, diff_mode, verbosity, enabled, dtstart, dtend, and next run where applicable.*


##### Data Example
```nginx
data "tower_schedule" "someschedule" {
  # Required
  name = "<name-on-tower>"    # name of existing schedule. Use schedule resource to create a new one

  # Computed
  # description = <known-after-apply>
  # rrule = <known-after-apply>
  # unified_job_template = <known-after-apply>
  # inventory = <known-after-apply>
  # scm_branch = <known-after-apply>
  # job_tags = <known-after-apply>
  # skip_tags = <known-after-apply>
  # limit = <known-after-apply>
  # diff_mode = <known-after-apply>
  # verbosity = <known-after-apply>
  # enabled = <known-after-apply>
  # dtstart = <known-after-apply>
  # dtend = <known-after-apply>
  # next_run = <known-after-apply>
}

```
------------------------------
## resource.tower_schedule
```Create and Manage``` a new schedule on Ansible Tower.
  - **name** *(string, required)*: name of the schedule to create
  - **rrule** *(string)*: A value representing the schedules iCal recurrence rule
  - **description** *(string)*: description of the created schedule
  - **unified_job_template** *(int)*: The id of the job template to assign the schedule to
  - **extra_data** *(YAML/JSON)*: Whatever extra variables to be associated with the new schedule
  - **inventory** *(int)*: The id of the inventory on tower to associate with this schedule
  - **scm_branch** *(string)*: default = ""
  - **job_type** *(string)*: default = "" - (must be configured to prompt on launch)
  - **job_tags** *(string)*: default = "" - (must be configured to prompt on launch)
  - **skip_tags** *(string)*: default = "" - (must be configured to prompt on launch)
  - **limit** *(string)*: default = "" - (must be configured to prompt on launch)
  - **diff_mode** *(bool)*: default = None - (must be configured to prompt on launch)
  - **verbosity** *(int)*: choice. From 0 to 5. Default=None - (must be configured to prompt on launch)
  - **enabled** *(bool)*: Enables processing of this schedule


NOTE: While both are optional, either the schedule must have an associated inventory or the associated unified job template must have an inventory in order to create a new schedule.

##### RRULE Info: 
================

The following lists the expected format and details of our rrules:

DTSTART is required and must follow the following format: DTSTART:YYYYMMDDTHHMMSSZ
DTSTART is expected to be in UTC
INTERVAL is required
SECONDLY is not supported
TZID is not supported
RRULE must precede the rule statements
BYDAY is supported but not BYDAY with a numerical prefix
BYYEARDAY and BYWEEKNO are not supported
Only one rrule statement per schedule is supported
COUNT must be < 1000
Here are some example rrules:

"DTSTART:20500331T055000Z RRULE:FREQ=MINUTELY;INTERVAL=10;COUNT=5" "DTSTART:20240331T075000Z RRULE:FREQ=DAILY;INTERVAL=1;COUNT=1" "DTSTART:20140331T075000Z RRULE:FREQ=MINUTELY;INTERVAL=1;UNTIL=20230401T075000Z" "DTSTART:20140331T075000Z RRULE:FREQ=WEEKLY;INTERVAL=1;BYDAY=MO,WE,FR"

Warning: Schedules will be implicitly deleted if their associated unified job template is destroyed. The associated unified job template can be switched with another one but this transfer must happen before the other is deleted. 


##### Resource Example
```nginx
resource "tower_schedule" "schedulename" {
    name = "<cool-new-name>"
    description = "hello there"
    rrule = "DTSTART;TZID=America/Denver:20200214T171700 RRULE:FREQ=DAILY;INTERVAL=1;COUNT=1"
    unified_job_template = tower_job_template.dependency.id
    inventory = tower_inventory.dependency.id
	extra_data = <<EOF
---
extra_data:
    key:"val"
EOF
}

```

------------------------------
