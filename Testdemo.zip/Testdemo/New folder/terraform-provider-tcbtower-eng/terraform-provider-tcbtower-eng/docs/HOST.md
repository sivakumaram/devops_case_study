# tower_host

- [Resource: Create and Manage](./HOST.md#resourcetower_host) 
  - [Example](./HOST.md#resource-example)

------------------------------

## resource.tower_host
```Create and Manage``` a new host on Ansible Tower.
  - **name** *(string)*: name of the host to create (ex. ip address, url)
  - **inventory** *(int)*: ID of the inventory to add the host to
  - **groups** *(list[int], optional)*: list of host group IDs to add this host into
  - **description** *(string, optional)*: description of this inventory
  - **variables** *(string, optional)*: yaml or json formatted string of variables for the host to use
  - **enabled** *(bool, optional)*: whether or not this host should be enabled


##### Resource Example
```nginx
resource "tower_host" "hname" {
  # REQUIRED
  name      = "<ip-address-or-url>"
  inventory = tower_inventory.iname.id        # <inventory-id-to-add-host-onto>

  # OPTIONAL
  enabled     = true                               # Default true
  description = "..."                              # Description for the host
  groups      = [tower_host_group.gname.id, ...]   # list of groups this host should belong to
  variables = file("</path/to/filename.yml or /path/to/filename.json>")
}
```

------------------------------
