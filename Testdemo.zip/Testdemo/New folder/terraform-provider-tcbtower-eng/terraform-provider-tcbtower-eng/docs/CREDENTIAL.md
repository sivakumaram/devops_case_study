# tower_credential

- [Data: Read Existing](./CREDENTIAL.md#datatower_credential) 
  - [Example](./CREDENTIAL.md#data-example)

- [Resource: Create and Manage](./CREDENTIAL.md#resourcetower_credential) 
  - [Example](./CREDENTIAL.md#resource-example)

------------------------------
## data.tower_credential
```Read Existing``` credential data Ansible Tower.
  - **name** *(string)*: exact name of credential on Tower
 
      *Returns id.*

##### Data Example
```nginx
data "tower_credential" "cname" {
  name = "<name-on-tower>"    # name of existing credential. Use resource "tower_credential" to create a new one

  # Computed
  # credential_id = <credential-id-on-tower>
}
```

------------------------------

## resource.tower_credential
```Create and Manage``` a new credential on Ansible Tower.
  - **name** *(string)*: name of the credential to create
  - **type** *(string)*: type of the credential to create (ex. "Machine")
  - **inputs** *(YAML/JSON)*: Inputs for the new credential - visible in terraform logs
  - **sensitive_inputs** *(YAML/JSON)*: Inputs for the new credential - invisible in terraform logs
  - **inputs_source** *(list[string] as YAML/JSON)*: Specifies the source of inputs for backend. Must look like:
    ```yaml
    ---
    - input_field_name: "<input-to-set-source-for>"
      metadata:
        secret_key: "<name-of-secret-backend-key>"
        secret_path: "<name-of-path-to-credential-including-store>"
      source_credential: "<integer-value-for-id-associated-with-secret-backend>"
    - etc.
    ```
  - DEPRECATED: **organization** *(string, optional)*: name of the organization to associate with this resource on Tower
  - **organization_id** *(int, optional)*: id of the organization to associate with this resource on Tower

##### Resource Example
With inputs:
```nginx
resource "tower_credential" "cname_with_inputs" {
  # REQUIRED
  name            = "<credential-name-for-tower>"
  type            = "<type-of-credential>"

  # COMPUTED
  type_id         =  <type-id>
  organization_id =  <organization-id-on-tower>

  # OPTIONAL
  description     = "..."
  inputs          = <<EOF
---
username: "<username-associated-with-credential>"
password: "<password-associated-with-username-for-credential>"
token: "<some-api-token-in-secret-backend>"
EOF
  # OR
  sensitive_inputs          = <<EOF
---
token: "<some-super-secret-info-no-one-can-see>"
EOF

  organization_id =  <organization-id-on-tower>

  # DEPRECATED: 
  organization =  <organization-name-on-tower>
}

```
With inputs_source:
```nginx
resource "tower_credential" "cname_with_source" {
  # REQUIRED
  name            = "<credential-name-for-tower>"
  type            = "<credential-type-id-on-tower>
  
  # COMPUTED
  organization_id =  <organization-id-on-tower>
  type_id         =  <type-id>

  #OPTIONAL
  description     = "..."
  inputs_source = <<EOF
--- 
- input_field_name: "token"
  metadata:
    secret_key: "key_name"
    secret_path: "/key/path/"
  source_credential: "key_source_id
EOF

  # Organization name OR id can be passed as a parameter.
  organization =  <organization-name-on-tower>
  # or
  organization_id =  <organization-id-on-tower>
  # Whichever is not passed will be computed.
}

```

`inputs` and/or `inputs_source` argument can be leveraged.


------------------------------
