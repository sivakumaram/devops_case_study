# tower_project

- [Data: Read Existing](./PROJECT.md#datatower_project) 
  - [Example](./PROJECT.md#data-example)

- [Resource: Create and Manage](./PROJECT.md#resourcetower_project) 
  - [Example](./PROJECT.md#resource-example)

------------------------------
## data.tower_project
```Read Existing``` project from Ansible Tower.
  - **name** *(string)*: exact name of project on Tower
  
      *Returns id, organization_id, description, scm_type, scm_url, scm_branch, scm_delete_on_update, scm_update_on_update..*

##### Data Example
```nginx
data "tower_project" "dpname" {
  # REQUIRED
  name = "<existing-project-name-for-tower>"

  # COMPUTED
  # organization_id        =   <organization-id-on-tower>
  # description            =  "<description-of-the-inventory>"
  # scm_type               =  "<source-control-type>"
  # scm_url                =  "<source-control-url>"
  # scm_branch             =  "<source-control-branch>"
  # scm_delete_on_update   =   <source-control-delete-on-update>
  # scm_update_on_update   =   <source-control-update-on-update>
}

```
------------------------------

### resource.tower_project
```Create and Manage``` a new project on Ansible Tower.
  - **name** *(string)*: name of the project to create on Tower
  - DEPRECATED: **organization** *(string)*: name of the organization to associate with this resource on Tower
  - **organization_id** *(int)*: id of the organization to associate with this resource on Tower
  - **scm_type** *(string, optional)*: the type of source control management ex: "git"
  - **scm_url** *(string, optional)*: url to the repo for source control management
  - **scm_branch** *(string, optional)*: specific branch to use for the repo
  - **scm_delete_on_update** *(bool, optional)*: whether or not the the repo on tower should be deleted locally when an update is made to the repo
  - **scm_update_on_launch** *(bool, optional)*: whether or not the repo on tower should be updated locally when a job template is launched
  - **scm_update_cache_timeout** *(int, optional)*: time before the cache is invalidated
  - **allow_branch_override** *(bool, optional)*: whether or not to allow overriding branch in job template - Default(true)
    
##### Resource Example
```nginx
resource "tower_project" "pname" {
  # REQUIRED
  name         = "<template-name-on-tower>"         # name of the template on tower
  organization_id =  <organization-id-on-tower>

  # OPTIONAL
  description  = "..."                        # description to show on tower
  scm_type     = "<source-control-type>"      # ex. "git"
  scm_url      = "<source-repo-url>"          # git project repo link
  scm_branch   = "<source-branch-name>"       # if other than master
  scm_delete_on_update = false                # whether or not to delete the local repo on repo update
  scm_update_on_launch = true                 # whether or not to update the local repo on launch
  scm_update_cache_timeout = 0                # the number of seconds after the last project update ran that new project update will be launched as a job dependency
  credential  = data.tower_credential.cname.id                # <credential-id>
  allow_branch_override = true                # whether or not to allow branch override in job template/job launch

  # COMPUTED
  # playbooks = ["playbook1.yml", "playbook2.yml", ...]  # (NOT WORKING) list of playbooks for project

  
  # DEPRECATED
  organization =  <organization-name-on-tower>
}

```
------------------------------