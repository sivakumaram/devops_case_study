# tower_inventory

- [Data: Read Existing](./INVENTORY.md#datatower_inventory) 
  - [Example](./INVENTORY.md#data-example)

- [Resource: Create and Manage](./INVENTORY.md#resourcetower_inventory) 
  - [Example](./INVENTORY.md#resource-example)

------------------------------
## data.tower_inventory
```Read Existing``` inventory from Ansible Tower.
  - **name** *(string)*: exact name of inventory on Tower.
 
      *Returns id, organization id, description, and total hosts*

##### Data Example
```nginx
data "tower_inventory" "iname" {
  # REQUIRED
  name = "<existing-inventory-name-for-tower>"

  # COMPUTED
  # organization_id = <organization-id-on-tower>
  # description = "<description-of-the-inventory>"
  # total_hosts = <number-of-hosts-in-inventory>
}

```

------------------------------

## resource.tower_inventory
```Create and Manage``` a new inventory on Ansible Tower.
  - **name** *(string)*: name of the inventory to create on Tower
  - **description** *(string)*: description of the inventory to associate with this resource on Tower.
  - DEPRECATED: **organization** *(string)*: name of the organization to associate with this resource on Tower
  - **organization_id** *(int)*: id of the organization to associate with this resource on Tower
  - **variables** *(string, optional)*: yaml or json formatted string of variables for the inventory to use
  - **kind** *(string, optional)*: kind of inventory to create - "" or "smart", default is ""
  - **instance_groups** *(list[int])*: a list of the ID's of instance groups to associate with this inventory


##### Resource Example
```nginx
resource "tower_inventory" "iname" {
  # REQUIRED
  name         = "<inventory-name-for-tower>"
  organization_id =  <organization-id-on-tower>

  # OPTIONAL
  description         = "<inventory-description-for-tower>"
  variables = file("</path/to/filename.yml or /path/to/filename.json>")
  kind = "<kind-of-inventory>"
  instance_groups = [<list-of-ids>] # list of instance group ids to associate with this inventory

  # DEPRECATED
  organization =  <organization-name-on-tower>
}

```
------------------------------