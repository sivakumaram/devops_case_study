# tower_group

- [Resource: Create and Manage](./GROUP.md#resourcetower_group) 
  - [Example](./GROUP.md#resource-example)

------------------------------

## resource.tower_group
```Create and Manage``` a new group on Ansible Tower.
- **name** *(string)*: name of the group to create
- **inventory** *(int)*: ID of the inventory to associate with this group
- **variables** *(YAML/JSON)*: variables to associate with this group

##### Resource Example
```nginx
resource "tower_group" "gname" {
  # REQUIRED
  name            = "<group-name-on-tower>"
  inventory       = <ID-of-inventory>

  # OPTIONAL
  variables       = <<EOF
---
key: "value"
some: "variable"
EOF

}
```
------------------------------