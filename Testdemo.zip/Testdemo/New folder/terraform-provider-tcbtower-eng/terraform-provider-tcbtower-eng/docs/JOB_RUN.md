# tower_job_run

- [Resource: Create and Manage](./JOB_RUN.md#resourcetower_job_run) 
  - [Example](./JOB_RUN.md#resource-example)
  - [Remarks On Artifact Data](./JOB_RUN.md#remarks-on-artifact_data)

------------------------------
### resource.tower_job_run
```Create and Manage``` a new job run on Ansible Tower.
  - **name** *(string)*: name of the template minus "_create"/"_delete".
  - **inventory** *(int, optional)*: id of the inventory to use with the job template. Optional if inventory was supplied in job template config.
  - **credential** *(int, optional)*: id of the credential to use with the job template
  - **delete_inventory** *(int, optional)*: id of the inventory to use with the job template on delete if different then the one for create.
  - **delete_credential** *(int, optional)*: id of the credential to use with the job template on delete if different then the one for create
  - **retries** *(int, optional)*: Amount of times to rerun the run if it returns an error
  - **retries_delay** *(string, optional)*: Time to wait between retries
  - **extra_vars** *(string, optional)*: yaml or json formatted string of variables for the job template to use
  - **status_check_retries** *(int, optional)*: Number of times the status of the job will be checked before timing out and assuming failure. Default: 4000
  - **status_check_retries_delay** *(string, optional)*: Time to wait between calls to the API to check for completion status. Default 3s
  - **no_delete** *(bool, optional)*: If this is set to true the job will not be managed with a delete and any runs will be permanent with regards to terraform state management. If this flag is true there is no _create/_delete postpended to name in search.
  - **no_update** *(bool, optional)*: Set to true to skip update calls
  - **success_on_job_fail** *(bool, optional)*: Whether or not to treat job failures as successful resource creation
  - **artifact_data_type** *(string, optional)*: the format to save artifact_data in for nested maps Default: yaml, options are: yaml, json.
  - **branch_override** *(string, optional)*: branch to launch job with. Default("")
  - **artifact_data** *(map, computed)*: A calculated map[string]string capturing the artifacts set during the job run on tower with "set_stats" 
  - **start_time** *(string, computed)*: time of API call to start the most recent job run (read, create, check, or delete). Formatted as yyyy-mm-dd hh:mm:ss to be compatible with sql. *(Previously job_start_time)*
  - **end_time** *(string, computed)*: time at the end of most recent job run (read, create, check, or delete) if successfully completed. Formatted as yyyy-mm-dd hh:mm:ss to be compatible with sql. Time will have an error bounded by the chosen `status_check_retries_delay` interval. *(Previously job_end_time)*
 

NOTE: The job templates should come in pairs unless `no_delete` is set to `true`, one for create (ending in "_create") and one for delete (ending in "_delete"). The beginning should be the same. If `no_delete` flag is set, a regular tower job run will be launched with no postpend.

##### Resource Example
Job Run HCL
```nginx
resource "tower_job_run" "jrname" {
  # REQUIRED
  name         = "<project-name-on-tower>"    # name of the project on tower without "_create", "_delete"

  # OPTIONAL
  # For each optional variable for tower (inventory, credential, extra_vars)
  # the associated "prompt on launch" checkbox must be checked on the job template
  # within tower or they will not work!

  inventory   = tower_inventory.iname.id                      # <inventory-id>
  credential  = data.tower_credential.cname.id                # <credential-id>
  credentials = [<credential-id-1>, <credential-id-2>, ...]   # list of cred  ential ids
  extra_vars  = file("<filename.yml or filename.json>")       # extra variables to include in job run
  no_delete   = false                                         # set to true if there is no delete job template 
  no_update   = false                                         # Set to true to skip update calls (will return nil) 
  status_check_retries = 4000                                 # number of retries when waiting for the job to finish
  status_check_retries_delay    = "3s"                                 # time to wait between retries
  artifact_data_type   = "yaml"                               # format to use for nested maps in artifact_data. Either "yaml" (default) or "json"
  retries            = 3    
  retries_delay        = "60s"                                  # Time to delay between retries
  delete_inventory   = tower_inventory.diname.id                      # <inventory-id-for-delete-run>
  delete_credential  = data.tower_credential.dcname.id                # <credential-id-for-delete-run>
  success_on_job_fail = false                                 # Whether or not to treat job failure as successful resource creation
  branch_override = ""                                        # Optional branch to launch with

  # COMPUTED
  # changes        = <number-of-changes-discovered>            # Found in state file
  # skips          = <number-of-skips-discovered>              # Found in state file
  # artifact_data  = <mapping-of-artifacts-set-with-set_stats> # See description below
  # start_time = "<time-at-start>"
  # end_time   = "<time-at-end>"

  # REQUIRED IF CREATING HOSTS
  depends_on = [              # list any resource this template needs that cannot be implicitly inferred
    tower_host.hname
  ]
}

```


#### Remarks on artifact_data

  If a playbook being run on tower with resource tower_job_run featured the task:


  ```yaml
  - set_stats:
      data:
        ip_address: "00.240.24.10"
        inventory_name: "test-host"
  ```

  A resources for an inventory with a host could access the values like so:

  ```nginx
  resource "tower_job_run" "job" {
    name = "job_template_with_artifacts"
  }

  resource "tower_inventory" "inv" {
    name = tower_job_run.job.artifact_data.inventory_name
    organization = "some organization name"
  }

  resource "tower_host" "host" {
    name = tower_job_run.job.artifact_data.ip_address
    inventory = tower_inventory.inv.id
  }
  ```

  **Notes:**
  - Non-string primitive types are converted to strings in outermost map.
  - Nested structures are saved as yaml or json formatted strings.
  - jsondecode or yamldecode to access inner structure key/values pairs.

------------------------------
