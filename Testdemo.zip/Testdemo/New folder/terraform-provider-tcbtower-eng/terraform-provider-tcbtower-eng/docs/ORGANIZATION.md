# tower_organization

- [Data: Read Existing](./ORGANIZATION.md#datatower_organization) 
  - [Example](./ORGANIZATION.md#data-example)

- [Resource: Create and Manage](./ORGANIZATION.md#resourcetower_organization) 
  - [Example](./ORGANIZATION.md#resource-example)

------------------------------
## data.tower_organization
```Read Existing``` organization from Ansible Tower.
  - **name** *(string)*: exact name of credential type on Tower.
  
      *Returns id, type, url, created, modified, max_hosts, description, and custom_virtualenv.*


##### Data Example
```nginx
data "tower_organization" "orgname" {
  # Required
  name = "<name-on-tower>"    # name of existing organization. Use organization resource to create a new one

  # Computed
  # type = <known-after-apply>
  # url = <known-after-apply>
  # created = <known-after-apply>
  # modified = <known-after-apply>
  # max_hosts = <known-after-apply>
  # description = <known-after-apply>
  # custom_virtualenv = <known-after-apply>
}

```

------------------------------

## resource.tower_organization
```Create and Manage``` a new organization on Ansible Tower.
  - **name** *(string)*: name of the organization to create.
  - **credential** *(int)*: credential of the instance group to create.
  - **policy_instance_percentage** *(int)*: policy_instance_percentage of the instance group to create.
  - **policy_instance_minimum** *(int)*: policy_instance_minimum of the instance group to create.
  - **policy_instance_list** *(string)*: name of the instance group to create.
  - **pod_spec_override** *(string)*: pod_spec_override of the instance group to create.
  - **instance_groups** *(list[int])*: a list of the ID's of instance groups to associate with this organization

##### Resource Example
```nginx
resource "tower_organization" "orgname" {
  # Required
  name = "Test_Organization"

  # Optional
  description = "..."
  max_hosts = 50
  custom_virtualenv = "/some/path/to/stuff/"
  instance_groups = [1, 2, 3] # The ID's of instance groups. it is recommended to use `data.tower_instance_groups.<name>.id` for each element
}

```

------------------------------
