# tower_instance_group

- [Data: Read Existing](./INSTANCE_GROUP.md#datatower_instance_group) 
  - [Example](./INSTANCE_GROUP.md#data-example)

- [Resource: Create and Manage](./INSTANCE_GROUP.md#resourcetower_instance_group) 
  - [Example](./INSTANCE_GROUP.md#resource-example)

------------------------------

## data.tower_instance_group
```Read Existing``` instance group from Ansible Tower.
  - **name** *(string)*: exact name of instance group on Tower.

      Returns type, url, capacity, jobs_running, jobs_total, instances, controller, and credential.*

##### Data Example
```nginx
data "tower_instance_group" "cname" {
  name = "<name-on-tower>"    # name of existing instance group on tower.

  # Computed
  # url          = "<url>"        # url to the instance group connection
  # capacity     = <capacity>     # capacity of the instance group
  # jobs_running = <jobs-running> # number of jobs running on the instance group
  # jobs_total   = <total-jobs>   # total jobs connected to instance group
  # instances    = <instances>    # number of instance in the group
  # controller   = <controller>   # the id for the controller if any
  # credential   = <credential>   # the id for the credential if any
}

```
------------------------------

## resource.tower_instance_group
```Create and Manage``` a new instance group on Ansible Tower.
  - **name** *(string)*: name of the instance group to create
  - **description** *(string)*: Optional description of this organization
  - **max_hosts** *(int)*: Maximum number of hosts allowed to be managed by this organization
  - **custom_virtualenv** *(string)*: Local absolute file path containing a custom Python virtualenv to use


##### Resource Example
```nginx
resource "tower_instance_group" "igname" {
  # REQUIRED
  name                        = "<name-of-instance-group>"

  # OPTIONAL
  credential                  = "<type-of-credential>"
  policy_instance_percentage  =  <policy-instance-percentage-number>
  policy_instance_minimum     =  <policy-instance-minimum-number>
  policy_instance_list        =  ["<policy-instance-list>"]
  pod_spec_override           =  "<pod-spec-override>"
}

```
------------------------------
