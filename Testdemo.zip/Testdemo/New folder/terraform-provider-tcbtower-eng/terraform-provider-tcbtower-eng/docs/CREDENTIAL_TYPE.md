# tower_credential_type

- [Data: Read Existing](./CREDENTIAL_TYPE.md#datatower_credential_type) 
  - [Example](./CREDENTIAL_TYPE.md#data-example)

- [Resource: Create and Manage](./CREDENTIAL_TYPE.md#resourcetower_credential_type) 
  - [Example](./CREDENTIAL_TYPE.md#resource-example)

------------------------------
## data.tower_credential_type
```Read Existing``` credential type from Ansible Tower.
  - **name** *(string)*: exact name of credential type on Tower
  
      *Returns id, kind, and description.*


##### Data Example
```nginx
data "tower_credential_type" "ctname" {
  name = "<name-on-tower>"    # name of existing credential type. Use resource "tower_credential_type" to create a new one

  # Computed
  # id          = <credential-id-on-tower>
  # description = <description-on-tower>
  # kind        = <kind-on-tower>
  # inputs      = <inputs-on-tower>
  # injectors   = <injectors-on-tower>
}

```

------------------------------

## resource.tower_credential_type
```Create and Manage``` a new credential type on Ansible Tower.
  - **name** *(string)*: name of the credential type to create
  - **kind** *(string)*: kind of the credential type to create (Options are: cloud, net)
  - **namespace** *(string)*: namespace to create the credential type in 
  - **inputs** *(YAML/JSON)*: Inputs for the new credential type
  - **injectors** *(YAML/JSON)*: Injectors for the new credential type


##### Resource Example
```nginx
resource "tower_credential_type" "ctname" {
  # REQUIRED
  name   = "<credential_type-name-for-tower>"

  inputs = <<EOF
---
fields: 
    id: "api_token",
    label: "API Token",
    secret: true,
    type: "string"
required:["api_key"]
EOF

  injectors = <<EOF
---
extra_vars:
  CLOUD_TOKEN: {{api_token}}
EOF

  # OPTIONAL

  kind            = "<kind-of-credential_type>" # Options are: cloud, net  \ Default is: cloud
  description     = "..."
  namespace       = ""
}

```

------------------------------
