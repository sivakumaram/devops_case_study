# snow ansible module
## 1. About
<details><summary><b>Click to expand</b></summary>
This repository defines the configuration for SNow API calls, mostly the SNow tables in order to retrieve any data that is needed for the IT3 deployment project. 

- Ability to make create, modify, and delete SNow CI Records

- Ability to use GET, PUT, PATCH, and DELETE CI Records

- In conjuction with Tower-Snow-Actions for creating and deleting CI Records

  https://github.com/robops/tower-snow-actions.git
  
</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 2. File Structure
<details><summary><b>Click to expand</b></summary>

### 2.1. Brief Description of Files

``` 
Ansible-Snow-Module/
├── defaults/
|   └── main.yml                           <-- Default variable values for role
├── meta/
|   └── main.yml                           <-- Role dependencies 
├── tasks/
|   ├── main.yml                           <-- Bulk of ansbile snow tasks
|   ├── aci_app_profile.yml                <-- Handles the get, create, and delete of CI records in the u_aci_app_profiles SNow table
|   ├── aci_epg.yml                        <-- Handles the get, create, and delete of CI records in the u_aci_epgs SNow table
|   ├── aci_service.yml                    <-- Handles the get, create, and delete of CI records in the u_it3_aci_services SNow table
|   ├── attachment.yml                     <-- Handles file attachments to the SNow tables
|   ├── business_application.yml           <-- Handles the get of CI records in the cmdb_ci_business_app SNow table
|   ├── business_application_instance.yml  <-- Handles the get of CI records in the u_cmdb_busapp_instance SNow table
|   ├── change.yml                         <-- Handles the changing of CI records 
|   ├── check_sys_id.yml                   <-- Verifies the sys_id
|   ├── ci.yml                             <-- Handles the get, create, retire, and delete of CI records 
|   ├── ci_relationships.yml               <-- Handles the table relationship of the CI records in SNow
|   ├── data_maps.yml                      <-- Handles the get of CI records in the u_data_map SNow table
|   ├── dns_domain.yml                     <-- Handles the get of CI records in the u_cmdb_ci_dns_domain SNow table
|   ├── dns_name.yml                       <-- Handles the get, create, and retire of CI records in the cmdb_ci_dns_name SNow table
|   ├── environment.yml                    <-- Handles the get of CI records in the cmdb_ci_environment SNow table
|   ├── get_name.yml                       <-- Handles the get and verifies the name and instance number of the name
|   ├── groups.yml                         <-- Handles the get of CI records in the sys_user_group SNow table
|   ├── instance_location.yml              <-- Handles the get of CI records in the cmdb_ci_datacenter SNow table
|   ├── ip_address.yml                     <-- Handles the get, create, update, and retire of IP Address CI records in the SNow tables
|   ├── it3_accounts.yml                   <-- Handles the get and delete of CI records in the u_it3_accounts SNow table
|   ├── it3_catalog_choices.yml            <-- Handles the get, create, update, and delete of CI records in the u_it3_catalog_choices SNow table
|   ├── it3_catalog_prices.yml             <-- Handles the get, create, update, and delete of CI records in the u_it3_catalog_pricing SNow table
|   ├── it3_playbook.yml                   <-- Handles the get and retire of CI records in the u_it3_playbooks SNow table
|   ├── line_of_business.yml               <-- Handles the get of CI records in the u_cmdb_ci_line_of_business SNow table
|   ├── network_adapter.yml                <-- Handles the get, create, update, and retire of CI records in the cmdb_ci_network_adapter SNow table
|   ├── requested_items.yml                <-- Handles the get of CI records in the sc_req_item SNow table
|   ├── risk_category.yml                  <-- Handles the get of CI records in the u_test_risk_category SNow table
|   ├── risk_container.yml                 <-- Handles the get of CI records in the u_test_risk_container SNow table
|   ├── security_zone.yml                  <-- Handles the get of CI records in the u_test_security_zone SNow table
|   ├── server_functions.yml               <-- Handles the get of CI records in the u_it3_server_functions SNow table
|   ├── snow_request.yml                   <-- Handles the get, create, update, and delete of snow requests 
|   ├── software_product_model.yml         <-- Handles the get of CI records in the cmdb_software_product_model SNow table
|   ├── solution_central.yml               <-- Handles the get of CI records in the u_cmdb_ci_solution_central_asset_list SNow table
|   ├── task.yml                           <-- Handles the get and create (SNow comments) of CI records in the sc_task SNow table
|   └── users.yml                          <-- Handles the get of CI records in the sys_user SNow table
├── tests/
|   ├── main.yml                           <-- Testing the ansible snow module
|   └── install_role.yml                   <-- Installs the tfe-mgmt role from Github Worldpay
└── README.md                              <-- You are here
```
</details>
