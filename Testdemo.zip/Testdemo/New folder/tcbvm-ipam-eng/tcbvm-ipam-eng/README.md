# tcbvm-ipam
## 1. About
<details><summary><b>Click to expand</b></summary>
API calls to IPAM for VM IP Addressing

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 2. File Structure
<details><summary><b>Click to expand</b></summary>
  
``` tcbvm-ipam/
├── roles/
|   └── ipam_request/                           <-- Role to handle ipam API requests and static ip setting
|       ├── defaults/
|       ├── tasks/
|       |    └── api_request.yml                <-- Playbook to trigger IPAM API
|       |    └── bastion.yml                    <-- Playbook to retrieve bastion from the csv file using location and risk-container
|       |    └── dns_addresses.yml              <-- Playbook to retrieve dns_servers from csv file using network address
|       |    └── location_format_change.yml     <-- Playbook to change location name's format that matches for IPAM API standards
|       |    └── main.yml                       <-- Main playbook to select either IPAM API or static request
|       |    └── static_ip.yml                  <-- Playbook to trigger functions with static IP
|       |    └── vsphere_network_converter.yml  <-- Playbook to convert risk container and security zone to new format 
|       └── templates/                          
├── files/
|   └── bastion-info.csv                        <-- CSV file for Bastion
|   └── dns_address_information.csv             <-- CSV file for DNS
|   └── network_address_information.csv         <-- CSV file for Network Address
├── request_ip_create.yml                       <-- Playbook to run ipam role for IP request
├── tower_setup_variables.tf                    <-- Variable file for Tower resource setup
├── tower_setup.tf                              <-- Resources for Tower to create job with request_ip_create.yml
└── README.md                                   <-- You are here
```

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 3. Terraform Automatic Setup
<details><summary><b>Click to expand</b></summary>

### 3.1. About
Attaching this repo to a Terraform Enterprise workspace will automate configuration of resources on Ansible Tower to run the IPAM IP requests.

### 3.2. Variables

```
1. tower_host           | string | url to tower api | default("https://tower.test-lab.local/api/v2/")
2. tower_token          | string | oauth token for tower authentication | default(none)
3. allow_unverified_ssl | bool   | whether or not to allow unverified ssl connections to tower | default(true)
4. organization         | string | organization to create resources on | default("james's organization")
5. scm_type             | string | type of connection for source control management | default("git")
6. scm_url              | string | url to this repository | default("https://github.test.com/robops/tcbvm-ipam")
7. scm_branch           | string | branch to use of this repository | default("master")
```

</details>

--------------------------------------------------------------------------------------------------------------------------------------
## 4. IPAM IP Request
<details><summary><b>Click to expand</b></summary>

### 4.1. Request IP Playbook
The playbook request_ip_create.yml should be run as a job on Ansible Tower with the resources created in section 3.

### 4.2. Required Extra Variables for Primary IP

```
1. operation             | string | type of request | default("add")
2. risk_category         | string | default("development")
3. risk_container        | string | default("unknown")
4. ipam_url              | string | api endpoint for IPAM | default("https://console-d.dynecon.com/ipmanagement/rest/v2/ipaddress_assign")
5. ipam_api_key          | string | api authentication key
6. requesting_user       | string | e/lc number of requesting user
7. RITM_number           | string | snow request number
8. hostname              | string | hostname of virtual machine
9. domain_name           | string | domain name to join virtual machine to
00. ipam_assignment_type | string | options are: appliance, backup, bastion, drac, ilo, lb_vip, nas, server, server_vip, vm_guest, vm_host
11. related_ci_key       | string | configuration item url
12. compute_environment  | string | generation of the converged infrastructure network
13. location             | string | datacenter location
14. ipam_network-usage   | string | the usage type for ip assignment
15. security_zone        | string | default("unkown")
16. automatable          | string | determines if the network can be used in automation
17. business_app         | string | URL of business application table with sysid
18. static_ip_list       | string | A list of IP's. Overrides ipam's external request. 
00. defaultGateway       | string | The default gateway is only required if a static_ip_list is provided. Needed to find network address and DNS servers.
```
### 4.3. Required Extra Variables for Backup IP

```
1. operation             | string | type of request | default("add")
2. risk_category         | string | set to "production"
3. risk_container        | string | set to "bkup"
4. ipam_url              | string | api endpoint for IPAM | default("https://console-d.dynecon.com/ipmanagement/rest/v2/ipaddress_assign")
5. ipam_api_key          | string | api authentication key
6. requesting_user       | string | e/lc number of requesting user
7. RITM_number           | string | snow request number
8. hostname              | string | hostname of virtual machine, - BKUP added to host name
9. domain_name           | string | domain name to join virtual machine to
00. ipam_assignment_type | string | option for backup ip is: backup
11. related_ci_key       | string | configuration item url
12. compute_environment  | string | generation of the converged infrastructure network
13. location             | string | datacenter location
14. ipam_network-usage   | string | the usage type for ip assignment
15. security_zone        | string | set to "bkup"
16. automatable          | string | determines if the network can be used in automation
17. business_app         | string | URL of business application table with sysid
18. static_ip_list       | string | A list of IP's. Overrides ipam's external request. 
19. defaultGateway       | string | The default gateway is only required if a static_ip_list is provided. Needed to find network address and DNS servers.
```
### 4.4. Parameter Options
1. <b>operation</b>: add, modify (wip), delete (wip)
2. <b>comments</b>: length < 256 characters
3. <b>requesting_user</b>: length < 256 characters
4. <b>RITM_number</b>: length < 256 characters, ex. RITM1234567890, CH123456789012
5. <b>hostname</b>: a-z, A-Z, 0-9, -, no underscores (_), no periods (.), can't end in -vip, see confluence for additional security reqs.
6. <b>domain_name</b>: a-z, A-Z, 0-9, -, no underscores (_), periods (.)
7. <b>ipam_assignment_type</b>: appliance, backup, bastion, drac, ilo, lb_vip, nas, server, server_vip, vm_guest, vm_host
8. <b>related_ci_key</b>: configuration item url. cmdb_ci_server, cmdb_ci_netgear, or cmdb_ci_hardware
9. <b>compute_environment</b>: gen1/2, gen3
00. <b>location</b>: bdc_brown_deer, lrk_little_rock, mke_cape, pdc_chandler, vor_voorhees
11. <b>ipam_network_usage</b>: lb_vip_b2b, lb_vip_internal, lb_vip_internet, repl, server, tools, transit_block
12. <b>risk_category</b>: corporate, development, production, tools
13. <b>risk_container</b>: bkup, bpy_billpay, crt_credit, dbt_debit, dev, test_test_corporate, gfs_lnpci, gfs_lpci, glbv_global_lb_vip, inf_infrastructure
14. <b>risk_container (continued)</b>: itb_internet_banking, lnpci, lpci, lpi, mbl_mobile_banking, mrss, ppd_prepaid, stt_security_test_team, tools, unknown, vce_enterprise_voice.
15. <b>security_zone</b>: app, bastion, bkup, data, global_lb_vip, ilo, netadmin, repl, web
16. <b>automatable</b>: yes, no
17. <b>business_app</b>: Business Application URL
18. <b>static_ip_list</b>: If not provided or empty, IPAM will make an external request to set all required information. If provided, the IP's will be set to the list contents and then Bastion and DNS will be determined. Primary IP will be expected as the first element and backup as the second. i.e. primary ip at index 0, backup at index 1.
19. <b>defaultGateway</b>: This is required only if a static_ip_list is provided. It is neccesary for DNS information to be acquired.

### 4.5. Returned Data
The following information from the IPAM request will be set in artifact_data if the `static_ip_list` is not provided:
1. ipAddress - the primary ip address
2. defaultGateway - the defaultGateway recieved from the IPAM request
3. resultDetail - status message from the request
4. vSphere_network - `"{{ tenant }}|{{ risk_container }}|{{ security_zone }}"`
5. dns_servers - first DNS server list that is found.
6. bastion: Bastion associated with the risk_container and location of deployment 
7. FQDN
8. networkAddress
9. subnetMask
00. ipv4_netmask
11. primary_dns_address - first DNS server in dns_servers
12. secondary_dns_address - second DNS server in dns_servers
13. third_dns_address - third DNS server in dns_servers
14. backup - the backup ip address
15. ipv4_netmask_backup - backup ipv4_netmask variable
16. vSphere_network_backup - `"{{ tenant }}|BDN|CLIENT-BACKUP"`
17. subnetMask_backup
18. networkAddress_backup

The following information will be set in artifact_data if the `static_ip_list` is provided:
1. ipAddress - the primary ip address
2. backup - the backup ip address
3. resultDetail - status message from the request
4. ipv4_netmask
5. ipv4_netmask_backup
6. defaultGateway
7. defaultGateway_backup
8. vSphere_network - `"{{ tenant }}|{{ risk_container }}|{{ security_zone }}"`
9. vSphere_network_backup
00. dns_servers - first DNS server list that is found.
11. bastion: Bastion associated with the risk_container and location of deployment
12. networkAddress
13. networkAddress_backup
14. subnetMask
15. subnetMask_backup 
16. primary_dns_address - first DNS server in dns_servers
17. secondary_dns_address - second DNS server in dns_servers
18. third_dns_address - third DNS server in dns_servers