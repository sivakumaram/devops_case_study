# Oracle-Workflow

## About

This role processes a request from ServiceNow to create an Oracle database,
configure Data Guard replication, scan for vulnerabilities, and post status
updates to ServiceNow.

Given two hosts, one belonging to the group `create_db_run_host` and the other to
the group `post_create_db_run_host`, this role takes the following steps:

  1. On `post_create_db_run_host` and `create_db_run_host`, convert SNOW variables and template extra vars
     ([`pre-req.yml`](tasks/pre-req.yml))
  2. On `create_db_run_host`, execute [`create-rac-database.yml`](https://github.test.com/dbaas/dbaas-create-database-v2/blob/master/create-rac-database.yml) to create an Oracle database
     ([`create-db.yml`](tasks/create-db.yml))
  3. On `post_create_db_run_host`, execute [`oracle-test.yml`](https://github.test.com/robops/oracle-test/blob/develop/playbooks/oracle-test.yml) to perform OEM database discovery, create a standby database, configure Data Guard, and scan for vulnerabilities
     ([`post-create.yml`](tasks/post-create.yml))
  4. On `post_create_db_run_host`, update the RITM in SNOW with the cumulative workflow status
     ([`notification.yml`](tasks/notification.yml))

*NOTE: The playbook [`create-rac-database.yml`](https://github.test.com/dbaas/dbaas-create-database-v2/blob/master/create-rac-database.yml) must exist on `create_db_run_host`, and the playbook [`oracle-test.yml`](https://github.test.com/robops/oracle-test/blob/develop/playbooks/oracle-test.yml) must exist on `post_create_db_run_host`. See [`create-db.yml`](tasks/create-db.yml) and [`post-create.yml`](tasks/post-create.yml) for details.*

---

Inputs
------
The following variables are accepted as input for this role.

Variable                     | Description                                  | Type    | Default
--------                     | -----------                                  | ----    | -------
`oem_host`                   | Oracle Enterprise Manager Host               | string  | `00.30.144.81`
`snow_instance_name`         | ServiceNow Instance Name                     | string  | `atyourserviceportaldev1`
`snow_catalog_item`          | ServiceNow Request Catalog Item SysID **\*** | string  |
`snow_ctask_id`              | ServiceNow Request Task SysID  **\***        | string  |
`snow_ctask_number`          | ServiceNow Request Task Number **\***        | string  |
`snow_request_id`            | ServiceNow Request Item SysID **\***         | string  |
`snow_request_number`        | ServiceNow Request Item Number **\***        | string  | `RITM21002156375`
`request_form_vars`          | ServiceNow Request Form Vars **\***          | mapping |
`request_price`              | ServiceNow Request Price **\***              | string  |
`request_user`               | ServiceNow Request User SysID **\***         | string  |
`request_user_email`         | ServiceNow Request User Email **\***         | string  |
`meta`                       | ServiceNow Request Field **\***              | string  |
`set`                        | ServiceNow Request Field **\***              | boolean |
`snow_ref`                   | ServiceNow Request Field **\***              | string  |

**\*** *See the Request Oracle Database catalog item in ServiceNow for more details*

---

Dependencies
------------
The following roles are required to run the `oracle-workflow` role.

- [`robops/oracle-db-vulnerability`](https://github.test.com/robops/oracle-db-vulnerability)
- [`robops/oracle-dg-replication`](https://github.test.com/robops/oracle-dg-replication)
- [`robops/oracle-oem-monitoring`](https://github.test.com/robops/oracle-oem-monitoring)
- [`robops/oracle-snow-converter`](https://github.test.com/robops/oracle-snow-converter)
- [`robops/oracle-snow-notification`](https://github.test.com/robops/oracle-snow-notification)

---

## Usage

### Requirements

In order to run the tasks in this role, the following requirements must be satisfied:

- OEM server
- Server on which to create a primary database
- Server on which to create a standby database
- Repository [`dbaas/dbaas-create-database-v2`](https://github.test.com/dbaas/dbaas-create-database-v2) existing on `create_db_run_host`
- Repository [`robops/oracle-test`](https://github.test.com/robops/oracle-test) existing on `post_create_db_run_host`
- Open connection from `create_db_run_host` and `post_create_db_run_host` to OEM server
- Open connection from `create_db_run_host` and `post_create_db_run_host` to primary and standby database servers
- Open conenction from `post_create_db_run_host` to ServiceNow

### Example

The following is an example of a playbook that runs the `oracle-workflow` role.

```yaml
---
- hosts: localhost
  connection: local
  pre_tasks:
    - add_host:
        name: "00.0.0.1"
        groups:
          - post_create_db_run_host

    - add_host:
        name: "00.0.0.1"
        groups:
          - create_db_run_host

- hosts: create_db_run_host,post_create_db_run_host
  roles:
    - role: oracle-workflow
      vars:
        oem_host: '00.0.0.2'
        snow_instance_name: atyourserviceportaldev1
        snow_catalog_item: b7a758391bce34d07cb1ed33b24bcbd9
        snow_ctask_id: 8cf63b341b3afc947cb1ed33b24bcba0
        snow_ctask_number: SCTASK21002700193
        snow_request_id: 6fe6b7341b3afc947cb1ed33b24bcbed
        snow_request_number: RITM21002156376
        request_form_vars:
          application_owner: 1c5737971b3bac98249120ea234bcb99
          bus_app: 168ea6111b7dec9465b6ece5624bcb10
          bus_app_instance: d28ea6111b7dec9465b6ece5624bcb4f
          character_set: AL32UTF8-America-American
          cluster_name: snow2c
          company: 337b1ae21bbbac509c865244604bcb59
          cost_center: c013905d0f4c4340d5ff716ce1050e8f
          ctr1_end: ''
          ctr1_start: ''
          ctr2_end: ''
          ctr2_start: ''
          ctr3_end: ''
          ctr3_start: ''
          ctr4_end: ''
          ctr4_start: ''
          ctr5_end: ''
          ctr5_start: ''
          ctr6_end: ''
          ctr6_start: ''
          ctr7_end: ''
          ctr7_start: ''
          ctr8_end: ''
          ctr8_start: ''
          database_type: RAC Database
          db_name: scrumandcoke
          db_owner: 1c5737971b3bac98249120ea234bcb99
          db_size: small
          instance_name: scrumandcoke
          lifecycle: 03f50b6e4f15fa80e6da69118110c73c
          line_of_business: c3e931841bb1245481f8eb12b24bcb30
          location: dd38b7111b121100763d91eebc0713f5
          primary_active: 33f361fc1b4f77c8e72b85506e4bcbb4
          primary_passive: 33f361fc1b4f77c8e72b85506e4bcbb4
          primary_site: 1745f2f1376acb001b765aa543990e61
          region: dbf440100a0a0a65006618f752ee74b5
          retention_period: '14'
          risk_container: 2d1dd5b1dba150904485dcf1f39619aa
          secondary_site: 60bee05837484340979d8d2754990e0d
          standby_active: 33f361fc1b4f77c8e72b85506e4bcbb4
          standby_passive: 33f361fc1b4f77c8e72b85506e4bcbb4
          standby_port: '1622'
          support_department: DBAEF
          tns_service_name: snowtns
          users: 1c5737971b3bac98249120ea234bcb99
        request_price: '0'
        request_user: 1c5737971b3bac98249120ea234bcb99
        request_user_email: lc5647361
        meta: ''
        set: false
        snow_ref: 8cf63b341b3afc947cb1ed33b24bcba0
```

---

## Testing

### Test Variables

The following variables may be provided to alter the execution of the database creation playbook
([`create-rac-database.yml`](https://github.test.com/dbaas/dbaas-create-database-v2/blob/master/create-rac-database.yml)).
For details, see [`create-db.yml`](tasks/create-db.yml)

Variable                     | Description
--------                     | -----------
`create_db`                  | Whether or not to create a database
`test_local`                 | Whether or not to test outside of Ansible Tower
`create_db_ansible_password` | When `test_local` is true, pass this the value of the extra var `ansible_ssh_pass` when executing the database creation playbook
`create_db_ansible_user`     | When `test_local` is true, pass this the value of the extra var `ansible_user` when executing the database creation playbook
`orcl_test`                  | When set to `03a`, run using the same hosts described in [Lab Environment](README.md#lab-environment)

### Lab Environment

Ansible version: 2.9.6

This role has been tested using the following inventory.

```
[post_create_db_run_host]
00.30.144.56  ansible_connection=ssh  ansible_user=root  ansible_ssh_pass=********

[create_db_run_host]
00.30.144.250  ansible_connection=ssh  ansible_user=root  ansible_ssh_pass=********
```

Testing has been performed with following extra variables.

```yaml
test_local: true

hostlist:
    bdc6ltestlabdb03a:
        install_node: True
        fqdn: bdc6ltestlabdb03a.test.lab
    bdc6ltestlabdb03b:
        install_node: False
        fqdn: bdc6ltestlabdb03b.test.lab

orcl_db_primary:
    - bdc6ltestlabdb03a.test.lab
    - bdc6ltestlabdb03b.test.lab

orcl_db_standby:
    - bdc6ltestlabdb04a.test.lab
    - bdc6ltestlabdb04b.test.lab

oem_host: 00.30.144.81

orcl_gtp_cluster_name: bdc6ltestlabdb03

orcl_rac_pri_node_1: bdc6ltestlabdb03a
orcl_rac_pri_node_2: bdc6ltestlabdb03b
orcl_rac_sby_node_1: bdc6ltestlabdb04a
orcl_rac_sby_node_2: bdc6ltestlabdb04b

g_environment: Test
orcl_gtp_lifecycle_status: Test
orcl_gtp_support_department: BDOC
orcl_gtp_location: BDOC
```

---

## Defaults

The following defaults are used by this role.
See [`defaults/main.yml`](defaults/main.yml) for details.

***WARNING: These variables should not be overriden unless you know what you are doing.***

Variable                        | Description
--------                        | -----------
`run_steps`                     | Execution Steps
`workflow_status`               | Execution Status
`snow_instance`                 | Alias of `snow_instance_name`
`create_db_var_dest_path`       | Create DB Root Directory
`create_db_modules_path`        | Create DB Modules Directory
`create_db_inventory_directory` | Create DB Inventory Directory
`create_db_playbook_name`       | Create DB Playbook File
`create_db_input_template`      | Create DB Database Template
`create_db_output_dest_path`    | Create DB Log File
`create_db_input_dest_path`     | Create DB Extra Vars File
`create_db_password_path`       | Create DB Database Password File
`create_db_vault_creds_file`    | Create DB Vault Password File
`var_dest_path`                 | Post-Create Root Directory
`post_input_dest_path`          | Post-Create Extra Vars File
`output_dest_path`              | Post-Create Log File
`output_summary`                | Post-Create Summary File
`repo_directory`                | Post-Create Repo Directory
`playbook_directory`            | Post-Create Playbook Directory
`playbook_name`                 | Post-Create Playbook File
`inventory_directory`           | Post-Create Inventory Directory
`inventory_name`                | Post-Create Inventory File
`vault_creds_file`              | Post-Create Vault Password File

---

## Authors

### Scrum & Coke



### PO


---

## License

BSD
