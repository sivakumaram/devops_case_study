
# About
The following steps shows the step by step instruction on how to integrate the Oracle Flow.
```
  1. Login to the run hose (a machine that has the fw open from itself to all the databases)
      a. For Create DB, we are using host `00.30.144.250`
         The variable for this host is defined as `create_db_run_host`
      b. For Create DB, we are using host `00.30.144.56`
         The variable for this host is defined as `post_create_run_host`

  2. Create a Folder
      a. On host create (00.30.144.250) we have a folder `/home/oracle/workspace`
      b. On host post-create (00.30.144.56), we have a folder `/root/ansible`
  3. Clone all the necessary ansible codes (stage)
      a. On host create (00.30.144.250), the code is already staged in `/home/oracle/workspace/dbaas-create-database-v2.3/`
      b. On host post-create (00.30.144.56)
          i. Go to the folder `/root/ansible`
          ii. Git clone https://github.test.com/robops/oracle-test.git
          iii. cd to the newly cloned repo `oracle-test`
          iv. run `ansible-galaxy install -r roles/requirements.yml -p roles`, This should install all the dependency roles
  3. On Ansible Tower
      i. Create a Project (if not existing before), and map that project with repo `https://github.test.com/robops/oracle-test.git`
      ii. Create a template (ansible job) and ensure that the newly created job has all the necessary ansible vault password attached to it (there are credential with name Orale machine type and oracle-lab-test vault)
      iii. Point the newly created template to point to workflow.yml inside the oracle-test repo
  4. When running the ansible tower job, ensure the following inputs are passed
          meta: ''
          oem_host: 00.30.144.81
          orcl_db_host_primary: bdc6ltestlabdb04a.test.lab
          orcl_db_host_secondary: bdc6ltestlabdb04b.test.lab
          request_form_vars:
            application_owner: 6cdf31ffdbd93f48f545bb1a689619f3
            bus_app: defcea201b0d24d09d6097d8b04bcbc9
            bus_app_instance: 9afcea201b0d24d09d6097d8b04bcbc8
            character_set: AL32UTF8-America-American
            cluster_name: Cluster1
            company: 337b1ae21bbbac509c865244604bcb59
            cost_center: 4c13905d0f4c4340d5ff716ce1050e90
            ctr1_end: ''
            ctr1_start: ''
            ctr2_end: ''
            ctr2_start: ''
            ctr3_end: ''
            ctr3_start: ''
            ctr4_end: ''
            ctr4_start: ''
            ctr5_end: ''
            ctr5_start: ''
            ctr6_end: ''
            ctr6_start: ''
            ctr7_end: ''
            ctr7_start: ''
            ctr8_end: ''
            ctr8_start: ''
            database_type: RAC Database
            db_name: Test-Database
            db_owner: be00d9ef1bddf34c36cfea0f6e4bcb17
            db_size: small
            instance_name: db
            lifecycle: 03f50b6e4f15fa80e6da69118110c73c
            line_of_business: bf8efca41b0dec909d6097d8b04bcbb2
            location: dd38b7111b121100763d91eebc0713f5
            primary_host: 33f361fc1b4f77c8e72b85506e4bcbb4
            primary_site: 1745f2f1376acb001b765aa543990e61
            region: 2a5289421b2e6c14b8bae1db234bcb80
            retention_period: '14'
            risk_container: 2d1dd5b1dba150904485dcf1f39619aa
            secondary_host: ''
            secondary_site: ''
            support_department: DBAU
            tns_service_name: dbservice1
            users: 0931ea37dbd97f48f545bb1a689619e5
          request_price: '0'
          request_user: 505737971b3bac98249120ea234bcb9c
          request_user_email: lc5647363
          set: false
          snow_catalog_item: b7a758391bce34d07cb1ed33b24bcbd9
          snow_ctask_id: fa157eaadb6a38508d2dce46b99619ca
          snow_ctask_number: SCTASK21002699453
          snow_ref: fa157eaadb6a38508d2dce46b99619ca
          snow_request_id: 52153eaadb6a38508d2dce46b9961969
          snow_request_number: RITM21002150333
          tower_job_launched: '5661'

```