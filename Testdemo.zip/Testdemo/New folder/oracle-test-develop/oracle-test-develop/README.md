# Oracle-test

## About

This repository contains Ansible playbooks and roles used to create an Oracle database based on a request from ServiceNow. The playbook [`workflow.yml`](workflow.yml) initiates the database creation process.

### Directories

Directory                    | Description
---------                    | -----------
[`playbooks`](playbooks)     | Ansible playbooks
[`collections`](collections) | Ansible collections
[`inventory`](inventory)     | Ansible inventories and host group variables
[`plugins`](plugins)         | Ansible plugins and modules
[`roles`](roles)             | Ansible roles
[`tests`](tests)             | Variables and playbooks used for testing

---

## Usage

The playbooks and roles in this repository are intended to be used by running the playbook [`workflow.yml`](workflow.yml).

### Requirements

In order to run [`workflow.yml`](workflow.yml), the same requirements described in the [`oracle-workflow`](roles/oracle-workflow/README.md#requirements) role must be satisfied.

Additionally, [`workflow.yml`](workflow.yml) requires an open connection from the Ansible execution node to `create_db_run_host` and `post_create_run_host` (see [Inputs](README.md#inputs)).

### Inputs

The following variables are expected as input for the [`workflow.yml`](workflow.yml) playbook.

Variable                     | Description                                  | Type
--------                     | -----------                                  | ----
`create_db_run_host`         | Database Creation Host                       | string
`post_create_run_host`       | Database Post-Creation Host                  | string
`oem_host`                   | Oracle Enterprise Manager Host               | string
`snow_instance_name`         | ServiceNow Instance Name                     | string
`snow_catalog_item`          | ServiceNow Request Catalog Item SysID **\*** | string
`snow_ctask_id`              | ServiceNow Request Task SysID  **\***        | string
`snow_ctask_number`          | ServiceNow Request Task Number **\***        | string
`snow_request_id`            | ServiceNow Request Item SysID **\***         | string
`snow_request_number`        | ServiceNow Request Item Number **\***        | string
`request_form_vars`          | ServiceNow Request Form Vars **\***          | mapping
`request_price`              | ServiceNow Request Price **\***              | string
`request_user`               | ServiceNow Request User SysID **\***         | string
`request_user_email`         | ServiceNow Request User Email **\***         | string
`meta`                       | ServiceNow Request Field **\***              | string
`set`                        | ServiceNow Request Field **\***              | boolean
`snow_ref`                   | ServiceNow Request Field **\***              | string

**\*** *See the Request Oracle Database catalog item in ServiceNow for more details.*

### Dependencies

The [`workflow.yml`](workflow.yml) playbook has the same dependencies described in the [`oracle-workflow`](roles/oracle-workflow/README.md#about) role.

Additionally, [`workflow.yml`](workflow.yml) depends on the [`oracle-workflow`](roles/oracle-workflow) role, which, at the time of writing, is contained in the [`roles`](roles) directory of this repository.

### Example

First, populate a file with the relevant key-value pairs to be passed as extra variables to the [`workflow.yml`](workflow.yml) playbook.

*NOTE: Extra variables may also be passed as raw key-value pairs using the `-e` option.*

Next, from the root of the repository, run the playbook [`workflow.yml`](workflow.yml) with the extra variables from the previous step to execute the Oracle database creation process.

For example, consider a file `extra_vars.yml` with the following content.

```yaml
---
create_db_run_host: '00.0.0.1'
post_create_run_host: '00.0.0.1'
oem_host: '00.0.0.2'
snow_instance_name: atyourserviceportaldev1
meta: ''
request_form_vars:
  application_owner: 1c5737971b3bac98249120ea234bcb99
  bus_app: 168ea6111b7dec9465b6ece5624bcb10
  bus_app_instance: d28ea6111b7dec9465b6ece5624bcb4f
  character_set: AL32UTF8-America-American
  cluster_name: snow2c
  company: 337b1ae21bbbac509c865244604bcb59
  cost_center: c013905d0f4c4340d5ff716ce1050e8f
  ctr1_end: ''
  ctr1_start: ''
  ctr2_end: ''
  ctr2_start: ''
  ctr3_end: ''
  ctr3_start: ''
  ctr4_end: ''
  ctr4_start: ''
  ctr5_end: ''
  ctr5_start: ''
  ctr6_end: ''
  ctr6_start: ''
  ctr7_end: ''
  ctr7_start: ''
  ctr8_end: ''
  ctr8_start: ''
  database_type: RAC Database
  db_name: scrumandcoke
  db_owner: 1c5737971b3bac98249120ea234bcb99
  db_size: small
  instance_name: scrumandcoke
  lifecycle: 03f50b6e4f15fa80e6da69118110c73c
  line_of_business: c3e931841bb1245481f8eb12b24bcb30
  location: dd38b7111b121100763d91eebc0713f5
  primary_active: 33f361fc1b4f77c8e72b85506e4bcbb4
  primary_passive: 33f361fc1b4f77c8e72b85506e4bcbb4
  primary_site: 1745f2f1376acb001b765aa543990e61
  region: dbf440100a0a0a65006618f752ee74b5
  retention_period: '14'
  risk_container: 2d1dd5b1dba150904485dcf1f39619aa
  secondary_site: 60bee05837484340979d8d2754990e0d
  standby_active: 33f361fc1b4f77c8e72b85506e4bcbb4
  standby_passive: 33f361fc1b4f77c8e72b85506e4bcbb4
  standby_port: '1622'
  support_department: DBAEF
  tns_service_name: snowtns
  users: 1c5737971b3bac98249120ea234bcb99
request_price: '0'
request_user: 1c5737971b3bac98249120ea234bcb99
request_user_email: lc5647361
set: false
snow_catalog_item: b7a758391bce34d07cb1ed33b24bcbd9
snow_ctask_id: 8cf63b341b3afc947cb1ed33b24bcba0
snow_ctask_number: SCTASK21002700193
snow_ref: 8cf63b341b3afc947cb1ed33b24bcba0
snow_request_id: 6fe6b7341b3afc947cb1ed33b24bcbed
snow_request_number: RITM21002156376
```

Given this file, we would run the following command.

```sh
ansible-playbook -e '@extra_vars.yml' workflow.yml
```

---

## Authors

### Scrum & Coke



### PO



---

## License

BSD
