# avamar_functions
Avamar selfheal functions

SNOW Trigger Playbook 

1. Ansible will conenct to SNOW API and execute a query to fetch the Active Incidents in the queue (State is New\inprogress\onhold,Assigned to CI support team)
2. Absible will Call Tasks playbook which has logics that covers below logic

Tasks Playbook 

1. Fetch the Mandate values from Short description
2. Identify the Backup Window for each Avamar instance
3. Validate the Avamar Instance in SNOW CMDB and fetch the Valid FQDN
4. Generate Authorize token for authentication from Avamar Instance
5. Verify the Avamar Instance state and utilization
6. Verify the affected CI associated plugin names
7. Perform the Activities search of the affected CI to Identify the Recent failure
8. Re trigger the Job based on Affected CI recent backup job state
9. Prepare the Notes for Update or closure of Incident
10. Update SNOW for closing incident or updating incident